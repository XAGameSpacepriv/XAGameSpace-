package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

// Window overlay Macro: tombol Trigger (tahan), titik Tembak (1), dan titik Senjata (2).
// Perilaku disamakan dengan XAGameSpacepanel: trigger selalu bisa ditekan, titik target ikut "kunci posisi & transparan",
// dan mode atur posisi (D-Pad) membuat semua titik bisa diseret lalu dikunci lagi.
object MacroOverlay {
    private const val TRIG = 0
    private const val T1 = 1
    private const val T2 = 2
    private const val LABEL_DP = 16

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var ui: Context? = null
    private var onPanel: ((Boolean) -> Unit)? = null
    private val views = arrayOfNulls<PlaceDot>(3)
    private val params = arrayOfNulls<WindowManager.LayoutParams>(3)
    private var bar: View? = null
    private var placing = false
    private var snapshot: MacroConfig? = null
    private var sel = TRIG

    fun attach(w: WindowManager, c: Context, panel: (Boolean) -> Unit) {
        wm = w
        ui = c
        onPanel = panel
        MacroEngine.onChange = { sync() }
        sync()
    }

    fun detach() {
        MacroEngine.onChange = null
        placing = false
        snapshot = null
        bar?.let { safeRemove(it) }
        bar = null
        removeAll()
        wm = null
        ui = null
        onPanel = null
    }

    // ---------- sinkron window dengan config ----------

    fun sync() {
        val w = wm ?: return
        val c = ui ?: return
        val cfg = MacroEngine.cfg
        val want = booleanArrayOf(
            cfg.enabled,
            cfg.enabled && cfg.showTarget,
            cfg.enabled && cfg.showTarget && (cfg.enableTarget2 || cfg.pattern == MacroPattern.QUICK_SWITCH)
        )
        for (i in 0..2) {
            if (!want[i]) {
                views[i]?.let { safeRemove(it) }
                views[i] = null
                params[i] = null
                continue
            }
            if (views[i] == null) addDot(w, c, i)
            applyDot(w, c, i, cfg)
        }
    }

    private fun addDot(w: WindowManager, c: Context, i: Int) {
        val label = when (i) {
            TRIG -> "Trigger"
            T1 -> "1 • Tembak"
            else -> "2 • Senjata"
        }
        val color = when (i) {
            TRIG -> MT.amber
            T1 -> MT.accent
            else -> MT.cyan
        }
        val v = PlaceDot(c, label, color, i == TRIG)
        val p = WindowManager.LayoutParams(
            1, 1, overlayType(), baseFlags(), PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        var downRx = 0f
        var downRy = 0f
        var startX = 0
        var startY = 0
        v.setOnTouchListener { _, e ->
            // trigger = tombol tahan/tap di luar mode atur posisi; drag hanya saat atur posisi
            if (i == TRIG && !placing) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> MacroEngine.onTriggerDown(c)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> MacroEngine.onTriggerUp(c)
                }
                true
            } else {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downRx = e.rawX
                        downRy = e.rawY
                        startX = p.x
                        startY = p.y
                        if (placing) select(i)
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val s = MacroEngine.screenSize(c)
                        p.x = (startX + (e.rawX - downRx)).roundToInt().coerceIn(0, s[0] - p.width)
                        p.y = (startY + (e.rawY - downRy)).roundToInt().coerceIn(0, s[1] - p.height)
                        runCatching { w.updateViewLayout(v, p) }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        savePos(c, i, p)
                        true
                    }
                    else -> true
                }
            }
        }
        views[i] = v
        params[i] = p
        runCatching { w.addView(v, p) }
    }

    private fun applyDot(w: WindowManager, c: Context, i: Int, cfg: MacroConfig) {
        val v = views[i] ?: return
        val p = params[i] ?: return
        val s = MacroEngine.screenSize(c)
        val circleDp = if (i == TRIG) (50f * cfg.triggerScale).coerceIn(36f, 84f).roundToInt() else 40
        val size = c.px(circleDp + LABEL_DP)
        val (nx, ny) = when (i) {
            TRIG -> cfg.triggerNormX to cfg.triggerNormY
            T1 -> cfg.targetNormX to cfg.targetNormY
            else -> cfg.target2NormX to cfg.target2NormY
        }
        val labelPx = c.px(LABEL_DP)
        val cxPx = (nx * s[0]).roundToInt()
        val cyPx = (ny * s[1]).roundToInt()
        p.width = size
        p.height = size
        p.x = (cxPx - size / 2).coerceIn(0, (s[0] - size).coerceAtLeast(0))
        p.y = (cyPx - (size - labelPx) / 2).coerceIn(0, (s[1] - size).coerceAtLeast(0))

        val locked = cfg.isLocked && !placing
        val touchable = i == TRIG || !locked
        p.flags = baseFlags() or if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        v.alpha = if (locked) cfg.lockedOpacity else 1f
        v.running = cfg.isRunning && i == TRIG
        v.highlight = placing && sel == i
        runCatching { w.updateViewLayout(v, p) }
    }

    // simpan posisi (normalisasi) dari window ke config
    private fun savePos(c: Context, i: Int, p: WindowManager.LayoutParams) {
        val s = MacroEngine.screenSize(c)
        val size = p.width
        val labelPx = c.px(LABEL_DP)
        val nx = ((p.x + size / 2f) / s[0]).coerceIn(0.05f, 0.95f)
        val ny = ((p.y + (size - labelPx) / 2f) / s[1]).coerceIn(0.05f, 0.95f)
        MacroEngine.update {
            when (i) {
                TRIG -> it.copy(triggerNormX = nx, triggerNormY = ny)
                T1 -> it.copy(targetNormX = nx, targetNormY = ny)
                else -> it.copy(target2NormX = nx, target2NormY = ny)
            }
        }
    }

    // ---------- mode atur posisi (D-Pad) ----------

    fun startPlacement() {
        val c = ui ?: return
        val w = wm ?: return
        if (placing) return
        MacroEngine.stop()
        snapshot = MacroEngine.cfg
        placing = true
        MacroEngine.update { it.copy(enabled = true, showTarget = true, isLocked = false, isRunning = false) }
        onPanel?.invoke(false)
        sel = TRIG
        showBar(w, c)
        sync()
    }

    private fun finish(keep: Boolean) {
        val snap = snapshot
        if (!keep && snap != null) {
            MacroEngine.update { snap.copy(isRunning = false) }
        } else {
            MacroEngine.update { it.copy(isLocked = true, isRunning = false) }
        }
        snapshot = null
        placing = false
        bar?.let { safeRemove(it) }
        bar = null
        sync()
        onPanel?.invoke(true)
    }

    private fun select(i: Int) {
        sel = i
        for (k in 0..2) views[k]?.highlight = placing && sel == k
    }

    private fun nudge(dx: Int, dy: Int) {
        val c = ui ?: return
        val w = wm ?: return
        val i = sel
        val v = views[i] ?: return
        val p = params[i] ?: return
        val s = MacroEngine.screenSize(c)
        p.x = (p.x + dx).coerceIn(0, (s[0] - p.width).coerceAtLeast(0))
        p.y = (p.y + dy).coerceIn(0, (s[1] - p.height).coerceAtLeast(0))
        runCatching { w.updateViewLayout(v, p) }
        savePos(c, i, p)
    }

    private fun showBar(w: WindowManager, c: Context) {
        bar?.let { safeRemove(it) }
        val cfg = MacroEngine.cfg
        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(c.px(10), c.px(8), c.px(10), c.px(8))
            background = MT.sheetBg(c)
        }
        col.addView(row(c,
            pBtn(c, "Trigger") { select(TRIG) },
            pBtn(c, "1 • Tembak") { select(T1) },
            if (cfg.enableTarget2 || cfg.pattern == MacroPattern.QUICK_SWITCH) {
                pBtn(c, "2 • Senjata") { select(T2) }
            } else {
                pBtn(c, "+ 2 Senjata") {
                    MacroEngine.update {
                        it.copy(enableTarget2 = true, showTarget = true, pattern = MacroPattern.QUICK_SWITCH)
                    }
                    showBar(w, c)
                    select(T2)
                }
            }
        ))
        col.addView(row(c, pBtn(c, "▲") { nudge(0, -12) }))
        col.addView(row(c,
            pBtn(c, "◀") { nudge(-12, 0) },
            pBtn(c, "▼") { nudge(0, 12) },
            pBtn(c, "▶") { nudge(12, 0) }
        ))
        col.addView(row(c,
            pBtn(c, "Batal") { finish(keep = false) },
            pBtn(c, "Selesai & Kunci", primary = true) { finish(keep = true) }
        ))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            baseFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = c.px(20)
        }
        bar = col
        runCatching { w.addView(col, lp) }
    }

    // ---------- helper ----------

    private fun pBtn(c: Context, text: String, primary: Boolean = false, onClick: () -> Unit): TextView =
        MT.button(c, text, primary, onClick).apply {
            textSize = 10f
            setPadding(c.px(8), c.px(6), c.px(8), c.px(6))
        }

    private fun row(c: Context, vararg views: View): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            views.forEach { v ->
                addView(v, LinearLayout.LayoutParams(-2, -2).also {
                    it.setMargins(c.px(3), c.px(3), c.px(3), c.px(3))
                })
            }
        }

    private fun baseFlags(): Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun safeRemove(v: View) {
        runCatching { wm?.removeView(v) }
    }

    private fun removeAll() {
        for (i in 0..2) {
            views[i]?.let { safeRemove(it) }
            views[i] = null
            params[i] = null
        }
    }
}

// Lingkaran target: crosshair + label. Tahan/tap dan drag diatur di MacroOverlay.
private class PlaceDot(c: Context, private val label: String, private val col: Int, private val filled: Boolean) :
    View(c) {

    var highlight = false
        set(v) { field = v; invalidate() }
    var running = false
        set(v) { field = v; invalidate() }

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = col
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = col
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = MT.text
        textSize = c.pxf(9f)
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    override fun onDraw(cv: Canvas) {
        val labelPx = context.pxf(16f)
        val cx = width / 2f
        val cy = (height - labelPx) / 2f
        val r = (minOf(width.toFloat(), height - labelPx) / 2f) - context.pxf(3f)
        if (filled) {
            fill.alpha = if (running) 200 else 90
            cv.drawCircle(cx, cy, r, fill)
        }
        ring.strokeWidth = context.pxf(if (highlight) 3f else 2f)
        cv.drawCircle(cx, cy, r, ring)
        cv.drawLine(cx - r, cy, cx + r, cy, ring)
        cv.drawLine(cx, cy - r, cx, cy + r, ring)
        fill.alpha = 255
        cv.drawCircle(cx, cy, context.pxf(2.5f), fill)
        cv.drawText(label, cx, height - context.pxf(3f), txt)
    }
}
