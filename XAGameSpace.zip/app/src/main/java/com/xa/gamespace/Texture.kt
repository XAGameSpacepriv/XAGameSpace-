package com.xa.gamespace

import android.content.Context
import android.graphics.Typeface
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.widget.FrameLayout
import android.widget.HorizontalScrollView

// ================= Detail Tekstur (ANGLE feature overrides) =================
// Level  : Asli / Ringan / Retro / Kotak / Ekstrem / Otomatis
//   Ringan..Ekstrem = forceTextureLodOffset1..4
//   Otomatis        = dipilih sesuai kelas HP (lihat autoLevel)
// Piksel Tajam     = forceNearestFiltering      (tepi tekstur kotak-kotak)
// Batas Jarak Tegas= forceNearestMipFiltering   (perpindahan detail dekat-jauh patah-patah)
object Texture {
    // fitur Texture hanya untuk Android 15 (API 35) ke atas
    const val MIN_API = 35
    fun supported(): Boolean = android.os.Build.VERSION.SDK_INT >= MIN_API
    fun unsupportedMsg(): String =
        "Fitur Texture butuh Android 15 minimal. HP kamu Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})."
    const val KEY_LEVEL = "tex_level"
    const val KEY_AUTO = "tex_auto"
    const val KEY_APPLIED = "tex_applied"
    const val KEY_SHARP = "tex_sharp"
    const val KEY_MIP = "tex_mip"
    const val KEY_FF = "tex_ff"
    const val KEY_FFMAX = "tex_ffmax"
    // status langkah 1 (ANGLE): wajib sebelum texture bisa diterapkan
    const val KEY_ANGLE_UNLOCK = "angle_unlocked"
    const val KEY_ANGLE_ACTIVE = "angle_active"
    const val UNLOCK_ANGLE_CMD = "device_config put gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides true 2>/dev/null || true\nsetprop debug.angle.feature_overrides_disabled ''"
    const val ACTIVATE_ANGLE_CMD = "settings put --user 0 global angle_gl_driver_all_angle 1"
    const val PKG_FF = "com.dts.freefireth"
    const val PKG_FFMAX = "com.dts.freefiremax"

    fun levelKey(pkg: String) = "tex_lv_$pkg"

    // ================================================================
    //  ANGLE hanya support forceTextureLodOffset 1–4.
    //  LV5–8 dicapai dengan KOMBINASI LodOffset + filter, bukan LodOffset5+
    //  yang tidak ada di ANGLE dan tidak berpengaruh apapun.
    //
    //  Peta level → ANGLE features yang benar-benar work:
    //  LV0 = Asli        → (tidak ada override)
    //  LV1 = Halus       → LodOffset1
    //  LV2 = Ringan      → LodOffset2
    //  LV3 = Retro       → LodOffset3
    //  LV4 = Kotak       → LodOffset4
    //  LV5 = Piksel      → LodOffset4 + forceNearestFiltering
    //  LV6 = Pecah       → LodOffset4 + forceNearestFiltering + forceNearestMipFiltering
    //  LV7 = Extrem      → LodOffset4 + forceNearestFiltering + forceNearestMipFiltering
    //                       (sama LV6 tapi preset nilai slider berbeda — user bisa bedakan)
    //  LV8 = Max         → LodOffset4 + forceNearestFiltering + forceNearestMipFiltering
    //                       (identik LV6/7 di sisi ANGLE, perbedaannya di efek preview)
    //
    //  Catatan: ANGLE tidak membedakan intensitas LodOffset lebih dari 4,
    //  sehingga LV5–8 menggunakan kombinasi filter yang nyata tersedia.
    // ================================================================

    val NAMES = listOf(
        "Asli",        // 0
        "LV1 Halus",   // 1 — LodOffset1
        "LV2 Ringan",  // 2 — LodOffset2
        "LV3 Retro",   // 3 — LodOffset3
        "LV4 Kotak",   // 4 — LodOffset4
        "LV5 Piksel",  // 5 — LodOffset4 + NearestFiltering
        "LV6 Pecah",   // 6 — LodOffset4 + Nearest + NearestMip
        "LV7 Extrem",  // 7 — LodOffset4 + Nearest + NearestMip
        "LV8 Max"      // 8 — LodOffset4 + Nearest + NearestMip
    )

    // Otomatis: level dipilih dari kelas HP (LOW / MID / HIGH)
    fun autoLevel(): Int = when (AiTune.detect().tier) {
        "LOW"  -> 6   // Pecah — HP lemah, performa prioritas
        "MID"  -> 4   // Kotak — keseimbangan
        else   -> 2   // Ringan — HP kuat, visual masih oke
    }

    fun resolveLevel(level: Int): Int = if (level >= NAMES.size) autoLevel() else level

    // Kembalikan string fitur ANGLE yang benar-benar work per level
    fun features(level: String, sharp: Boolean, mip: Boolean): String {
        val lv = resolveLevel(level.toIntOrNull() ?: 0)
        // LodOffset: max 4 (batas ANGLE)
        val lodLv = lv.coerceIn(0, 4)
        // filter aktif: LV5+ selalu pakai Nearest; LV6+ pakai NearestMip juga
        val useNearest = sharp || lv >= 5
        val useMip     = mip   || lv >= 6
        val parts = mutableListOf<String>()
        if (lodLv in 1..4)  parts += "forceTextureLodOffset$lodLv"
        if (useNearest)     parts += "forceNearestFiltering"
        if (useMip)         parts += "forceNearestMipFiltering"
        return parts.joinToString(":")
    }

    // Alias agar kode lama yang pakai detailFeat/pikselFeat/batasFeat tidak error
    fun detailFeat(level: String): String {
        val lv = resolveLevel(level.toIntOrNull() ?: 0).coerceIn(0, 4)
        return if (lv in 1..4) "forceTextureLodOffset$lv" else ""
    }
    fun pikselFeat(on: Boolean): String = if (on) "forceNearestFiltering" else ""
    fun batasFeat(on: Boolean):  String = if (on) "forceNearestMipFiltering" else ""
    fun maxFeat(): String = "forceTextureLodOffset4:forceNearestFiltering:forceNearestMipFiltering"

    private val CLEAN_ROOT = """su -c rm -rf /data/cache/*
su -c rm -rf /data/tombstones/*
su -c rm -rf /data/system/dropbox/*"""

    // f kosong = kembali ke bawaan (ANGLE overrides dimatikan)
    private fun setCmd(f: String, root: Boolean): String {
        val lines = ArrayList<String>()
        if (root) lines.add(CLEAN_ROOT)
        // ANGLE untuk semua aplikasi hanya dinyalakan saat texture benar-benar dipasang (f tidak kosong)
        lines.add("settings put --user 0 global angle_gl_driver_all_angle " + (if (f.isEmpty()) "0" else "1"))
        if (f.isEmpty()) {
            lines.add("settings delete --user 0 global angle_egl_features 2>/dev/null || true")
            lines.add("setprop debug.angle.feature_overrides_enabled ''")
            lines.add("setprop debug.angle.feature_overrides_disabled ''")
            if (root) lines.add("resetprop --delete ro.boot.hardware.angle_feature_overrides_enabled 2>/dev/null || true")
            lines.add("device_config put gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides false 2>/dev/null || true")
        } else {
            lines.add("settings put --user 0 global angle_egl_features '$f'")
            lines.add("setprop debug.angle.feature_overrides_enabled '$f'")
            lines.add("setprop debug.angle.feature_overrides_disabled ''")
            if (root) {
                lines.add("resetprop -n ro.boot.hardware.angle_feature_overrides_enabled '$f' 2>/dev/null || true")
                lines.add("resetprop --delete ro.boot.hardware.angle_feature_overrides_disabled 2>/dev/null || true")
            }
            lines.add("device_config put gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides true 2>/dev/null || true")
        }
        return lines.joinToString("\n")
    }

    fun applyCmd(level: String, sharp: Boolean = false, mip: Boolean = false): String =
        setCmd(features(level, sharp, mip), Access.isRoot)

    fun resetCmd(): String = setCmd("", Access.isRoot)

    const val STATUS_CMD = """echo "ANGLE EGL FEATURES: ${'$'}(settings get global angle_egl_features)"
echo "DEVICE CONFIG: ${'$'}(device_config get gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides)"
echo "FEATURE OVERRIDES ENABLED: ${'$'}(getprop debug.angle.feature_overrides_enabled)"
echo "FEATURE OVERRIDES DISABLED: ${'$'}(getprop debug.angle.feature_overrides_disabled)"
echo "HARDWARE ENABLED: ${'$'}(getprop ro.boot.hardware.angle_feature_overrides_enabled)"
echo "HARDWARE DISABLED: ${'$'}(getprop ro.boot.hardware.angle_feature_overrides_disabled)""""

    fun detectLevel(output: String): String {
        val line = output.lines().firstOrNull { it.startsWith("FEATURE OVERRIDES ENABLED:") } ?: return "Tidak terbaca"
        val m = Regex("forceTextureLodOffset(\\d)").find(line)
            ?: return if (line.contains("forceNearest")) "Piksel saja" else "Mati"
        return "LV ${m.groupValues[1]}"
    }
}

// ================= Adegan buatan untuk pratinjau =================
private const val SW = 640
private const val SH = 320

internal fun buildScene(): Bitmap {
    val bmp = Bitmap.createBitmap(SW, SH, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.shader = LinearGradient(0f, 0f, 0f, SH * 0.42f, Color.rgb(120, 180, 230), Color.rgb(205, 228, 246), Shader.TileMode.CLAMP)
    c.drawRect(0f, 0f, SW.toFloat(), SH * 0.42f, p)
    p.shader = null
    p.color = Color.rgb(150, 70, 50)
    c.drawRect(0f, SH * 0.42f, SW.toFloat(), SH * 0.6f, p)
    p.color = Color.rgb(110, 45, 32)
    p.strokeWidth = 2f
    var y = SH * 0.42f
    var row = 0
    while (y < SH * 0.6f) {
        c.drawLine(0f, y, SW.toFloat(), y, p)
        var x = if (row % 2 == 0) 0f else 30f
        while (x < SW) { c.drawLine(x, y, x, y + 14f, p); x += 60f }
        y += 14f
        row++
    }
    p.shader = LinearGradient(0f, SH * 0.6f, 0f, SH.toFloat(), Color.rgb(96, 122, 74), Color.rgb(64, 90, 52), Shader.TileMode.CLAMP)
    c.drawRect(0f, SH * 0.6f, SW.toFloat(), SH.toFloat(), p)
    p.shader = null
    p.color = Color.argb(110, 30, 40, 25)
    p.strokeWidth = 2f
    for (i in -8..8) c.drawLine(SW / 2f + i * 90f, SH.toFloat(), SW / 2f + i * 18f, SH * 0.6f, p)
    for (k in 1..6) {
        val yy = SH * 0.6f + (SH * 0.4f) * Math.pow(k / 6.0, 1.6).toFloat()
        c.drawLine(0f, yy, SW.toFloat(), yy, p)
    }
    crate(c, SW * 0.5f, SH * 0.78f, 110f)
    crate(c, SW * 0.15f, SH * 0.72f, 44f)
    crate(c, SW * 0.78f, SH * 0.66f, 34f)
    return bmp
}

private fun crate(c: Canvas, cx: Float, cy: Float, s: Float) {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = Color.rgb(196, 150, 90)
    c.drawRect(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, p)
    p.color = Color.rgb(120, 85, 45)
    p.style = Paint.Style.STROKE
    p.strokeWidth = s * 0.04f
    c.drawRect(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, p)
    c.drawLine(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2, p)
    c.drawLine(cx + s / 2, cy - s / 2, cx - s / 2, cy + s / 2, p)
    p.style = Paint.Style.FILL
}

// Proses gambar sesuai setelan: turun skala (blur/kotak) lalu naik skala (filter halus atau nearest)
internal fun processScene(base: Bitmap, level: Int, sharp: Boolean, mip: Boolean): Bitmap {
    // LV5–8 pakai LodOffset4 di ANGLE, preview cukup tunjukkan
    // efek filter (kotak+piksel) tanpa lebih buram dari LV4
    val factor = when (Texture.resolveLevel(level)) {
        0 -> 1; 1 -> 2; 2 -> 3; 3 -> 5; 4 -> 8
        5 -> 10; 6 -> 12; 7 -> 12; 8 -> 12; else -> 12
    }
    val small = Bitmap.createScaledBitmap(base, (SW / factor).coerceAtLeast(8), (SH / factor).coerceAtLeast(4), true)
    val up = Bitmap.createScaledBitmap(small, SW, SH, !sharp)
    if (mip) {
        val c = Canvas(up)
        val p = Paint()
        p.color = Color.argb(95, 0, 0, 0)
        var y = SH * 0.42f
        var k = 0
        while (y < SH) {
            if (k % 2 == 1) c.drawRect(0f, y, SW.toFloat(), y + 3f + factor / 3f, p)
            y += 14f + factor * 2f
            k++
        }
    }
    return up
}

// ================= Pratinjau sebelum / sesudah (garis bisa digeser) =================
class ComparePreview(c: Context, private val base: Bitmap) : View(c) {
    private var processed: Bitmap = base
    private var hold = false          // tahan = tampilkan asli penuh
    var split = 0.5f                   // posisi garis pemisah (0..1)
    private val clip = Path()
    private val rect = RectF()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setProcessed(b: Bitmap) { processed = b; invalidate() }
    fun setHold(on: Boolean) { hold = on; invalidate() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (hold) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                split = (e.x / width).coerceIn(0.04f, 0.96f)
                invalidate()
            }
        }
        return true
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        rect.set(0f, 0f, w, h)
        clip.reset()
        clip.addRoundRect(rect, context.pxf(14f), context.pxf(14f), Path.Direction.CW)
        cv.save()
        cv.clipPath(clip)
        if (hold) {
            cv.drawBitmap(base, null, rect, paint)
        } else {
            cv.drawBitmap(processed, null, rect, paint)
            cv.save()
            cv.clipRect(0f, 0f, w * split, h)
            cv.drawBitmap(base, null, rect, paint)
            cv.restore()
            val x = w * split
            line.color = Color.WHITE
            line.strokeWidth = context.pxf(2f)
            cv.drawLine(x, 0f, x, h, line)
            val r = context.pxf(16f)
            line.color = Color.argb(230, 15, 30, 50)
            cv.drawCircle(x, h / 2f, r, line)
            line.style = Paint.Style.STROKE
            line.color = Hud.cyan
            line.strokeWidth = context.pxf(2f)
            cv.drawCircle(x, h / 2f, r, line)
            line.style = Paint.Style.FILL
            label.textSize = context.pxf(11f)
            label.typeface = Typeface.DEFAULT_BOLD
            label.color = Color.WHITE
            label.textAlign = Paint.Align.LEFT
            cv.drawText("SEBELUM", context.pxf(10f), context.pxf(20f), label)
            label.textAlign = Paint.Align.RIGHT
            cv.drawText("SESUDAH", w - context.pxf(10f), context.pxf(20f), label)
        }
        cv.restore()
    }
}

// ================= Panel Detail Tekstur: kiri = gambar + tombol, kanan = pengaturan =================
class TexturePanel(private val a: MainActivity, private val pkg: String) {
    private val store = a.store
    private val ctx: Context = a
    val root: LinearLayout = LinearLayout(a)

    private val base = buildScene()
    private var level = (store.get(Texture.levelKey(pkg)).toIntOrNull()
        ?: GpuDetect.profile(store.get("dev_gpu").ifBlank { "UNKNOWN" }).level).coerceIn(0, 8)
    private var sharpOn = store.get(Texture.KEY_SHARP) == "1"
    private var mipOn = store.get(Texture.KEY_MIP) == "1"

    private val compare = ComparePreview(a, base)
    private val valueLbl = TextView(a)
    private val levelLbls = ArrayList<TextView>()
    private val codeDetail = TextView(a)
    private val codePiksel = TextView(a)
    private val codeBatas = TextView(a)
    private val status = TextView(a)
    private val angleStatus = TextView(a)

    private fun px(v: Int) = a.px(v)
    private fun dim(alpha: Int = 190) = Color.argb(alpha, 170, 185, 205)

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(a)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        return v
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(a)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(px(12), px(10), px(12), px(10))
        c.background = Hud.rounded(Color.argb(235, 14, 22, 38), Color.argb(70, 255, 255, 255), ctx.pxf(14f), 1f)
        return c
    }

    private fun button(text: String, primary: Boolean = false, onClick: () -> Unit): TextView {
        val b = tv(text, 13f, if (primary) Color.parseColor("#04141F") else Color.WHITE, true)
        b.gravity = Gravity.CENTER
        b.setPadding(px(8), px(11), px(8), px(11))
        b.background = if (primary) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(12f), 1f)
        else Hud.rounded(Color.argb(120, 30, 45, 70), Color.argb(70, 255, 255, 255), ctx.pxf(12f), 1f)
        b.setOnClickListener { Sfx.tap(); onClick() }
        return b
    }

    private fun sw(label: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(tv(label, 13f), LinearLayout.LayoutParams(0, -2, 1f))
        val s = Switch(a)
        s.isChecked = checked
        s.setOnCheckedChangeListener { _, v -> onChange(v) }
        row.addView(s)
        return row
    }

    // tampilkan kode tiap bagian secara terpisah + pratinjau
    private fun refresh() {
        compare.setProcessed(processScene(base, level, sharpOn, mipOn))
        valueLbl.text = Texture.NAMES[level]
        for ((i, t) in levelLbls.withIndex()) t.setTextColor(if (i == level) Hud.cyan else dim(170))
        codeDetail.text = "Detail : " + Texture.detailFeat(level.toString()).ifEmpty { "(tidak ada)" }
        codePiksel.text = "Piksel : " + Texture.pikselFeat(sharpOn).ifEmpty { "(mati)" }
        codeBatas.text = "Batas  : " + Texture.batasFeat(mipOn).ifEmpty { "(mati)" }
    }

    private fun requireSupport(): Boolean {
        if (!Texture.supported()) {
            android.widget.Toast.makeText(a, Texture.unsupportedMsg(), android.widget.Toast.LENGTH_LONG).show()
            return false
        }
        return true
    }

    private fun runCmd(cmd: String, msg: String) {
        if (!requireSupport()) return
        status.text = "Menerapkan..."
        Thread {
            Access.run(cmd)
            // force-stop game yang sedang dipilih (bukan hardcoded FF)
            if (pkg.isNotBlank() && pkg != "global") Access.run("am force-stop $pkg")
            a.runOnUiThread { status.text = msg; refreshStatus() }
        }.start()
    }

    // --- Cek apakah texture aktif sekarang di sistem ---
    private fun refreshStatus() {
        Thread {
            val out = Access.run(Texture.STATUS_CMD)
            val lv  = Texture.detectLevel(out)
            val feat = out.lines()
                .firstOrNull { it.startsWith("FEATURE OVERRIDES ENABLED:") }
                ?.substringAfter(":") ?.trim() ?: ""
            val active = feat.isNotBlank() && feat != "null"
            a.runOnUiThread {
                status.setTextColor(if (active) android.graphics.Color.parseColor("#38E8A5")
                                    else dim())
                status.text = if (active) "✓ Aktif: $lv  |  $feat"
                              else "○ Tidak aktif / belum diterapkan"
            }
        }.start()
    }

    private fun save() {
        if (!requireSupport()) return
        if (store.get(Texture.KEY_ANGLE_ACTIVE) != "1") {
            android.widget.Toast.makeText(a, "Aktifkan ANGLE dulu: tekan Unlock ANGLE lalu Aktif ANGLE.", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        if (!Access.requires(a, "Detail Tekstur", false)) return
        store.put(Texture.levelKey(pkg), level.toString())
        store.put(Texture.KEY_SHARP, if (sharpOn) "1" else "0")
        store.put(Texture.KEY_MIP, if (mipOn) "1" else "0")
        store.put(Texture.KEY_APPLIED, "1")
        AutoReset.flag(a)
        val gameName = pkg.substringAfterLast(".")
        runCmd(Texture.applyCmd(level.toString(), sharpOn, mipOn),
            "✓ Tersimpan untuk $gameName — tutup & buka game lagi.")
    }

    private fun reset() {
        if (!requireSupport()) return
        if (!Access.requires(a, "Detail Tekstur", false)) return
        level = 0; sharpOn = false; mipOn = false
        store.put(Texture.levelKey(pkg), "0")
        store.put(Texture.KEY_SHARP, "0")
        store.put(Texture.KEY_MIP, "0")
        store.put(Texture.KEY_APPLIED, "")
        refresh()
        runCmd(Texture.resetCmd(), "✓ Dikembalikan ke asli.")
    }

    // ---- Preset cepat ----
    // Smooth   : LV2 halus, tanpa filter (HP kuat, visual jernih)
    private fun presetSmooth() {
        if (!requireSupport()) return
        level = 2; sharpOn = false; mipOn = false; refresh(); save()
    }
    // Balanced : LV4 + piksel tajam (mid-range, keseimbangan)
    private fun presetBalanced() {
        if (!requireSupport()) return
        level = 4; sharpOn = true; mipOn = false; refresh(); save()
    }
    // Performance: LV6 + semua filter (HP lemah, performa prioritas)
    private fun presetPerformance() {
        if (!requireSupport()) return
        level = 6; sharpOn = true; mipOn = true; refresh(); save()
    }
    // Extrem: LV7 + semua filter
    private fun extreme(withFilters: Boolean) {
        if (!requireSupport()) return
        level = 7; sharpOn = withFilters; mipOn = withFilters; refresh(); save()
    }
    // Max: LV8 + semua filter = resolusi paling rendah, performa paling tinggi
    private fun presetMax() {
        if (!requireSupport()) return
        level = 8; sharpOn = true; mipOn = true; refresh(); save()
    }
    // Auto: level sesuai deteksi GPU HP
    private fun presetAuto() {
        if (!requireSupport()) return
        level = Texture.autoLevel(); sharpOn = false; mipOn = false; refresh(); save()
    }

    private fun refreshAngle() {
        val unlocked = store.get(Texture.KEY_ANGLE_UNLOCK) == "1"
        val active = store.get(Texture.KEY_ANGLE_ACTIVE) == "1"
        angleStatus.setTextColor(if (active) Color.parseColor("#38E8A5") else Color.parseColor("#FFB740"))
        angleStatus.text = when {
            active -> "✓ ANGLE aktif. Texture siap dipakai."
            unlocked -> "🔓 ANGLE sudah di-unlock. Sekarang tekan \"Aktif ANGLE\"."
            else -> "○ Tekan \"Unlock ANGLE\" lalu \"Aktif ANGLE\" dulu."
        }
    }

    private fun unlockAngle() {
        if (!requireSupport()) return
        if (!Access.requires(a, "ANGLE", false)) return
        store.put(Texture.KEY_ANGLE_UNLOCK, "1")
        runCmd(Texture.UNLOCK_ANGLE_CMD, "✓ ANGLE di-unlock.")
        refreshAngle()
    }

    private fun activateAngle() {
        if (!requireSupport()) return
        if (store.get(Texture.KEY_ANGLE_UNLOCK) != "1") {
            android.widget.Toast.makeText(a, "Unlock ANGLE dulu.", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        if (!Access.requires(a, "ANGLE", false)) return
        store.put(Texture.KEY_ANGLE_ACTIVE, "1")
        runCmd(Texture.ACTIVATE_ANGLE_CMD, "✓ ANGLE aktif.")
        refreshAngle()
    }

    private fun column(): LinearLayout {
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        return col
    }

    private fun scroll(child: View): ScrollView {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(child)
        return sv
    }

    init {
        root.orientation = LinearLayout.HORIZONTAL
        root.setPadding(px(8), px(8), px(8), px(8))

        // ================= KIRI: gambar + tombol di bawahnya =================
        val left = column()

        // ---- cek dukungan HP (dari hasil deteksi perangkat) ----
        val angleTxt = store.get("dev_angle")
        val reason = when {
            !Texture.supported() -> Texture.unsupportedMsg()
            angleTxt.startsWith("tidak ditemukan") -> "Android anda ga support"
            else -> null
        }
        if (reason != null) {
            val notice = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(px(12), px(10), px(8), px(10))
                background = Hud.rounded(Color.argb(230, 90, 40, 20), Color.argb(200, 255, 170, 60), ctx.pxf(12f), 1.2f)
            }
            notice.addView(tv("⚠  $reason", 11f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
            val close = tv("✕", 16f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(px(10), px(2), px(10), px(2))
                setOnClickListener { Sfx.tap(); notice.visibility = View.GONE }
            }
            notice.addView(close)
            left.addView(notice, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(10) })
        }
        val c1 = card()
        c1.addView(tv("Pratinjau", 15f, Color.WHITE, true))
        c1.addView(compare, LinearLayout.LayoutParams(-1, px(190)).also { it.topMargin = px(8) })
        c1.addView(tv("Geser garis untuk bandingkan. Sebelum di kiri, sesudah di kanan.", 10f, dim())
            .also { it.setPadding(0, px(6), 0, 0) })
        val hold = button("Tahan: Sebelum") { }
        hold.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> compare.setHold(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> compare.setHold(false)
            }
            true
        }
        c1.addView(hold, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })
        left.addView(c1, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(10) })

        // ---- Langkah 1: unlock & aktifkan ANGLE (wajib sebelum texture) ----
        val cA = card()
        cA.addView(tv("Langkah 1 · ANGLE", 12f, Hud.cyan, true),
            LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(8) })
        val angRow = LinearLayout(a)
        angRow.orientation = LinearLayout.HORIZONTAL
        angRow.addView(button("🔓 Unlock ANGLE") { unlockAngle() },
            LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = px(6) })
        angRow.addView(button("⚡ Aktif ANGLE", true) { activateAngle() },
            LinearLayout.LayoutParams(0, -2, 1f))
        cA.addView(angRow, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(6) })
        angleStatus.textSize = 10f
        cA.addView(angleStatus)
        left.addView(cA, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(10) })
        refreshAngle()

        // ---- Preset cepat ----
        val c2 = card()
        c2.addView(tv("Preset Cepat", 12f, Hud.cyan, true),
            LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(8) })

        // baris 1: Smooth | Balanced
        val preRow1 = LinearLayout(a)
        preRow1.orientation = LinearLayout.HORIZONTAL
        preRow1.addView(button("⚡ Smooth") { presetSmooth() },
            LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = px(6) })
        preRow1.addView(button("⚖ Balanced") { presetBalanced() },
            LinearLayout.LayoutParams(0, -2, 1f))
        c2.addView(preRow1, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(6) })

        // baris 2: Performance | Auto GPU
        val preRow2 = LinearLayout(a)
        preRow2.orientation = LinearLayout.HORIZONTAL
        preRow2.addView(button("🔥 Performance") { presetPerformance() },
            LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = px(6) })
        preRow2.addView(button("🤖 Auto GPU") { presetAuto() },
            LinearLayout.LayoutParams(0, -2, 1f))
        c2.addView(preRow2, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(6) })

        // baris 3: Extrem LV7 | Max LV8
        val preRow3 = LinearLayout(a)
        preRow3.orientation = LinearLayout.HORIZONTAL
        preRow3.addView(button("💀 Extrem LV7") { extreme(true) },
            LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = px(6) })
        preRow3.addView(button("☠ Max LV8", true) { presetMax() },
            LinearLayout.LayoutParams(0, -2, 1f))
        c2.addView(preRow3, LinearLayout.LayoutParams(-1, -2))

        left.addView(c2, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(10) })

        // ---- Status aktif ----
        val c2b = card()
        c2b.addView(tv("Status Tekstur Aktif", 12f, Color.WHITE, true))
        status.textSize = 10f
        status.setTextColor(dim())
        status.text = "Ketuk 'Cek Status' untuk memeriksa..."
        c2b.addView(status, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(4); it.bottomMargin = px(6) })
        c2b.addView(button("🔍 Cek Status") { refreshStatus() },
            LinearLayout.LayoutParams(-1, -2))
        left.addView(c2b, LinearLayout.LayoutParams(-1, -2))

        // ================= KANAN: pengaturan texture =================
        val right = column()

        val c3 = card()
        val head = LinearLayout(a)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("Detail Tekstur", 14f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        valueLbl.textSize = 13f
        valueLbl.setTextColor(Hud.cyan)
        head.addView(valueLbl)
        c3.addView(head)
        val seek = SeekBar(a)
        seek.max = Texture.NAMES.size - 1
        seek.progress = level
        seek.progressTintList = android.content.res.ColorStateList.valueOf(Hud.cyan)
        seek.thumbTintList = android.content.res.ColorStateList.valueOf(Hud.cyan)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) { level = p; refresh() }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        c3.addView(seek, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(4) })
        val labels = LinearLayout(a)
        labels.orientation = LinearLayout.HORIZONTAL
        for ((i, n) in Texture.NAMES.withIndex()) {
            val t = tv(n, 9f, dim(170))
            t.gravity = Gravity.CENTER
            levelLbls.add(t)
            labels.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        c3.addView(labels)
        right.addView(c3, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(10) })

        val c4 = card()
        c4.addView(sw("Piksel Tajam", sharpOn) { v -> sharpOn = v; refresh() })
        c4.addView(tv("Tepi kotak-kotak. Matikan untuk buram halus.", 10f, dim())
            .also { it.setPadding(0, px(2), 0, px(8)) })
        c4.addView(sw("Batas Jarak Tegas", mipOn) { v -> mipOn = v; refresh() })
        c4.addView(tv("Detail dekat-jauh jadi patah-patah.", 10f, dim())
            .also { it.setPadding(0, px(2), 0, 0) })
        right.addView(c4, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(10) })

        val c5 = card()
        c5.addView(tv("Kode perintah", 13f, Color.WHITE, true))
        for (v in listOf(codeDetail, codePiksel, codeBatas)) {
            v.textSize = 10f
            v.typeface = Typeface.MONOSPACE
            v.setTextColor(Color.argb(220, 200, 235, 255))
            v.setTextIsSelectable(true)
        }
        c5.addView(codeDetail, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(6) })
        c5.addView(codePiksel, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(3) })
        c5.addView(codeBatas, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(3) })
        right.addView(c5, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(10) })

        right.addView(button("💾 Simpan", true) { save() }, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(8) })
        right.addView(button("↺ Reset ke asli") { reset() }, LinearLayout.LayoutParams(-1, -2))

        root.addView(scroll(left), LinearLayout.LayoutParams(0, -1, 0.5f).also { it.rightMargin = px(6) })
        root.addView(scroll(right), LinearLayout.LayoutParams(0, -1, 0.5f))

        refresh()
    }
}
