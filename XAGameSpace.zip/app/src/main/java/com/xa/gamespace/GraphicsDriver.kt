package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.HorizontalScrollView
import android.widget.Toast

// Info driver grafik sistem lengkap. Bagian dasar bisa dibaca tanpa root.
// Bagian ANGLE dan SurfaceFlinger butuh Shizuku atau root.
object GraphicsDriver {
    private fun prop(k: String): String = try {
        Runtime.getRuntime().exec(arrayOf("getprop", k)).inputStream.bufferedReader().readText().trim().ifBlank { "-" }
    } catch (e: Exception) { "-" }

    fun collect(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        out.add("SoC" to prop("ro.soc.model").let { if (it == "-") prop("ro.board.platform") else it })
        out.add("Board" to prop("ro.board.platform"))
        out.add("Hardware" to prop("ro.hardware"))
        out.add("EGL driver" to prop("ro.hardware.egl"))
        out.add("Vulkan HAL" to prop("ro.hardware.vulkan"))
        out.add("OpenGL ES" to prop("ro.opengles.version"))
        out.add("Renderer HWUI" to prop("debug.hwui.renderer"))
        out.add("Hwui pipeline" to prop("ro.hwui.use_vulkan"))
        out.add("Build" to prop("ro.build.display.id"))
        if (Access.hasAny()) {
            val sh = Access.run(
                "cat /sys/class/kgsl/kgsl-3d0/gpu_model 2>/dev/null; " +
                    "settings get global angle_gl_driver_all_angle; " +
                    "settings get global angle_egl_features; " +
                    "dumpsys SurfaceFlinger 2>/dev/null | grep -i -E 'GLES|Vulkan' | head -n 4"
            ).lines().map { it.trim() }.filter { it.isNotBlank() }
            out.add("GPU model" to (sh.getOrNull(0) ?: "-"))
            out.add("ANGLE semua app" to (sh.getOrNull(1) ?: "-"))
            out.add("ANGLE fitur" to (sh.getOrNull(2) ?: "-"))
            for ((i, line) in sh.drop(3).withIndex()) out.add("SurfaceFlinger ${i + 1}" to line)
        } else {
            out.add("GPU model / ANGLE / SurfaceFlinger" to "butuh Shizuku atau root")
        }
        return out
    }
}

// Mode driver grafis. value = nilai yang ditulis ke settings ANGLE per aplikasi (null = kembali ke default).
enum class DriverMode(val label: String, val desc: String, val value: String?) {
    DEFAULT("Default", "Pengaturan bawaan sistem untuk aplikasi ini", null),
    SYSTEM("Driver Grafis Sistem", "Pakai driver GPU bawaan HP, tanpa lapisan ANGLE", "native"),
    ANGLE("ANGLE", "OpenGL diterjemahkan ke Vulkan, kadang lebih stabil", "angle"),
    GAME("Game Driver", "Driver game terbaru (prerelease) bila tersedia di ROM", "prerelease"),
}

class DriverSheet(private val ctx: Context, private val store: Store, private val onClose: () -> Unit) {
    private val content = LinearLayout(ctx)
    // seluruh panel bisa digulir (sebelumnya bagian bawah terpotong)
    val root = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; addView(content) }
    // game yang dipilih di panel ini (tidak bergantung pada game yang sedang di-Start)
    private var picked: String? = store.game
    private val gameBox = LinearLayout(ctx)
    private val statusTv = TextView(ctx)
    private val scopeBox = LinearLayout(ctx)
    private val modeBox = LinearLayout(ctx)
    private val infoBody = LinearLayout(ctx)
    private var allApps = store.game.isNullOrBlank()
    private var current: DriverMode = DriverMode.DEFAULT
    private var busy = false

    private fun px(v: Int) = ctx.px(v)

    private fun pkgLabel(pkg: String): String = try {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    // ---- baca / tulis settings (butuh root atau Shizuku) ----
    private fun readSetting(key: String): String =
        Access.run("settings get global $key").lines().map { it.trim() }
            .lastOrNull { it.isNotEmpty() }?.takeIf { it != "null" } ?: ""

    private fun readList(key: String): MutableList<String> {
        val s = readSetting(key)
        return if (s.isEmpty()) mutableListOf() else s.split(",").map { it.trim() }.toMutableList()
    }

    private fun readMode(): DriverMode {
        if (allApps) return if (readSetting("angle_gl_driver_all_angle") == "1") DriverMode.ANGLE else DriverMode.DEFAULT
        val pkg = picked ?: return DriverMode.DEFAULT
        val pkgs = readList("angle_gl_driver_selection_pkgs")
        val vals = readList("angle_gl_driver_selection_values")
        val i = pkgs.indexOf(pkg)
        if (i < 0 || i >= vals.size) return DriverMode.DEFAULT
        return DriverMode.values().firstOrNull { it.value == vals[i] } ?: DriverMode.DEFAULT
    }

    private fun setPkgDriver(pkg: String, value: String?) {
        val pkgs = readList("angle_gl_driver_selection_pkgs")
        val vals = readList("angle_gl_driver_selection_values")
        while (vals.size < pkgs.size) vals.add("default")
        val i = pkgs.indexOf(pkg)
        if (i >= 0) { pkgs.removeAt(i); vals.removeAt(i) }
        if (value != null) { pkgs.add(pkg); vals.add(value) }
        if (pkgs.isEmpty()) {
            Access.run("settings delete global angle_gl_driver_selection_pkgs; settings delete global angle_gl_driver_selection_values")
        } else {
            Access.run(
                "settings put global angle_gl_driver_selection_pkgs '${pkgs.joinToString(",")}'; " +
                    "settings put global angle_gl_driver_selection_values '${vals.joinToString(",")}'"
            )
        }
    }

    private fun applyMode(m: DriverMode) {
        if (busy) return
        if (!Access.requires(ctx, "Driver grafis", false)) return
        busy = true
        Sfx.tap()
        Thread {
            val pkg = picked
            if (allApps || pkg == null) {
                Access.run("settings put global angle_gl_driver_all_angle ${if (m == DriverMode.ANGLE) 1 else 0}")
            } else {
                setPkgDriver(pkg, m.value)
            }
            val now = readMode()
            body(now)
        }.start()
    }

    private fun body(now: DriverMode) {
        root.post {
            busy = false
            current = now
            refresh()
            Toast.makeText(ctx, "Driver aktif: ${now.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadCurrent() {
        Thread {
            val m = if (Access.hasAny()) readMode() else DriverMode.DEFAULT
            root.post { current = m; refresh() }
        }.start()
    }

    private fun loadInfo() {
        infoBody.removeAllViews()
        Thread {
            val rows = GraphicsDriver.collect()
            infoBody.post {
                infoBody.removeAllViews()
                for ((k, v) in rows) {
                    infoBody.addView(TextView(ctx).apply {
                        text = "$k\n$v"
                        textSize = 11f
                        setTextColor(Color.argb(235, 220, 240, 255))
                        typeface = Typeface.MONOSPACE
                        setPadding(0, px(5), 0, px(5))
                    })
                }
            }
        }.start()
    }

    private fun tile(title: String, sub: String, selected: Boolean, onTap: () -> Unit): LinearLayout =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(12), px(10), px(12), px(10))
            background = Hud.rounded(
                if (selected) Color.argb(120, 40, 150, 220) else Color.argb(60, 255, 255, 255),
                if (selected) Hud.neon else Color.argb(50, 255, 255, 255),
                ctx.pxf(10f),
                if (selected) 1.6f else 1f
            )
            addView(TextView(ctx).apply {
                text = (if (selected) "✓  " else "") + title
                textSize = 13f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            })
            if (sub.isNotEmpty()) addView(TextView(ctx).apply {
                text = sub
                textSize = 10f
                setTextColor(Hud.sub)
            })
            setOnClickListener { Sfx.tap(); onTap() }
        }

    private fun buildGameChips() {
        gameBox.removeAllViews()
        val apps = try { Games.detect(ctx) } catch (e: Exception) { emptyList() }
        if (apps.isEmpty()) {
            gameBox.addView(TextView(ctx).apply { text = "Tidak ada game terdeteksi"; textSize = 10f; setTextColor(Hud.sub) })
            return
        }
        for (g in apps) {
            val sel = !allApps && g.pkg == picked
            gameBox.addView(TextView(ctx).apply {
                text = g.label
                textSize = 11f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (sel) Color.parseColor("#04141F") else Color.WHITE)
                setPadding(px(12), px(7), px(12), px(7))
                background = Hud.rounded(
                    if (sel) Hud.neon else Color.argb(60, 255, 255, 255),
                    if (sel) Hud.neon else Color.argb(50, 255, 255, 255),
                    ctx.pxf(14f), 1f
                )
                setOnClickListener { Sfx.tap(); picked = g.pkg; allApps = false; buildGameChips(); loadCurrent() }
            }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(6) })
        }
    }

    private fun refresh() {
        val scopeName = if (allApps) "semua aplikasi" else (picked?.let { pkgLabel(it) } ?: "-")
        statusTv.text = "Aktif: ${current.label} · $scopeName"

        scopeBox.removeAllViews()
        val pickedOk = picked != null
        val gameTile = tile(
            "Game dipilih",
            if (pickedOk) pkgLabel(picked!!) else "pilih dari daftar di bawah",
            !allApps && pickedOk
        ) { if (pickedOk) { allApps = false; buildGameChips(); loadCurrent() } }
        val allTile = tile("Semua aplikasi", "berlaku global", allApps) { allApps = true; buildGameChips(); loadCurrent() }
        scopeBox.addView(gameTile, LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(0, 0, px(4), 0) })
        scopeBox.addView(allTile, LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(px(4), 0, 0, 0) })

        modeBox.removeAllViews()
        for (m in DriverMode.values()) {
            modeBox.addView(
                tile(m.label, m.desc, m == current) { applyMode(m) },
                LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(6) }
            )
        }
    }

    init {
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(px(14), px(12), px(14), px(12))
        content.background = Hud.rounded(Color.argb(240, 8, 22, 42), Hud.neon, ctx.pxf(14f), 1.4f)
        content.addView(TextView(ctx).apply {
            text = "DRIVER GRAFIK"
            textSize = 13f
            setTextColor(Hud.neon)
            typeface = Typeface.DEFAULT_BOLD
        })
        statusTv.apply { textSize = 11f; setTextColor(Color.WHITE); setPadding(0, px(4), 0, px(6)) }
        content.addView(statusTv)

        scopeBox.orientation = LinearLayout.HORIZONTAL
        content.addView(scopeBox, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(6) })
        gameBox.orientation = LinearLayout.HORIZONTAL
        val gameScroll = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(gameBox) }
        content.addView(gameScroll, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(6) })

        modeBox.orientation = LinearLayout.VERTICAL
        content.addView(modeBox, LinearLayout.LayoutParams(-1, -2))

        infoBody.orientation = LinearLayout.VERTICAL
        content.addView(TextView(ctx).apply {
            text = "INFO SISTEM"
            textSize = 10f
            setTextColor(Hud.sub)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, px(8), 0, 0)
        })
        content.addView(infoBody, LinearLayout.LayoutParams(-1, -2))

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(TextView(ctx).apply {
            text = "SEGARKAN"; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(px(12), px(8), px(12), px(8))
            background = Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
            setOnClickListener { Sfx.tap(); loadCurrent(); loadInfo() }
        }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(8) })
        row.addView(TextView(ctx).apply {
            text = "TUTUP"; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(px(12), px(8), px(12), px(8))
            background = Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
            setOnClickListener { Sfx.tap(); onClose() }
        }, LinearLayout.LayoutParams(-2, -2))
        content.addView(row, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(10) })

        buildGameChips()
        refresh()
        loadCurrent()
        loadInfo()
    }
}
