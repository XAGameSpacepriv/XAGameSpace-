package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

// Pengubahan Fitur: pilih fungsi untuk tile Touch dan tile Clear RAM.
object Remap {

    fun ramIsFilter(s: Store) = s.get("remap_ram") == "filter"

    // isi tile Touch: "" = Touch (default), "thermal", atau "macro"
    fun touchMode(s: Store): String = s.get("remap_touch")
}

class RemapSheet(private val ctx: Context, private val onChange: () -> Unit, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val s = Store(ctx)
    private val touchChips = ArrayList<Pair<TextView, String>>()
    private val ramChips = ArrayList<Pair<TextView, String>>()

    private fun chip(text: String): TextView = TextView(ctx).apply {
        this.text = text; textSize = 10f; gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD; isSingleLine = true
        setPadding(ctx.px(6), ctx.px(8), ctx.px(6), ctx.px(8))
    }

    private fun paint(c: TextView, on: Boolean) {
        c.setTextColor(if (on) Color.parseColor("#04141F") else Color.WHITE)
        c.background = if (on) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(10f), 1f)
        else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
    }

    private fun row(label: String, opts: List<Pair<String, String>>, key: String, list: ArrayList<Pair<TextView, String>>): LinearLayout {
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(ctx).apply { text = label; textSize = 11f; setTextColor(Hud.neon); typeface = Typeface.DEFAULT_BOLD })
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        for ((txt, value) in opts) {
            val c = chip(txt)
            list.add(c to value)
            c.setOnClickListener {
                Sfx.tap()
                s.put(key, value)
                refreshAll()
                onChange()
            }
            r.addView(c, LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(0, ctx.px(4), ctx.px(4), 0) })
        }
        col.addView(r)
        return col
    }

    private fun refreshAll() {
        val t = s.get("remap_touch")
        for ((c, v) in touchChips) paint(c, v == t)
        val r = s.get("remap_ram")
        for ((c, v) in ramChips) paint(c, v == r)
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(ctx.px(16), ctx.px(14), ctx.px(16), ctx.px(14))
        root.background = Hud.rounded(Color.argb(240, 8, 22, 42), Hud.neon, ctx.pxf(14f), 1.4f)
        root.addView(TextView(ctx).apply {
            text = "PENGUBAHAN FITUR"; textSize = 13f; setTextColor(Hud.neon); typeface = Typeface.DEFAULT_BOLD
        })

        root.addView(row("Tile TOUCH jadi:", listOf("Touch" to "", "Thermal" to "thermal"), "remap_touch", touchChips))
        root.addView(row("Tile CLEAR RAM jadi:", listOf("Clear RAM" to "", "Filter Layar" to "filter"), "remap_ram", ramChips))
        refreshAll()
        root.addView(TextView(ctx).apply {
            text = "TUTUP"; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(ctx.px(12), ctx.px(6), ctx.px(12), ctx.px(6))
            background = Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
            setOnClickListener { Sfx.tap(); onClose() }
        }, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = ctx.px(10); it.gravity = Gravity.END })
    }
}
