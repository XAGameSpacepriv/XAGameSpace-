package com.xa.gamespace

// Model macro: disalin dari XAGameSpacepanel (model/BoosterModels.kt)

enum class MacroPattern(val label: String) {
    REPEAT("Repeat"),
    BURST("Burst"),
    HOLD("Hold"),
    SWIPE("Swipe"),
    QUICK_SWITCH("1→2 Senjata")
}

enum class MacroInjectionMode(val label: String, val subtitle: String) {
    SMART_POINTER("Smart 10-Jari", "Otomatis Kernel Slot-9 / Direct Touch anti-mouse"),
    STYLUS_HYBRID("Stylus Hybrid", "Simulasi stylus (pointer terpisah)"),
    TOUCHSCREEN_DIRECT("Touch Direct", "Hardware device touchscreen langsung")
}

data class MacroConfig(
    val enabled: Boolean = false,
    val pattern: MacroPattern = MacroPattern.REPEAT,
    val injectionMode: MacroInjectionMode = MacroInjectionMode.SMART_POINTER,
    val triggerScale: Float = 1.0f,
    val intervalMs: Int = 150,
    val holdDurationMs: Int = 35,
    val randomJitterPx: Int = 0,
    val burstCount: Int = 3,
    val showTarget: Boolean = true,
    val triggerNormX: Float = 0.22f,
    val triggerNormY: Float = 0.62f,
    val targetNormX: Float = 0.48f,
    val targetNormY: Float = 0.56f,
    val enableTarget2: Boolean = false,
    val target2NormX: Float = 0.68f,
    val target2NormY: Float = 0.36f,
    val switchDelayMs: Int = 120,
    val isLocked: Boolean = false,
    val holdToTrigger: Boolean = true,
    val lockedOpacity: Float = 0.30f,
    val isRunning: Boolean = false
)

data class ShizukuStatus(
    val isInstalled: Boolean = false,
    val isRunning: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val apiVersion: Int = 0,
    val isRootAvailable: Boolean = false,
    val isInputServiceBound: Boolean = false,
    val autoPermissionsApplied: Boolean = false,
    val isKernelMultiTouch: Boolean = false,
    val activeEngineLabel: String = ""
) {
    val canRunPrivileged: Boolean
        get() = (isRunning && isPermissionGranted) || isRootAvailable
}
