package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView

class ShellPanel(private val a: MainActivity) {
    private val u = a.u
    val root: LinearLayout = u.vbox()
    private val box = u.vbox()
    private val input = EditText(a)
    private val out = TextView(a)

    // ════════════════════════════════════════════
    // BERSIH CACHE
    // ════════════════════════════════════════════
    private val CLEAN = """rm -rf /data/dalvik-cache/* 2>/dev/null||true
rm -rf /data/anr/* 2>/dev/null||true
rm -f /data/local/tmp/*.log 2>/dev/null||true
rm -rf /sdcard/UnityAdsVideoCache 2>/dev/null||true
su -c "rm -rf /data/media/0/DCIM/.thumbnails" 2>/dev/null||true
su -c "rm -rf /data/media/0/Pictures/.thumbnails" 2>/dev/null||true
su -c "rm -rf /data/cache/*" 2>/dev/null||true
su -c "rm -rf /data/tombstones/*" 2>/dev/null||true
su -c "rm -rf /data/system/dropbox/*" 2>/dev/null||true"""

    // ════════════════════════════════════════════
    // MODULE TEXTURE LOW (ANGLE) — Android 12+
    // ════════════════════════════════════════════
    private fun texCmd(level: String): String {
        val f = "forceNearestFiltering:forceNearestMipFiltering:forceTextureLodOffset$level"
        // Semua $ shell di-escape dengan \$ agar tidak dikira Kotlin string interpolation
        return """
$CLEAN
# ── Aktifkan ANGLE driver (semua Android 11-15) ──
settings put --user 0 global angle_gl_driver_all_angle 1
setprop debug.angle.rules /data/local/tmp/a4a_rules.json 2>/dev/null||true
setprop debug.angle.libs.suffix libEGL_angle.so 2>/dev/null||true
setprop debug.angle.markers 1 2>/dev/null||true
setprop debug.angle.validation false 2>/dev/null||true
su -c resetprop -n persist.graphics.vulkan.disable false 2>/dev/null||true
su -c resetprop -n ro.hwui.use_vulkan true 2>/dev/null||true
device_config put gpu android.os.enable_angle_allow_list true 2>/dev/null||true
su -c device_config put gpu android.os.enable_angle_allow_list true 2>/dev/null||true
device_config put gpu android.provider.flags.angle_dynamic_denylist false 2>/dev/null||true
su -c device_config put gpu android.provider.flags.angle_dynamic_denylist false 2>/dev/null||true
# ── Feature overrides texture ──
settings put --user 0 global angle_egl_features '$f'
setprop debug.angle.feature_overrides_enabled '$f'
setprop debug.angle.feature_overrides_disabled ''
su -c resetprop -n ro.boot.hardware.angle_feature_overrides_enabled '$f' 2>/dev/null||true
su -c resetprop --delete ro.boot.hardware.angle_feature_overrides_disabled 2>/dev/null||true
device_config put gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides true 2>/dev/null||true
su -c device_config put gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides true 2>/dev/null||true
settings put --user 0 global force_gpu_rendering 1 2>/dev/null||true
settings put --user 0 global force_hw_ui 1 2>/dev/null||true
# ── Auto-deteksi versi Android & terapkan metode yang tepat ──
XA_API=${'$'}(getprop ro.build.version.sdk)
XA_AND=${'$'}(getprop ro.build.version.release | cut -d. -f1)
echo "Android ${'$'}XA_AND (API ${'$'}XA_API) terdeteksi"
if [ "${'$'}XA_API" -ge 30 ] && [ "${'$'}XA_API" -le 31 ]; then
  echo "Metode: Android 11-12"
  su -c resetprop -n debug.graphics.angle.developeroption.enable 1 2>/dev/null||true
  su -c resetprop -n ro.gfx.angle.supported true 2>/dev/null||true
  su -c resetprop -n persist.graphics.egl angle 2>/dev/null||true
  su -c resetprop -n ro.hardware.egl angle 2>/dev/null||true
  su -c resetprop -n ro.hardwareegl angle 2>/dev/null||true
  su -c resetprop -n ro.boot.hardware.egl angle 2>/dev/null||true
  setprop debug.hwui.use_gpu 1 2>/dev/null||true
  setprop debug.angle.backend 2 2>/dev/null||true
  XA_FPS=${'$'}(dumpsys display | grep -Eo 'fps=[0-9]+' | cut -d= -f2 | sort -n | tail -n1)
  for XA_PKG in ${'$'}(cmd package list packages -3 | cut -f2 -d:); do
    device_config put game_overlay "${'$'}XA_PKG" mode=2,fps=${'$'}XA_FPS,useAngle=true,downscaleFactor=-1.0 2>/dev/null||true
  done
elif [ "${'$'}XA_API" -ge 32 ] && [ "${'$'}XA_API" -le 33 ]; then
  echo "Metode: Android 12L-13"
  su -c resetprop -n debug.graphics.angle.developeroption.enable 1 2>/dev/null||true
  su -c resetprop -n ro.gfx.angle.supported true 2>/dev/null||true
  su -c resetprop -n persist.graphics.egl angle 2>/dev/null||true
  su -c resetprop -n ro.hardware.egl angle 2>/dev/null||true
  su -c resetprop -n ro.boot.hardware.egl angle 2>/dev/null||true
  XA_FPS=${'$'}(dumpsys display | grep -Eo 'fps=[0-9]+' | cut -d= -f2 | sort -n | tail -n1)
  for XA_PKG in ${'$'}(cmd package list packages -3 | cut -f2 -d:); do
    XA_UID=${'$'}(pm list packages -U | grep "^package:${'$'}XA_PKG " | sed -n 's/.*uid:\([0-9]*\).*/\1/p')
    [ -z "${'$'}XA_UID" ] && continue
    device_config put game_overlay "${'$'}XA_PKG" mode=2,fps=${'$'}XA_FPS,useAngle=true,downscaleFactor=-1.0,loadingBoost=1073741824 2>/dev/null||true
    device_config override game_overlay "${'$'}XA_PKG" mode=2,fps=${'$'}XA_FPS,useAngle=true,downscaleFactor=-1.0,loadingBoost=1073741824 2>/dev/null||true
    cmd game set --mode 2 --user 0 "${'$'}XA_PKG" 2>/dev/null||true
  done
elif [ "${'$'}XA_API" -ge 34 ]; then
  echo "Metode: Android 14-15"
  device_config put gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides true 2>/dev/null||true
  su -c device_config put gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides true 2>/dev/null||true
fi
echo "Texture LV$level selesai diterapkan"
""".trimIndent()
    }

    private fun texReset(): String {
        val f = "forceNearestFiltering:forceNearestMipFiltering"
        return buildString {
            appendLine(CLEAN)
            appendLine("settings put --user 0 global angle_gl_driver_all_angle 0")
            appendLine("settings delete --user 0 global angle_egl_features 2>/dev/null||true")
            appendLine("setprop debug.angle.feature_overrides_enabled ''")
            appendLine("setprop debug.angle.feature_overrides_disabled '$f'")
            appendLine("su -c resetprop --delete ro.boot.hardware.angle_feature_overrides_enabled 2>/dev/null||true")
            appendLine("su -c resetprop -n ro.boot.hardware.angle_feature_overrides_disabled '$f' 2>/dev/null||true")
            appendLine("device_config put gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides false 2>/dev/null||true")
            appendLine("su -c device_config put gpu com.android.graphics.graphicsenv.flags.angle_feature_overrides false 2>/dev/null||true")
            appendLine("su -c resetprop -n debug.graphics.angle.developeroption.enable 0 2>/dev/null||true")
            appendLine("setprop persist.graphics.egl '' 2>/dev/null||true")
            appendLine("settings put --user 0 global force_gpu_rendering 0 2>/dev/null||true")
            appendLine("settings put --user 0 global force_hw_ui 0 2>/dev/null||true")
        }.trimEnd()
    }

    // ════════════════════════════════════════════
    // SPOOF GPU ANGLE — dari module Spoof-Gpu-Angle
    // ════════════════════════════════════════════
    private val GLES_DETECT = """GLES_CODE=$(getprop ro.opengles.version)
case "${'$'}GLES_CODE" in
  196608) VERSI="3.0.0";; 196609) VERSI="3.1.0";; 196610) VERSI="3.2.0";;
  262144) VERSI="4.0.0";; 262145) VERSI="4.1.0";; 262146) VERSI="4.2.0";;
  262150) VERSI="4.6.0";; *) VERSI="3.2.0";;
esac"""

    private fun spoofCmd(vendor: String, renderer: String): String = buildString {
        appendLine("# Reset dulu ke stock")
        appendLine("setprop debug.angle.gl_vendor ''")
        appendLine("setprop debug.angle.gl_renderer ''")
        appendLine("setprop debug.gpu.fake_gpu_vendor ''")
        appendLine("setprop debug.gpu.fake_gpu_renderer ''")
        appendLine("setprop debug.angle.gl_version ''")
        appendLine("su -c resetprop -n debug.graphics.angle.developeroption.enable 1 2>/dev/null||true")
        appendLine("su -c resetprop -n ro.gfx.angle.supported true 2>/dev/null||true")
        appendLine("su -c resetprop -n persist.graphics.egl angle 2>/dev/null||true")
        appendLine("su -c resetprop -n ro.hardware.egl angle 2>/dev/null||true")
        appendLine("su -c resetprop -n ro.hardwareegl angle 2>/dev/null||true")
        appendLine("su -c resetprop -n ro.boot.hardware.egl angle 2>/dev/null||true")
        appendLine("# Set spoof")
        appendLine("setprop debug.angle.gl_vendor '$vendor'")
        appendLine("setprop debug.angle.gl_renderer '$renderer'")
        appendLine("setprop debug.gpu.fake_gpu_vendor '$vendor'")
        appendLine("setprop debug.gpu.fake_gpu_renderer '$renderer'")
        appendLine(GLES_DETECT)
        appendLine("[ -n \"\$VERSI\" ] && setprop debug.angle.gl_version \"OpenGL ES \$VERSI (ANGLE 2.1)\"")
    }.trimEnd()

    private fun spoofDisable(): String = buildString {
        appendLine("setprop debug.angle.gl_vendor ''")
        appendLine("setprop debug.angle.gl_renderer ''")
        appendLine("setprop debug.gpu.fake_gpu_vendor ''")
        appendLine("setprop debug.gpu.fake_gpu_renderer ''")
        appendLine("setprop debug.angle.gl_version ''")
        appendLine("su -c resetprop -n debug.graphics.angle.developeroption.enable 0 2>/dev/null||true")
        appendLine("setprop persist.graphics.egl '' 2>/dev/null||true")
        appendLine("su -c resetprop -n ro.hardware.egl \$(getprop debug.hardware.egl) 2>/dev/null||true")
        appendLine("su -c resetprop -n ro.hardwareegl \$(getprop debug.hardware.egl) 2>/dev/null||true")
        appendLine("su -c resetprop -n ro.boot.hardware.egl \$(getprop debug.hardware.egl) 2>/dev/null||true")
    }.trimEnd()

    // ════════════════════════════════════════════
    // PRESET LAIN
    // ════════════════════════════════════════════
    private data class Preset(val label: String, val cmd: String)
    private fun buildOtherPresets() = listOf(
        Preset("GPU Vsync ON",   RateCmd.gpuVsyncCmd(true)),
        Preset("GPU Vsync OFF",  RateCmd.gpuVsyncCmd(false)),
        Preset("Render 120 Hz", RateCmd.renderCmd("120")),
        Preset("Render Bawaan", RateCmd.renderDefaultCmd()),
        Preset("VSync 120",     RateCmd.vsyncFpsCmd("120")),
        Preset("Cek Status",    Texture.STATUS_CMD)
    )

    init {
        val sv = ScrollView(a); sv.isVerticalScrollBarEnabled = false; sv.addView(box)
        root.addView(sv, u.lp(-1, 0, 1f))
        draw()
    }

    private fun draw() {
        box.removeAllViews()

        // ── Label mode ──
        val api = Build.VERSION.SDK_INT
        val modeColor = when (Access.mode) {
            Access.Mode.ROOT    -> Color.parseColor("#00E5FF")
            Access.Mode.SHIZUKU -> Color.parseColor("#FFB300")
            Access.Mode.NONE    -> Color.RED
        }
        val modeTag = when (Access.mode) {
            Access.Mode.ROOT    -> "ROOT ✅"
            Access.Mode.SHIZUKU -> "SHIZUKU ⚡"
            Access.Mode.NONE    -> "Tidak ada akses ❌"
        }
        box.addView(u.label("Mode: $modeTag  |  Android API $api", 11f, modeColor, true), u.lp(b = 10))

        // ════════════════ SEKSI 1: TEXTURE LOW ════════════════
        box.addView(u.label("🎨  MODULE TEXTURE LOW — Android 15+", 12f, Color.WHITE, true), u.lp(b = 4))

        if (api < 35) {
            box.addView(u.label(
                "⚠️ Android kamu (API $api) belum support fitur ini. Butuh Android 15 (API 35) minimal.",
                10f, Color.parseColor("#FFB300")), u.lp(b = 10))
        } else {
            box.addView(u.label(
                "Root: permanen via resetprop. Shizuku: aktif per sesi — tutup & buka game setelah terapkan.",
                10f, Theme.sub), u.lp(b = 8))
            val texRow = u.hbox()
            listOf("1" to "LV 1", "2" to "LV 2", "3" to "LV 3", "4" to "⚡ LV 4 Ultra").forEach { (lv, label) ->
                texRow.addView(u.btn(label, lv == "4") { runTex(lv) }, u.lp(-2, -2, r = 8))
            }
            texRow.addView(u.btn("Reset") { runTexReset() })
            val ts = HorizontalScrollView(a); ts.isHorizontalScrollBarEnabled = false; ts.addView(texRow)
            box.addView(ts, u.lp(b = 14))
        }

        // ════════════════ SEKSI 2: SPOOF GPU ════════════════
        box.addView(u.label("🎮  SPOOF GPU ANGLE", 12f, Color.WHITE, true), u.lp(b = 4))
        box.addView(u.label("Spoof renderer GPU ke Adreno flagship. Butuh ROOT.", 10f, Theme.sub), u.lp(b = 8))
        val spoofRow = u.hbox()
        data class GpuSpoof(val label: String, val vendor: String, val renderer: String)
        listOf(
            GpuSpoof("Adreno 840",
                "Google Inc. (Qualcomm)",
                "ANGLE (Qualcomm, Vulkan 1.4.363 (Adreno (TM) 840 (0x90930010)), Adreno (TM) 840-512.502.0)"),
            GpuSpoof("Adreno 608",
                "Google Inc. (Qualcomm)",
                "ANGLE (Qualcomm, Vulkan 1.3.303 (Adreno (TM) 608 (0x90930010)), Adreno (TM) 608-512.502.0)"),
            GpuSpoof("Adreno 504",
                "Google Inc. (Qualcomm)",
                "ANGLE (Qualcomm, Vulkan 1.1.128 (Adreno (TM) 504), Adreno (TM) 504-512.502.0)"),
        ).forEach { g ->
            spoofRow.addView(u.btn(g.label) { run(spoofCmd(g.vendor, g.renderer), "Spoof ${g.label}") }, u.lp(-2, -2, r = 8))
        }
        spoofRow.addView(u.btn("Disable") { run(spoofDisable(), "Disable Spoof") })
        val ss = HorizontalScrollView(a); ss.isHorizontalScrollBarEnabled = false; ss.addView(spoofRow)
        box.addView(ss, u.lp(b = 14))

        // ════════════════ SEKSI 3: PRESET LAIN ════════════════
        box.addView(u.label("⚙️  PRESET LAIN", 12f, Color.WHITE, true), u.lp(b = 4))
        val otherRow = u.hbox()
        buildOtherPresets().forEach { p ->
            val t = u.label(p.label, 12f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(u.dp(12), u.dp(7), u.dp(12), u.dp(7))
            t.background = u.glass(20, Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255))
            t.setOnClickListener { run(p.cmd, p.label) }
            otherRow.addView(t, u.lp(-2, -2, r = 6))
        }
        val os = HorizontalScrollView(a); os.isHorizontalScrollBarEnabled = false; os.addView(otherRow)
        box.addView(os, u.lp(b = 14))

        // ════════════════ SEKSI 4: PERINTAH BEBAS ════════════════
        box.addView(u.label("💻  PERINTAH BEBAS", 12f, Color.WHITE, true), u.lp(b = 4))
        input.hint = "contoh: getprop debug.angle.feature_overrides_enabled"
        input.setHintTextColor(Color.argb(120, 255, 255, 255))
        input.setTextColor(Color.WHITE); input.textSize = 12f
        input.typeface = Typeface.MONOSPACE; input.minLines = 2
        input.gravity = Gravity.TOP or Gravity.START
        input.background = u.glass(12, Color.argb(120, 0, 0, 0), Color.argb(60, 255, 255, 255))
        input.setPadding(u.dp(10), u.dp(8), u.dp(10), u.dp(8))
        box.addView(input, u.lp(b = 8))
        val bar = u.hbox()
        bar.addView(u.btn("Jalankan", true) {
            val c = input.text.toString().trim(); if (c.isNotEmpty()) run(c, "Perintah")
        }, u.lp(-2, -2, r = 8))
        bar.addView(u.btn("Bersihkan") { out.text = ""; input.setText("") })
        box.addView(bar, u.lp(b = 10))
        out.textSize = 11f; out.typeface = Typeface.MONOSPACE
        out.setTextColor(Theme.sub); out.setTextIsSelectable(true)
        box.addView(out)
    }

    private fun runTex(level: String) {
        if (!Texture.supported()) { android.widget.Toast.makeText(a, Texture.unsupportedMsg(), android.widget.Toast.LENGTH_LONG).show(); return }
        if (!Access.hasAny()) { Access.requires(a, "Texture LV$level", false); return }
        val label = if (level == "4") "Texture LV4 Ultra Low" else "Texture LV$level"
        out.text = "Menerapkan $label..."
        Thread {
            val r = Access.run(texCmd(level))
            val check = Access.run(Texture.STATUS_CMD)
            a.runOnUiThread {
                notif("🎨 $label Aktif", "Texture diterapkan. Tutup & buka game sekarang!")
                out.text = "$label ✅\nTerdeteksi: ${Texture.detectLevel(check)}\n\n${check.ifBlank{"(kosong)"}}\n\n${r.ifBlank{""}}"
            }
        }.start()
    }

    private fun runTexReset() {
        if (!Access.hasAny()) { Access.requires(a, "Reset Texture", false); return }
        out.text = "Mereset texture..."
        Thread {
            val r = Access.run(texReset())
            val check = Access.run(Texture.STATUS_CMD)
            a.runOnUiThread {
                notif("Reset Texture ✅", "Texture kembali ke bawaan")
                out.text = "Reset ✅\n${check.ifBlank{"(kosong)"}}\n\n${r.ifBlank{""}}"
            }
        }.start()
    }

    private fun run(cmd: String, label: String) {
        if (!Access.requires(a, label, false)) return
        out.text = "Menjalankan $label..."
        Thread {
            val r = Access.run(cmd)
            a.runOnUiThread { out.text = "$label\n${r.ifBlank{"(tanpa output)"}}" }
        }.start()
    }

    private fun notif(title: String, msg: String) {
        try {
            val nm = a.getSystemService(android.content.Context.NOTIFICATION_SERVICE)
                    as android.app.NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val ch = android.app.NotificationChannel("xa_shell", "XAGameSpace Shell",
                    android.app.NotificationManager.IMPORTANCE_DEFAULT)
                nm.createNotificationChannel(ch)
            }
            val nb = androidx.core.app.NotificationCompat.Builder(a, "xa_shell")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .setContentTitle(title).setContentText(msg)
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
            androidx.core.app.NotificationManagerCompat.from(a).notify(2002, nb.build())
        } catch (_: Exception) {}
    }
}
