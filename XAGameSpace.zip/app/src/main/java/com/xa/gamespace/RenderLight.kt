package com.xa.gamespace

import android.content.Context

// Render ringan: memakai kelas HP dari deteksi awal (dev_tier).
// Refresh rate dikunci (min = peak) supaya layar tidak naik-turun (jitter/patah-patah),
// dan GPU render vsync dinyalakan untuk menghaluskan frame.
object RenderLight {
    fun hzFor(tier: String): Int = when (tier) {
        "HIGH" -> 90
        else -> 60
    }

    // render paling ringan untuk semua kelas HP: 60 Hz terkunci + GPU render vsync
    fun applyLowest(ctx: Context): String {
        Access.run(RateCmd.renderCmd("60") + "\n" + RateCmd.gpuVsyncCmd(true))
        Store(ctx).put("render_light", "60")
        AutoReset.flag(ctx)
        return "Render paling ringan aktif: 60 Hz terkunci"
    }

    fun apply(ctx: Context): String {
        val st = Store(ctx)
        val tier = st.get("dev_tier").ifBlank { "LOW" }
        val hz = hzFor(tier)
        Access.run(RateCmd.renderCmd(hz.toString()) + "\n" + RateCmd.gpuVsyncCmd(true))
        st.put("render_light", hz.toString())
        AutoReset.flag(ctx)
        return "Render ringan aktif: ${hz} Hz terkunci (kelas $tier)"
    }
}
