package com.xa.gamespace

import android.content.Context

// Reset tweak ke bawaan: satu per satu (ResetSheet) atau semua sekaligus.
// Dipakai tombol RESET DEFAULT di beranda, dan otomatis saat game ditutup / service berhenti.
object TweakReset {
    class Item(val id: String, val label: String, val action: (Context) -> Unit)

    val items: List<Item> = listOf(
        Item("boost", "Boost game (FPS & performa)") { c ->
            if (Store(c).active) Boost.off(c)
        },
        Item("texture", "Texture (ANGLE)") { c ->
            if (Access.hasAny()) Access.run(Texture.resetCmd())
            Store(c).put(Texture.KEY_APPLIED, "")
        },
        Item("render", "Render ringan") { c ->
            if (Access.hasAny()) Access.run(RateCmd.renderDefaultCmd())
            Store(c).put("render_light", "")
        },
        Item("vsync", "VSync GPU") { c ->
            if (Access.hasAny()) Access.run(RateCmd.gpuVsyncCmd(false))
        },
        Item("cooler", "Pendingin & thermal") { c ->
            Store(c).put("cooler", "0")
            if (Access.hasAny()) Access.run(ThermalCmd.buildCmd(ThermalCmd.Mode.STOCK, null))
        },
        Item("filter", "Filter layar") { c ->
            FilterLayer.clear(c)
            Store(c).put("filter_idx", "0")
        },
        Item("network", "Optimal jaringan") { c ->
            NetOpt.resetAll(c)
        },
        Item("touch", "Sensitivitas X / Y") { c ->
            val st = Store(c)
            st.touchSensX = 1f
            st.touchSensY = 1f
        }
    )

    fun runOne(ctx: Context, id: String): Boolean {
        val item = items.firstOrNull { it.id == id } ?: return false
        item.action(ctx)
        return true
    }

    fun runAll(ctx: Context) {
        for (item in items) runCatching { item.action(ctx) }
        Store(ctx).put("applied", "")
    }
}
