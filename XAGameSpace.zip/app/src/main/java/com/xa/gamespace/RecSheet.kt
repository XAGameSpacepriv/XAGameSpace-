package com.xa.gamespace

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

// Menu REKAM: pengaturan (resolusi, FPS, bitrate) dan tombol rekam.
class RecSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val status = TextView(ctx)
    private val store = Store(ctx)

    private fun px(v: Int) = ctx.px(v)

    private fun chip(text: String, on: Boolean, click: () -> Unit) = TextView(ctx).apply {
        this.text = text; textSize = 11f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (on) Color.parseColor("#04141F") else Color.WHITE)
        setPadding(px(8), px(8), px(8), px(8))
        background = Hud.rounded(if (on) Hud.cyan else Color.argb(90, 255, 255, 255),
            if (on) Hud.cyan else Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
        setOnClickListener { Sfx.tap(); click() }
    }

    private fun group(title: String, key: String, opts: List<Pair<String, String>>, def: String) {
        root.addView(TextView(ctx).apply { text = title; textSize = 11f; setTextColor(Hud.neon); typeface = Typeface.DEFAULT_BOLD },
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(10) })
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val cur = store.get(key).ifBlank { def }
        for ((label, value) in opts) {
            r.addView(chip(label, cur == value) { store.put(key, value); rebuild() },
                LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(0, px(4), px(4), 0) })
        }
        root.addView(r)
    }

    private fun button(text: String, primary: Boolean, click: () -> Unit) = chip(text, primary, click).apply {
        textSize = 13f
    }

    private fun needPerm(mode: String) {
        store.put("rec_pending", mode)
        // task terpisah + tanpa animasi: setelah izin, kembali ke game, bukan ke GameSpace
        val i = Intent(ctx, ScreenPermActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or
                Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
        ctx.startActivity(i)
    }

    private fun rebuild() {
        root.removeAllViews()
        build()
    }

    private fun build() {
        root.addView(TextView(ctx).apply { text = "/ REKAM LAYAR"; textSize = 13f; setTextColor(Hud.neon); typeface = Typeface.DEFAULT_BOLD })
        group("Resolusi (tinggi layar)", "rec_res", listOf("480p" to "480", "720p" to "720", "1080p" to "1080"), "720")
        group("FPS", "rec_fps", listOf("24" to "24", "30" to "30", "60" to "60"), "30")
        group("Bitrate (Mbps)", "rec_bitrate", listOf("2" to "2", "4" to "4", "6" to "6", "8" to "8"), "4")
        group("Audio", "rec_audio", listOf("Tanpa" to "none", "🎤 Mic" to "mic", "🔊 Suara sistem" to "sys"), "none")
        root.addView(TextView(ctx).apply {
            text = "Lebih rendah = lebih ringan dan file lebih kecil. 720p · 30 FPS · 4 Mbps cocok untuk HP biasa."
            textSize = 10f; setTextColor(Color.argb(190, 200, 215, 235))
        }, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })

        val recOn = ScreenRec.recording
        root.addView(button(if (recOn) "■  STOP REKAM" else "●  MULAI REKAM", true) {
            if (ScreenRec.recording) {
                status.text = ScreenRec.stopRecord()
                ctx.stopService(Intent(ctx, ScreenRecService::class.java))
                rebuild()
            } else if (store.get("rec_audio") != "none" &&
                ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                needPerm("perm_mic")
            } else if (ScreenRec.projection == null) {
                needPerm("rec")
            } else {
                status.text = ScreenRec.startRecord(ctx)
                rebuild()
            }
        }, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(14) })

        status.textSize = 11f; status.setTextColor(Hud.sub)
        root.addView(status, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })
        root.addView(button("TUTUP", false) { onClose() }, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(10); it.gravity = Gravity.END })
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(14), px(12), px(14), px(12))
        root.background = Hud.rounded(Color.argb(240, 8, 22, 42), Hud.neon, ctx.pxf(14f), 1.4f)
        build()
    }
}
