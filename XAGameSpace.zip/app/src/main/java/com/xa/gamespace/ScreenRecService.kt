package com.xa.gamespace

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast

// Service foreground untuk rekam layar.
// Urutan wajib (Android 14+): startForeground dulu, baru getMediaProjection,
// lalu registerCallback sebelum createVirtualDisplay.
class ScreenRecService : Service() {

    override fun onCreate() {
        super.onCreate()
        val ch = "xa_rec"
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel(ch, "Rekam layar", NotificationManager.IMPORTANCE_LOW))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else @Suppress("DEPRECATION") Notification.Builder(this)
        val n = b.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("XAGameSpace")
            .setContentText("Merekam layar")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(4711, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(4711, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        val mode = intent?.getStringExtra("mode") ?: ""

        if (data != null && code != 0 && ScreenRec.projection == null) {
            try {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val p: MediaProjection = mpm.getMediaProjection(code, data)
                p.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        ScreenRec.stopRecord()
                        ScreenRec.projection = null
                        stopSelf()
                    }
                }, Handler(Looper.getMainLooper()))
                ScreenRec.projection = p
            } catch (e: Exception) {
                Toast.makeText(this, "Izin rekam gagal: ${e.message}", Toast.LENGTH_LONG).show()
                stopSelf()
                return START_NOT_STICKY
            }
        }

        if (mode == "rec") {
            val msg = try { ScreenRec.startRecord(this) } catch (e: Exception) {
                ScreenRec.stopRecord()
                "Gagal mulai rekam: ${e.message}"
            }
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { ScreenRec.stopRecord() } catch (e: Exception) {}
        try { ScreenRec.projection?.stop() } catch (e: Exception) {}
        ScreenRec.projection = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
