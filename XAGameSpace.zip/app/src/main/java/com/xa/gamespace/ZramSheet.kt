package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

// ZRAM: swap terkompresi di RAM. Butuh ROOT (tulis ke /sys dan swapon).
object Zram {
    fun status(): String = Access.run("cat /proc/swaps 2>/dev/null; ls /sys/block/zram0 2>/dev/null | head -n 1")

    fun enable(gb: Int): String {
        val bytes = gb.toLong() * 1024L * 1024L * 1024L
        return Access.run(
            "swapoff /dev/block/zram0 2>/dev/null\n" +
                "echo 1 > /sys/block/zram0/reset\n" +
                "echo lz4 > /sys/block/zram0/comp_algorithm 2>/dev/null\n" +
                "echo $bytes > /sys/block/zram0/disksize\n" +
                "mkswap /dev/block/zram0\n" +
                "swapon /dev/block/zram0 -p 100"
        )
    }

    fun disable(): String = Access.run(
        "swapoff /dev/block/zram0 2>/dev/null\n" +
            "echo 1 > /sys/block/zram0/reset"
    )
}

class ZramSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val out = TextView(ctx)
    private var pending = 0

    private fun px(v: Int) = ctx.px(v)

    private fun chip(t: String, primary: Boolean = false, click: () -> Unit) = TextView(ctx).apply {
        text = t; textSize = 12f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (primary) Color.parseColor("#04141F") else Color.WHITE)
        setPadding(px(10), px(9), px(10), px(9))
        background = Hud.rounded(if (primary) Hud.cyan else Color.argb(90, 255, 255, 255),
            if (primary) Hud.cyan else Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
        setOnClickListener { Sfx.tap(); click() }
    }

    private fun warning(gb: Int) {
        root.removeAllViews()
        root.addView(TextView(ctx).apply {
            text = "PERINGATAN ZRAM ${gb} GB"; textSize = 13f; setTextColor(Color.parseColor("#FFB347")); typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(ctx).apply {
            text = "• Butuh ROOT. Tanpa root, tidak akan jalan.\n" +
                "• ZRAM memakai RAM untuk menyimpan data terkompresi. Ukuran besar bisa membuat HP terasa lambat atau tidak stabil.\n" +
                "• Tidak semua kernel mendukung ZRAM. Bisa gagal di HP tertentu.\n" +
                "• Setelah HP restart, ZRAM hilang dan harus dipasang ulang.\n" +
                "• Gunakan 2 sampai 4 GB untuk HP biasa. 8 GB hanya untuk HP yang RAM-nya sudah besar."
            textSize = 11f; setTextColor(Color.argb(220, 230, 235, 245))
        }, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(chip("Batal") { pending = 0; render() }, LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = px(6) })
        row.addView(chip("Jalankan tweak", true) { apply(gb) }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(12) })
        // teks proses tampil di bawah tombol
        out.textSize = 11f; out.setTextColor(Hud.sub)
        root.addView(out, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(12) })
    }

    private fun apply(gb: Int) {
        if (!Access.isRoot) { out.text = "ZRAM butuh ROOT. Tidak bisa dipasang dengan Shizuku."; return }
        out.text = "Proses: menjalankan tweak ZRAM ${gb} GB..."
        Thread {
            val r = Zram.enable(gb)
            out.post { out.text = "Selesai: ZRAM ${gb} GB dicoba.\n${r.ifBlank { "(selesai, cek status)" }}" }
        }.start()
    }

    private fun render() {
        root.removeAllViews()
        root.addView(TextView(ctx).apply { text = "ZRAM"; textSize = 14f; setTextColor(Hud.neon); typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(ctx).apply {
            text = if (Access.isRoot) "Pilih ukuran (butuh root):" else "Butuh ROOT. Fitur ini dikunci tanpa root."
            textSize = 11f; setTextColor(Hud.sub)
        }, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(6) })
        val row1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, gb) in (1..8).withIndex()) {
            val c = chip("$gb GB") { warning(gb) }
            val lp = LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(0, px(6), px(4), 0) }
            if (i < 4) row1.addView(c, lp) else row2.addView(c, lp)
        }
        root.addView(row1); root.addView(row2)
        root.addView(chip("Matikan ZRAM") {
            if (!Access.isRoot) { out.text = "Butuh ROOT."; return@chip }
            Thread { val r = Zram.disable(); out.post { out.text = "ZRAM dimatikan.\n${r.ifBlank { "" }}" } }.start()
        }, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(10) })
        out.textSize = 11f; out.setTextColor(Hud.sub)
        root.addView(out, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })
        root.addView(chip("TUTUP") { onClose() }, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(10); it.gravity = Gravity.END })
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(16), px(14), px(16), px(14))
        root.background = Hud.rounded(Color.argb(240, 8, 22, 42), Hud.neon, ctx.pxf(14f), 1.4f)
        render()
    }
}
