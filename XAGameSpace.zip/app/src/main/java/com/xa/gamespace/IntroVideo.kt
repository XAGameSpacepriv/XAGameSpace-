package com.xa.gamespace

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

// Intro saat game dibuka. Dulu video 720x328 (diperbesar di 1080p jadi buram).
// Sekarang digambar langsung dengan Canvas di resolusi layar, jadi tajam di HP apa pun.
// Urutan (2.2 dtk): grid melengkung -> pusar cahaya -> bola hitam berbusur -> teks XA GAMESPACE.
// Selesai (atau ketuk layar) -> onEnd dipanggil supaya handle panel tetap muncul.
class IntroVideo(c: Context, private val onEnd: () -> Unit) : FrameLayout(c) {
    private var done = false
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f)
    private val canvasView = IntroCanvas(c)

    private fun finish() {
        if (done) return
        done = true
        anim.cancel()
        onEnd()
    }

    init {
        setBackgroundColor(Color.BLACK)
        addView(canvasView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        setOnClickListener { finish() }
        Sfx.playIntro(c)
        anim.duration = 2200
        anim.interpolator = LinearInterpolator()
        anim.addUpdateListener { t = it.animatedValue as Float; canvasView.invalidate() }
        anim.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(a: android.animation.Animator) { finish() }
        })
        anim.start()
    }

    private inner class IntroCanvas(ctx: Context) : View(ctx) {
        private val rnd = Random(7)
        private val bubbles = List(45) { floatArrayOf(rnd.nextFloat(), rnd.nextFloat(), 1f + rnd.nextFloat() * 3f) }
        private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val arcP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        }
        private val txtP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            letterSpacing = 0.12f
        }
        private val rect = RectF()

        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return
            val cx = w / 2f
            val cy = h / 2f
            val u = min(w, h) / 1080f * 1.6f   // skala ukuran dari layar 1080p

            // latar gelap biru malam
            fillP.shader = LinearGradient(0f, 0f, 0f, h,
                Color.parseColor("#06101F"), Color.parseColor("#020609"), Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, w, h, fillP)
            fillP.shader = null

            val gridA = fade(t, 0.00f, 0.30f) * (1f - fade(t, 0.80f, 1.00f) * 0.6f)

            // grid melengkung: cincin elips + garis radial
            if (gridA > 0f) {
                lineP.strokeWidth = 1.2f * u
                for (i in 1..9) {
                    val rx = w * 0.09f * i
                    val ry = rx * 0.38f
                    lineP.color = argb(gridA * 0.55f * (1f - i / 11f), 60, 200, 255)
                    cv.drawOval(cx - rx, cy - ry, cx + rx, cy + ry, lineP)
                }
                for (k in 0 until 18) {
                    val a = (k / 18f) * 2f * PI.toFloat()
                    lineP.color = argb(gridA * 0.25f, 60, 200, 255)
                    cv.drawLine(cx, cy, cx + cos(a) * w * 0.9f, cy + sin(a) * h * 0.4f, lineP)
                }
            }

            // gelembung naik pelan
            for (b in bubbles) {
                val y = ((b[1] - t * 0.25f * b[2]) % 1f + 1f) % 1f
                fillP.color = argb(gridA * 0.5f, 120, 230, 255)
                cv.drawCircle(b[0] * w, y * h, b[2] * u, fillP)
            }

            // pusar cahaya awal + sinar horizontal
            val coreA = fade(t, 0.05f, 0.20f) * (1f - fade(t, 0.38f, 0.52f))
            if (coreA > 0f) {
                val beamW = w * 0.8f * fade(t, 0.05f, 0.25f)
                lineP.strokeWidth = 2.5f * u
                lineP.color = argb(coreA * 0.9f, 80, 230, 255)
                cv.drawLine(cx - beamW / 2f, cy, cx + beamW / 2f, cy, lineP)
                fillP.shader = RadialGradient(cx, cy, 90f * u,
                    intArrayOf(argb(coreA, 200, 250, 255), argb(coreA * 0.3f, 40, 180, 255), Color.TRANSPARENT),
                    floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
                cv.drawCircle(cx, cy, 90f * u, fillP)
                fillP.shader = null
            }

            // bola hitam dengan busur berputar
            val swirlP = fade(t, 0.30f, 0.55f)
            val swirlOut = fade(t, 0.72f, 0.82f)
            if (swirlP > 0f && swirlOut < 1f) {
                val s = swirlP * (1f - swirlOut)
                val r = 70f * u * s
                fillP.color = Color.BLACK
                cv.drawCircle(cx, cy, r, fillP)
                lineP.strokeWidth = 0f
                arcP.strokeWidth = 7f * u
                for (arm in 0 until 3) {
                    val base = (t * 900f + arm * 120f) % 360f
                    arcP.color = argb(s, 120, 240, 255)
                    rect.set(cx - r * 1.5f, cy - r * 1.5f, cx + r * 1.5f, cy + r * 1.5f)
                    cv.drawArc(rect, base, 70f, false, arcP)
                    arcP.color = argb(s * 0.5f, 40, 200, 255)
                    rect.set(cx - r * 1.25f, cy - r * 1.25f, cx + r * 1.25f, cy + r * 1.25f)
                    cv.drawArc(rect, base + 150f, 50f, false, arcP)
                }
            }

            // teks XA GAMESPACE + garis neon
            val textA = fade(t, 0.62f, 0.78f) * (1f - fade(t, 0.93f, 1.00f))
            if (textA > 0f) {
                val slide = (1f - fade(t, 0.62f, 0.80f)) * 24f * u
                txtP.textSize = 74f * u
                txtP.color = argb(textA, 255, 255, 255)
                txtP.setShadowLayer(22f * u, 0f, 0f, argb(textA * 0.9f, 46, 245, 160))
                cv.drawText("XA GAMESPACE", cx, cy + 22f * u + slide, txtP)
                txtP.clearShadowLayer()

                val barW = w * 0.62f * fade(t, 0.70f, 0.90f)
                lineP.strokeWidth = 3f * u
                lineP.color = argb(textA * 0.9f, 60, 200, 255)
                cv.drawLine(cx - barW / 2f, cy + 62f * u, cx + barW / 2f, cy + 62f * u, lineP)
                lineP.color = argb(textA * 0.9f, 46, 245, 160)
                cv.drawLine(cx - barW / 3f, cy + 78f * u, cx + barW / 3f, cy + 78f * u, lineP)
            }
        }

        private fun fade(v: Float, a: Float, b: Float): Float =
            ((v - a) / (b - a)).coerceIn(0f, 1f)

        private fun argb(alpha: Float, r: Int, g: Int, b: Int): Int =
            Color.argb((max(0f, min(1f, alpha)) * 255f).toInt(), r, g, b)
    }
}
