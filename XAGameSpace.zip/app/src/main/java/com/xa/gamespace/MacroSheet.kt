package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.roundToInt

// Tab Macro di overlay XA. Susunan dan isi disamakan dengan tab Macro di XAGameSpacepanel.
class MacroSheet(
    private val ctx: Context,
    private val onClose: () -> Unit,
    private val onPlace: () -> Unit
) {
    val root = LinearLayout(ctx).apply { background = MT.sheetBg(ctx) }
    private val statusTv = TextView(ctx)
    private val accent = MT.accent

    init {
        MacroEngine.load(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(14), px(10), px(14), px(16))
        build()
    }

    private fun build() {
        root.removeAllViews()
        val c = MacroEngine.cfg

        // header
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(tv("🎮 Macro", 14f, MT.text, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(MT.button(ctx, "✕") { MacroEngine.stop(); onClose() })
        root.addView(header, lp(-1, -2).also { it.bottomMargin = px(6) })

        // status Shizuku / root
        statusTv.textSize = 10f
        root.addView(statusTv, lp(-1, -2).also { it.bottomMargin = px(8) })
        refreshStatus()

        root.addView(switchRow("Aktifkan Macro (Pro Unlocked)", c.enabled) { on ->
            MacroEngine.update { it.copy(enabled = on, isRunning = if (!on) false else it.isRunning) }
            if (!on) MacroEngine.stop()
        })

        val target2On = c.enableTarget2 || c.pattern == MacroPattern.QUICK_SWITCH
        root.addView(switchRow("Tombol 2: Auto Ganti Senjata (1 → 2)", target2On) { on ->
            MacroEngine.update {
                it.copy(
                    enableTarget2 = on,
                    showTarget = if (on) true else it.showTarget,
                    pattern = if (on) MacroPattern.QUICK_SWITCH
                    else if (it.pattern == MacroPattern.QUICK_SWITCH) MacroPattern.REPEAT else it.pattern
                )
            }
        })

        // mode sentuhan
        root.addView(sectionLabel("Mode Sentuhan (10-Jari Multi-Touch)"))
        root.addView(pillRow(
            listOf(
                "Anti-Bentrok" to MacroInjectionMode.SMART_POINTER,
                "Stylus" to MacroInjectionMode.STYLUS_HYBRID,
                "Touch" to MacroInjectionMode.TOUCHSCREEN_DIRECT
            ),
            c.injectionMode
        ) { m -> MacroEngine.update { it.copy(injectionMode = m) }; build() })
        root.addView(tv(c.injectionMode.subtitle, 10f, MT.sub))

        // pola macro
        root.addView(sectionLabel("Pola Macro"))
        MacroPattern.values().toList().chunked(3).forEach { chunk ->
            root.addView(pillRow(chunk.map { it.label to it }, c.pattern) { p ->
                MacroEngine.update {
                    if (p == MacroPattern.QUICK_SWITCH) it.copy(pattern = p, enableTarget2 = true, showTarget = true)
                    else it.copy(pattern = p)
                }
                build()
            })
        }

        if (target2On) {
            root.addView(slider({ "Jeda Tembak (1) → Senjata (2)" }, 30, 600, c.switchDelayMs, { "$it ms" }) { v ->
                MacroEngine.update { it.copy(switchDelayMs = v) }
            })
        }

        val tapsPerSec = { ms: Int -> (1000f / ms.coerceAtLeast(16)).roundToInt() }
        root.addView(slider({ ms -> "Interval (${tapsPerSec(ms)} siklus/detik)" }, 16, 1000, c.intervalMs, { "$it ms" }) { v ->
            MacroEngine.update { it.copy(intervalMs = v) }
        })
        root.addView(slider({ "Lama tahan sentuhan" }, 6, 400, c.holdDurationMs, { "$it ms" }) { v ->
            MacroEngine.update { it.copy(holdDurationMs = v) }
        })
        root.addView(slider({ "Ukuran Trigger" }, 7, 16, (c.triggerScale * 10f).roundToInt(),
            { String.format(java.util.Locale.US, "%.1fx", it / 10f) }) { v ->
            MacroEngine.update { it.copy(triggerScale = v / 10f) }
        })
        root.addView(slider({ "Jangkauan acak (Anti-detect)" }, 0, 20, c.randomJitterPx,
            { if (it == 0) "Off" else "$it px" }) { v ->
            MacroEngine.update { it.copy(randomJitterPx = v) }
        })

        root.addView(switchRow("Tampilkan titik target (1 & 2)", c.showTarget) { on ->
            MacroEngine.update { it.copy(showTarget = on) }
        })
        root.addView(switchRow("Kunci posisi & transparan", c.isLocked) { on ->
            MacroEngine.update { it.copy(isLocked = on, isRunning = false) }
        })
        root.addView(switchRow("Mode Tahan Trigger (Hold)", c.holdToTrigger) { on ->
            MacroEngine.update { it.copy(holdToTrigger = on, isRunning = false) }
        })
        root.addView(slider({ "Transparansi saat dikunci" }, 15, 70, (c.lockedOpacity * 100f).roundToInt(),
            { "$it%" }) { v ->
            MacroEngine.update { it.copy(lockedOpacity = (v / 100f).coerceIn(0.15f, 0.70f)) }
        })

        root.addView(tv(
            "Kunci posisi lalu tahan Trigger sambil menggeser layar game dengan jari lain. " +
                "Macro 10-jari butuh Shizuku atau ROOT.",
            10f, accent
        ).apply { setPadding(px(8), px(6), px(8), px(6)); background = MT.box(ctx, MT.elevated, MT.border, ctx.pxf(8f)) },
            lp(-1, -2).also { it.topMargin = px(8); it.bottomMargin = px(8) })

        root.addView(MT.button(ctx, "🎯 Atur & geser posisi (D-Pad)") {
            MacroEngine.stop()
            onPlace()
        }, lp(-1, -2))
    }

    private fun refreshStatus() {
        ShizukuBridge.init(ctx)
        val st = ShizukuBridge.refresh(ctx, autoTriggerIfReady = false)
        val (text, col) = when {
            st.isKernelMultiTouch -> "${st.activeEngineLabel} • 10-Jari Aktif • Zero Cancel" to "#2CE59B"
            st.isInputServiceBound -> "${st.activeEngineLabel} • Tanpa Aksesibilitas" to "#2CE59B"
            st.canRunPrivileged -> "Shizuku Terhubung • ${st.activeEngineLabel}" to "#2CE59B"
            else -> "Macro butuh Shizuku (Wireless Debugging) atau ROOT" to "#FFB740"
        }
        statusTv.text = text
        statusTv.setTextColor(Color.parseColor(col))
    }

    // ---- komponen ----

    private fun switchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val pill = tv(if (checked) "ON" else "OFF", 10f, if (checked) MT.onAccent else MT.text, true).apply {
            gravity = Gravity.CENTER
            setPadding(px(12), px(5), px(12), px(5))
            background = MT.box(ctx, 
                if (checked) accent else MT.elevated,
                if (checked) accent else MT.border,
                ctx.pxf(12f), 1f
            )
            setOnClickListener { Sfx.tap(); onChange(!checked); build() }
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, px(4), 0, px(4))
        }
        row.addView(tv(label, 11f, MT.text, false), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(pill)
        return row
    }

    private fun <T> pillRow(items: List<Pair<String, T>>, current: T, onPick: (T) -> Unit): LinearLayout {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        for ((text, value) in items) {
            val sel = value == current
            val t = tv(text, 10f, if (sel) MT.onAccent else MT.text, true).apply {
                gravity = Gravity.CENTER
                setPadding(px(4), px(8), px(4), px(8))
                background = MT.box(ctx, 
                    if (sel) accent else MT.elevated,
                    if (sel) accent else MT.border,
                    ctx.pxf(10f), 1f
                )
                setOnClickListener { Sfx.tap(); onPick(value) }
            }
            row.addView(t, LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = px(4); it.bottomMargin = px(4) })
        }
        return row
    }

    private fun slider(
        label: (Int) -> String,
        lo: Int,
        hi: Int,
        value: Int,
        fmt: (Int) -> String,
        onChange: (Int) -> Unit
    ): LinearLayout {
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, px(4), 0, px(4)) }
        val labelTv = tv(label(value), 11f, MT.text, true)
        val valTv = tv(fmt(value), 11f, accent, true)
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(labelTv, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(valTv)
        col.addView(head)
        val sb = SeekBar(ctx).apply {
            this.max = hi - lo
            this.progress = value - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val v = p + lo
                    valTv.text = fmt(v)
                    labelTv.text = label(v)
                    onChange(v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(sb)
        return col
    }

    private fun sectionLabel(t: String) = tv(t, 11f, MT.sub).apply {
        setPadding(0, px(8), 0, px(4))
    }

    private fun px(dp: Int) = ctx.px(dp)
    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)
    private fun tv(t: String, size: Float, col: Int = MT.text, bold: Boolean = false) =
        TextView(ctx).apply {
            text = t
            textSize = size
            setTextColor(col)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
}
