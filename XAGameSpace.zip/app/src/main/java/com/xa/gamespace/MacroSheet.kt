package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.widget.NestedScrollView

// =====================================================================
//  MacroEngine – eksekusi macro via "input tap" / "input swipe"
//  Mendukung ROOT dan Shizuku shell.
//
//  Pattern tersedia:
//  RAPID_FIRE   → tap cepat berulang di titik target
//  BURST        → N tap berurutan lalu jeda
//  HOLD         → tahan layar (input swipe durasi panjang)
//  SWIPE_L/R    → geser kiri/kanan cepat
//  QUICK_SWITCH → tap target1 lalu target2 bergantian (ganti senjata)
// =====================================================================
object MacroEngine {

    enum class Pattern(val label: String, val desc: String) {
        RAPID_FIRE (
            "⚡ Rapid Fire",
            "Tap cepat berulang di titik tembak — cocok untuk mode semi-auto."
        ),
        BURST(
            "💥 Burst 3×",
            "3 tap cepat lalu jeda — cocok untuk burst rifle."
        ),
        HOLD(
            "👇 Hold (Tahan)",
            "Tahan layar terus-menerus — cocok untuk scope / ADS."
        ),
        SWIPE_LEFT(
            "← Swipe Kiri",
            "Geser layar ke kiri berulang — cocok untuk loot cepat."
        ),
        SWIPE_RIGHT(
            "→ Swipe Kanan",
            "Geser layar ke kanan berulang."
        ),
        QUICK_SWITCH(
            "🔄 Quick Switch",
            "Tap senjata 1 → senjata 2 bergantian cepat."
        )
    }

    data class MacroConfig(
        val pattern: Pattern = Pattern.RAPID_FIRE,
        val intervalMs: Long = 150,      // jeda antar tap (ms)
        val holdMs: Long = 35,           // durasi hold per tap (ms)
        val burstCount: Int = 3,         // tap per burst
        val jitterPx: Int = 2,           // random jitter (piksel) agar tidak terdeteksi
        // posisi target (koordinat layar)
        val targetX: Int = 540,
        val targetY: Int = 960,
        val target2X: Int = 700,
        val target2Y: Int = 800
    )

    private var running = false
    private var thread: Thread? = null

    val isRunning get() = running

    fun start(ctx: Context, cfg: MacroConfig) {
        if (running) return
        if (!Access.hasAny()) return
        running = true
        thread = Thread {
            while (running) {
                try {
                    executeCycle(cfg)
                    Thread.sleep(cfg.intervalMs.coerceAtLeast(16))
                } catch (_: InterruptedException) { break }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
    }

    private fun executeCycle(cfg: MacroConfig) {
        val jx = if (cfg.jitterPx > 0) (-cfg.jitterPx..cfg.jitterPx).random() else 0
        val jy = if (cfg.jitterPx > 0) (-cfg.jitterPx..cfg.jitterPx).random() else 0
        val x = cfg.targetX + jx
        val y = cfg.targetY + jy

        when (cfg.pattern) {
            Pattern.RAPID_FIRE -> {
                Access.run("input tap $x $y")
            }
            Pattern.BURST -> {
                repeat(cfg.burstCount) {
                    if (!running) return
                    Access.run("input tap $x $y")
                    Thread.sleep(30)
                }
            }
            Pattern.HOLD -> {
                val endX = x; val endY = y
                val dur = cfg.holdMs.coerceAtLeast(500)
                Access.run("input swipe $x $y $endX $endY $dur")
            }
            Pattern.SWIPE_LEFT -> {
                Access.run("input swipe ${x + 300} $y ${x - 300} $y 80")
            }
            Pattern.SWIPE_RIGHT -> {
                Access.run("input swipe ${x - 300} $y ${x + 300} $y 80")
            }
            Pattern.QUICK_SWITCH -> {
                val jx2 = if (cfg.jitterPx > 0) (-cfg.jitterPx..cfg.jitterPx).random() else 0
                val jy2 = if (cfg.jitterPx > 0) (-cfg.jitterPx..cfg.jitterPx).random() else 0
                Access.run("input tap $x $y")
                Thread.sleep(cfg.intervalMs / 2)
                if (running) Access.run("input tap ${cfg.target2X + jx2} ${cfg.target2Y + jy2}")
            }
        }
    }
}

// =====================================================================
//  MacroSheet – UI panel macro di overlay game
// =====================================================================
class MacroSheet(
    private val ctx: Context,
    private val onClose: () -> Unit,
    private val onPlace: () -> Unit
) {
    val root: LinearLayout = LinearLayout(ctx)
    private val store = Store(ctx)
    private val statusTv = TextView(ctx)
    private var currentCfg = loadConfig()
    private var selectedPattern = currentCfg.pattern
    private lateinit var toggleBtn: android.widget.TextView
    private lateinit var posTv: android.widget.TextView

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(14), px(10), px(14), px(16))

        // Header
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(tv("🎮 Macro", 14f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(btn("✕") { MacroEngine.stop(); onClose() })
        root.addView(header, lp(-1, -2).also { it.bottomMargin = px(4) })

        // Info
        root.addView(tv(
            "Macro tap otomatis via ROOT/Shizuku shell. Pilih pattern, atur posisi, lalu tekan START.",
            10f, Hud.sub
        ), lp(-1, -2).also { it.bottomMargin = px(10) })

        // Status
        statusTv.textSize = 10f
        statusTv.setTextColor(Hud.sub)
        statusTv.text = if (Access.hasAny()) "Siap — ${if (Access.isRoot) "ROOT" else "Shizuku"}" else "⚠ Butuh ROOT atau Shizuku"
        root.addView(statusTv, lp(-1, -2).also { it.bottomMargin = px(8) })

        // Pattern selector
        root.addView(tv("Pattern Macro", 12f, Color.WHITE, true), lp(-1, -2).also { it.bottomMargin = px(6) })

        val sv = NestedScrollView(ctx).apply { isVerticalScrollBarEnabled = false }
        val patternBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        val chipRows = ArrayList<android.widget.Button>()
        for (pattern in MacroEngine.Pattern.values()) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(px(10), px(10), px(10), px(10))
            }
            val isSelected = pattern == selectedPattern
            row.background = Hud.rounded(
                if (isSelected) Color.argb(80, 46, 200, 255) else Color.argb(30, 20, 60, 80),
                if (isSelected) Hud.cyan else Color.argb(60, 46, 200, 255),
                ctx.pxf(10f), if (isSelected) 2f else 1f
            )

            val info = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            info.addView(tv(pattern.label, 12f, if (isSelected) Hud.cyan else Color.WHITE, true))
            info.addView(tv(pattern.desc, 9.5f, Hud.sub))
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))

            row.setOnClickListener {
                Sfx.tap()
                selectedPattern = pattern
                // refresh semua baris
                for (i in MacroEngine.Pattern.values().indices) {
                    val p = MacroEngine.Pattern.values()[i]
                    val r = patternBox.getChildAt(i) as? LinearLayout ?: continue
                    val sel = p == selectedPattern
                    r.background = Hud.rounded(
                        if (sel) Color.argb(80, 46, 200, 255) else Color.argb(30, 20, 60, 80),
                        if (sel) Hud.cyan else Color.argb(60, 46, 200, 255),
                        ctx.pxf(10f), if (sel) 2f else 1f
                    )
                    val nameTv = (r.getChildAt(0) as? LinearLayout)?.getChildAt(0) as? TextView
                    nameTv?.setTextColor(if (sel) Hud.cyan else Color.WHITE)
                }
                currentCfg = currentCfg.copy(pattern = selectedPattern)
            }

            patternBox.addView(row, lp(-1, -2).also { it.bottomMargin = px(5) })
        }

        sv.addView(patternBox)
        root.addView(sv, lp(-1, 0, 1f))

        // Interval slider
        root.addView(tv("Interval Tap", 11f, Color.WHITE, true), lp(-1, -2).also { it.topMargin = px(10); it.bottomMargin = px(2) })
        val intervalLabels = listOf("16ms\n(turbo)", "50ms", "100ms", "150ms\n(std)", "250ms", "500ms")
        val intervalValues = listOf(16L, 50L, 100L, 150L, 250L, 500L)
        val intervalRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, label) in intervalLabels.withIndex()) {
            val isSel = intervalValues[i] == currentCfg.intervalMs
            val chip = tv(label, 9f, if (isSel) Color.parseColor("#04141F") else Color.WHITE, isSel)
            chip.gravity = Gravity.CENTER
            chip.setPadding(px(6), px(6), px(6), px(6))
            chip.background = Hud.rounded(
                if (isSel) Hud.cyan else Color.argb(50, 46, 200, 255),
                if (isSel) Hud.cyan else Color.argb(80, 46, 200, 255),
                ctx.pxf(10f), 1f
            )
            chip.setOnClickListener {
                Sfx.tap()
                currentCfg = currentCfg.copy(intervalMs = intervalValues[i])
                for (j in 0 until intervalRow.childCount) {
                    val c = intervalRow.getChildAt(j) as? TextView ?: continue
                    val s = intervalValues[j] == currentCfg.intervalMs
                    c.setTextColor(if (s) Color.parseColor("#04141F") else Color.WHITE)
                    c.background = Hud.rounded(
                        if (s) Hud.cyan else Color.argb(50, 46, 200, 255),
                        if (s) Hud.cyan else Color.argb(80, 46, 200, 255),
                        ctx.pxf(10f), 1f
                    )
                }
            }
            intervalRow.addView(chip, LinearLayout.LayoutParams(0, -2, 1f).also {
                if (i < intervalLabels.size - 1) it.rightMargin = px(4)
            })
        }
        root.addView(intervalRow, lp(-1, -2).also { it.bottomMargin = px(10) })

        // Atur posisi: memunculkan titik Tembak (1) & Senjata (2) yang bisa diseret di layar
        posTv = tv(posText(), 10f, Hud.sub)
        root.addView(posTv, lp(-1, -2).also { it.bottomMargin = px(6) })
        root.addView(btn("🎯 Atur posisi (seret titik di layar)") {
            if (MacroEngine.isRunning) MacroEngine.stop()
            saveConfig(currentCfg)
            onPlace()
        }, lp(-1, -2).also { it.bottomMargin = px(8) })

        // Tombol START/STOP
        toggleBtn = btn(
            if (MacroEngine.isRunning) "■ STOP MACRO" else "▶ START MACRO",
            primary = !MacroEngine.isRunning
        ) { toggleMacro() }
        root.addView(toggleBtn, lp(-1, -2))
    }

    private fun posText() =
        "Tembak (${currentCfg.targetX}, ${currentCfg.targetY}) • Senjata (${currentCfg.target2X}, ${currentCfg.target2Y})"

    private fun toggleMacro() {
        if (!Access.hasAny()) {
            statusTv.setTextColor(Color.parseColor("#FF6B6B"))
            statusTv.text = "⚠ Butuh ROOT atau Shizuku!"
            return
        }
        if (MacroEngine.isRunning) {
            MacroEngine.stop()
            toggleBtn.text = "▶ START MACRO"
            toggleBtn.background = Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(10f), 1f)
            toggleBtn.setTextColor(Color.parseColor("#04141F"))
            statusTv.setTextColor(Hud.sub)
            statusTv.text = "Macro dihentikan."
        } else {
            saveConfig(currentCfg)
            MacroEngine.start(ctx, currentCfg)
            toggleBtn.text = "■ STOP MACRO"
            toggleBtn.background = Hud.rounded(Color.parseColor("#FF6B6B"), Color.parseColor("#FF6B6B"), ctx.pxf(10f), 1f)
            toggleBtn.setTextColor(Color.WHITE)
            statusTv.setTextColor(Color.parseColor("#38E8A5"))
            statusTv.text = "✓ Macro berjalan — ${currentCfg.pattern.label} @ ${currentCfg.intervalMs}ms"
        }
    }

    private fun loadConfig() = MacroEngine.MacroConfig(
        intervalMs = store.get("macro_interval").toLongOrNull() ?: 150L,
        pattern = try { MacroEngine.Pattern.valueOf(store.get("macro_pattern")) }
                  catch (_: Exception) { MacroEngine.Pattern.RAPID_FIRE },
        targetX  = store.get("macro_tx").toIntOrNull() ?: 540,
        targetY  = store.get("macro_ty").toIntOrNull() ?: 960,
        target2X = store.get("macro_tx2").toIntOrNull() ?: 700,
        target2Y = store.get("macro_ty2").toIntOrNull() ?: 800
    )

    private fun saveConfig(cfg: MacroEngine.MacroConfig) {
        store.put("macro_interval", cfg.intervalMs.toString())
        store.put("macro_pattern", cfg.pattern.name)
        store.put("macro_tx", cfg.targetX.toString())
        store.put("macro_ty", cfg.targetY.toString())
        store.put("macro_tx2", cfg.target2X.toString())
        store.put("macro_ty2", cfg.target2Y.toString())
    }

    // ---- helpers ----
    private fun px(dp: Int) = ctx.px(dp)
    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)
    private fun tv(t: String, size: Float, col: Int = Color.WHITE, bold: Boolean = false) =
        TextView(ctx).apply {
            text = t; textSize = size; setTextColor(col)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
    private fun btn(label: String, primary: Boolean = false, onClick: () -> Unit) =
        Hud.flatButton(ctx, label, primary, onClick)
}
