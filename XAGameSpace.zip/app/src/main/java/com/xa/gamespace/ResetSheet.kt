package com.xa.gamespace

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.LinearLayout
import android.widget.TextView

// Panel RESET DEFAULT: kembalikan semua tweak sekaligus, atau satu per satu.
class ResetSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val log = TextView(ctx)

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(14), px(12), px(14), px(14))

        root.addView(TextView(ctx).apply {
            text = "Reset Default"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }, lp(-1, -2))
        root.addView(TextView(ctx).apply {
            text = "Kembalikan setelan ke bawaan. Bisa semua sekaligus atau satu per satu."
            textSize = 11f
            setTextColor(Hud.sub)
        }, lp(-1, -2).also { it.bottomMargin = px(8) })

        root.addView(Hud.flatButton(ctx, "↺  RESET SEMUA TWEAK", true) { run(null) },
            lp(-1, -2).also { it.bottomMargin = px(8) })

        for (item in TweakReset.items) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(px(12), px(10), px(10), px(10))
                background = Hud.card(ctx)
            }
            row.addView(TextView(ctx).apply {
                text = item.label
                textSize = 12f
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Hud.flatButton(ctx, "Reset") { run(item) })
            root.addView(row, lp(-1, -2).also { it.topMargin = px(6) })
        }

        log.textSize = 11f
        log.setTextColor(Hud.sub)
        root.addView(log, lp(-1, -2).also { it.topMargin = px(10) })
        root.addView(Hud.flatButton(ctx, "Tutup") { onClose() }, lp(-1, -2).also { it.topMargin = px(8) })
    }

    private fun run(item: TweakReset.Item?) {
        log.setTextColor(Hud.sub)
        log.text = "Mereset..."
        Thread {
            if (item == null) TweakReset.runAll(ctx) else item.action(ctx)
            (ctx as? Activity)?.runOnUiThread {
                log.setTextColor(Color.parseColor("#2CE59B"))
                log.text = if (item == null) "✓ Semua tweak dikembalikan ke bawaan."
                else "✓ ${item.label} dikembalikan."
            }
        }.start()
    }

    private fun px(d: Int) = ctx.px(d)
    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
}
