package com.xa.gamespace

import android.os.Process
import android.os.SystemClock
import android.view.MotionEvent
import androidx.annotation.Keep
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit

data class TouchDeviceSpec(
    val eventPath: String,
    val absMinX: Int,
    val absMaxX: Int,
    val absMinY: Int,
    val absMaxY: Int,
    val slotMax: Int,
    val hasBtnTouch: Boolean
)

/**
 * Direct Linux `/dev/input/eventX` Type-B Multi-Touch engine (Slot 9..6 hardware injection)
 * + real-time passive physical finger tracker for both Root (evdev) and Non-Root Shizuku
 * (Multi-Pointer `ACTION_POINTER_DOWN` merging).
 *
 * Critical guarantees for smooth, zero-stutter camera swiping while holding Macro:
 * 1. Atomic `ABS_MT_SLOT` restoration: every synthetic `down()`/`move()`/`up()` packet writes
 *    `EV_ABS ABS_MT_SLOT <lastPhysicalSlot>` right before `SYN_REPORT` in the exact same `write()`
 *    syscall so hardware drivers that omit redundant `ABS_MT_SLOT` never route physical swipe
 *    frames into the synthetic macro slot.
 * 2. Zero `BTN_TOUCH` clobbering: tracks hardware `BTN_TOUCH`, physical slot bitmask, recent
 *    physical activity timestamp, AND explicit `physicalFingerHint` from the Macro Trigger view.
 *    Never emits `BTN_TOUCH=0` while any physical finger is on screen.
 * 3. AOSP-accurate physical `pointerId` & coordinate snapshotting: feeds `ShizukuInputUserService`
 *    with active physical finger positions so non-root `InputManager` injection can merge Macro
 *    taps as `ACTION_POINTER_DOWN` / `ACTION_POINTER_UP` on the real touchscreen `deviceId`
 *    without cancelling the user's camera drag!
 */
class KernelTouchEngine(
    private val nowMsProvider: () -> Long = { SystemClock.uptimeMillis() }
) {

    @Volatile
    var deviceSpec: TouchDeviceSpec? = null
        private set

    @Volatile
    var isWritable: Boolean = false
        private set

    @Volatile
    var isReadable: Boolean = false
        private set

    @Volatile
    var isGeteventReaderRunning: Boolean = false
        private set

    @Volatile
    private var macroActive: Boolean = false

    val isLiveBoostReaderActive: Boolean
        get() = isReadable || isGeteventReaderRunning

    val boostedFramesCount: Long
        get() = boostController.boostedFramesCount

    private var outStream: FileOutputStream? = null
    private var inStream: FileInputStream? = null
    private var readerThread: Thread? = null
    private var geteventProcess: java.lang.Process? = null
    private var geteventThread: Thread? = null

    @Volatile
    private var runningReader = false

    private val is64Bit = runCatching { Process.is64Bit() }.getOrDefault(true)
    val eventSizeBytes: Int = if (is64Bit) 24 else 16
    private val writeLock = Any()
    private val slotStateLock = Any()

    // Active physical slots monitored passively from hardware driver (slots 0..5)
    @Volatile
    private var activePhysicalSlotMask: Int = 0

    @Volatile
    private var activeSyntheticSlotMask: Int = 0

    @Volatile
    private var lastPhysicalSlot: Int = 0

    @Volatile
    private var hardwareBtnTouchDown: Boolean = false

    @Volatile
    private var lastPhysicalEventMs: Long = 0L

    @Volatile
    private var physicalDownTimeMs: Long = 0L

    private var currentReadSlot: Int = 0
    private var activePointerIdBits: Int = 0
    private var trackingSeq: Int = 9100
    private var macroBtnTouchSent = false

    // Type-B Multi-Touch per-slot state for SYN_REPORT frame assembly & pointerId mirroring
    private val slotTrackingId = IntArray(32) { -1 }
    private val slotPointerId = IntArray(32) { -1 }
    private val slotRawX = IntArray(32) { -1 }
    private val slotRawY = IntArray(32) { -1 }
    private val slotActive = BooleanArray(32)
    private val slotJustDown = BooleanArray(32)
    private val slotJustUp = BooleanArray(32)
    private val slotDirtyPos = BooleanArray(32)

    @Volatile
    private var externalBoostInjector: ((
        action: Int,
        x: Float,
        y: Float,
        downTimeMs: Long,
        screenW: Int,
        screenH: Int,
        rotation: Int
    ) -> Boolean)? = null

    private val boostController = TouchBoostController(
        dispatchEvent = { action, x, y, downTimeMs, screenW, screenH, rotation ->
            dispatchTouchBoostEvent(action, x, y, downTimeMs, screenW, screenH, rotation)
        },
        nowMsProvider = nowMsProvider
    )

    val macroSlot: Int
        get() = (deviceSpec?.slotMax ?: 9).coerceIn(1, 9)

    val reservedSyntheticMinSlot: Int
        get() = (macroSlot - MAX_SLOT_OFFSET).coerceAtLeast(if (macroSlot >= 4) 2 else 1)

    internal fun setTestDeviceSpec(spec: TouchDeviceSpec) {
        deviceSpec = spec
    }

    fun setExternalBoostInjector(
        injector: ((
            action: Int,
            x: Float,
            y: Float,
            downTimeMs: Long,
            screenW: Int,
            screenH: Int,
            rotation: Int
        ) -> Boolean)?
    ) {
        externalBoostInjector = injector
    }

    /**
     * Marks whether Macro auto-tap is currently active.
     * In non-kernel (`!isWritable`) mode, pauses Touch Sensitivity companion injections while Macro
     * is firing so both features never compete on `InputManager.injectInputEvent`.
     * In kernel (`isWritable`) mode, Slot 9 (Macro) and Slot 6 (Touch Boost) coexist seamlessly.
     */
    fun setMacroActive(active: Boolean) {
        macroActive = active
        if (active && !isWritable) {
            runCatching { boostController.forceRelease() }
            if (!isLiveBoostReaderActive) {
                ensurePassiveReaderForConcurrency()
            }
        }
    }

    /**
     * Ensures passive physical finger tracking (`inStream` or `getevent`) is active even when
     * Touch Sensitivity Boost is turned off, enabling zero-cancel Non-Root Multi-Pointer Macro!
     */
    fun ensurePassiveReaderForConcurrency(): Boolean {
        if (isReadable) return true
        if (isGeteventReaderRunning && geteventThread?.isAlive == true) return true
        return startGeteventFallbackReaderIfNeeded()
    }

    fun updateBoostConfig(config: TouchAmplifierConfig) {
        boostController.updateConfig(config)
        if (config.hasEffectiveBoost()) {
            if (deviceSpec == null) {
                initIfPermitted()
            }
            if (!isReadable) {
                startGeteventFallbackReaderIfNeeded()
            }
        } else if (!macroActive) {
            // Keep passive reader alive only while macro or touch boost needs physical slot tracking
            stopGeteventFallbackReader()
        }
    }

    private fun dispatchTouchBoostEvent(
        action: Int,
        x: Float,
        y: Float,
        downTimeMs: Long,
        screenW: Int,
        screenH: Int,
        rotation: Int
    ): Boolean {
        if (isWritable) {
            return when (action) {
                MotionEvent.ACTION_DOWN -> down(BOOST_SLOT_OFFSET, x, y, screenW, screenH, rotation, physicalFingerHint = true)
                MotionEvent.ACTION_MOVE -> move(BOOST_SLOT_OFFSET, x, y, screenW, screenH, rotation)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> up(BOOST_SLOT_OFFSET, physicalFingerHint = true)
                else -> false
            }
        }
        if (macroActive) return false
        val delegate = externalBoostInjector ?: return false
        return delegate(action, x, y, downTimeMs, screenW, screenH, rotation)
    }

    @Synchronized
    fun initIfPermitted(): Boolean {
        if (isWritable && outStream != null && deviceSpec != null) return true
        if (isReadable && inStream != null && deviceSpec != null) return false
        close()

        val spec = discoverTouchscreenDevice() ?: return false
        deviceSpec = spec

        val file = File(spec.eventPath)
        val writable = runCatching {
            if (!file.exists()) return@runCatching false
            outStream = FileOutputStream(file)
            true
        }.getOrElse {
            outStream = null
            false
        }

        val readable = runCatching {
            inStream = FileInputStream(file)
            startPassiveSlotReader(spec)
            true
        }.getOrElse {
            inStream = null
            false
        }

        isWritable = writable
        isReadable = readable
        return writable
    }

    private fun resetSlotTrackerState() {
        synchronized(slotStateLock) {
            currentReadSlot = 0
            lastPhysicalSlot = 0
            activePhysicalSlotMask = 0
            activePointerIdBits = 0
            hardwareBtnTouchDown = false
            physicalDownTimeMs = 0L
            for (i in 0 until 32) {
                slotTrackingId[i] = -1
                slotPointerId[i] = -1
                slotRawX[i] = -1
                slotRawY[i] = -1
                slotActive[i] = false
                slotJustDown[i] = false
                slotJustUp[i] = false
                slotDirtyPos[i] = false
            }
        }
    }

    private fun allocateLowestFreePointerIdLocked(): Int {
        for (id in 0 until 31) {
            if ((activePointerIdBits and (1 shl id)) == 0) {
                activePointerIdBits = activePointerIdBits or (1 shl id)
                return id
            }
        }
        return 0
    }

    private fun releasePointerIdForSlotLocked(slot: Int) {
        val pid = slotPointerId[slot]
        if (pid in 0 until 31) {
            activePointerIdBits = activePointerIdBits and (1 shl pid).inv()
        }
        slotPointerId[slot] = -1
    }

    private fun ensureSlotMarkedPhysicalDownLocked(slot: Int, nowMs: Long) {
        val wasAnyDown = activePhysicalSlotMask != 0
        if (slot in 0..30) {
            activePhysicalSlotMask = activePhysicalSlotMask or (1 shl slot)
            lastPhysicalSlot = slot
            lastPhysicalEventMs = nowMs
            macroBtnTouchSent = false
            if (slotPointerId[slot] < 0) {
                slotPointerId[slot] = allocateLowestFreePointerIdLocked()
            }
            if (!wasAnyDown) {
                physicalDownTimeMs = nowMs
            }
        }
    }

    private fun isSyntheticSlot(slot: Int): Boolean {
        if (slot < 0 || slot >= 32) return true
        if (slot >= reservedSyntheticMinSlot) return true
        if ((activeSyntheticSlotMask and (1 shl slot)) != 0) return true
        val tid = slotTrackingId[slot]
        if (tid in 9100..65000) return true
        return false
    }

    /**
     * Picks the exact physical slot to restore via `EV_ABS ABS_MT_SLOT` at the end of every
     * synthetic packet so hardware touchscreen updates never land in our synthetic slot.
     */
    internal fun resolveRestorePhysicalSlot(): Int {
        val maxPhysical = (reservedSyntheticMinSlot - 1).coerceAtLeast(0)
        val mask = activePhysicalSlotMask
        val candidate = lastPhysicalSlot.coerceIn(0, maxPhysical)
        if ((mask and (1 shl candidate)) != 0) {
            return candidate
        }
        if (mask != 0) {
            for (s in maxPhysical downTo 0) {
                if ((mask and (1 shl s)) != 0) return s
            }
        }
        return candidate
    }

    internal fun isAnyPhysicalFingerDown(physicalFingerHint: Boolean = false): Boolean {
        if (physicalFingerHint) return true
        if (activePhysicalSlotMask != 0) return true
        if (hardwareBtnTouchDown) return true
        val elapsed = nowMsProvider() - lastPhysicalEventMs
        return lastPhysicalEventMs > 0L && elapsed in 0L..500L
    }

    /**
     * Thread-safe snapshot of all currently touching physical fingers (pointerIds + rotated display coords).
     * Used by `ShizukuInputUserService` to merge non-root Macro taps as `ACTION_POINTER_DOWN`/`UP`
     * on the physical touchscreen's `deviceId` without cancelling the user's camera drag!
     */
    fun snapshotActivePhysicalPointers(
        screenW: Int,
        screenH: Int,
        rotation: Int
    ): ActivePhysicalTouchSnapshot {
        val spec = deviceSpec ?: return ActivePhysicalTouchSnapshot(0L, emptyList())
        synchronized(slotStateLock) {
            val mask = activePhysicalSlotMask
            if (mask == 0) {
                return ActivePhysicalTouchSnapshot(0L, emptyList())
            }
            val nowMs = nowMsProvider()
            // Guard against stale slots if hardware lifted without delivering a final event
            if (!hardwareBtnTouchDown && lastPhysicalEventMs > 0L && (nowMs - lastPhysicalEventMs) > 6_000L) {
                activePhysicalSlotMask = 0
                activePointerIdBits = 0
                for (i in 0 until reservedSyntheticMinSlot.coerceIn(1, 31)) {
                    slotPointerId[i] = -1
                    slotActive[i] = false
                }
                return ActivePhysicalTouchSnapshot(0L, emptyList())
            }
            val maxPhysical = reservedSyntheticMinSlot.coerceIn(1, 31)
            val list = ArrayList<PhysicalPointerPoint>(4)
            for (s in 0 until maxPhysical) {
                if ((mask and (1 shl s)) != 0 && slotRawX[s] >= 0 && slotRawY[s] >= 0) {
                    val pid = if (slotPointerId[s] >= 0) {
                        slotPointerId[s]
                    } else {
                        allocateLowestFreePointerIdLocked().also { slotPointerId[s] = it }
                    }
                    val (sx, sy) = TouchAmplifierMath.sensorToScreen(
                        spec, slotRawX[s], slotRawY[s], screenW, screenH, rotation
                    )
                    list.add(PhysicalPointerPoint(slot = s, pointerId = pid, screenX = sx, screenY = sy))
                }
            }
            val downTime = if (physicalDownTimeMs > 0L) physicalDownTimeMs else nowMs
            return ActivePhysicalTouchSnapshot(downTimeMs = downTime, pointers = list)
        }
    }

    internal fun processEvdevEvent(spec: TouchDeviceSpec, type: Int, code: Int, value: Int) {
        val nowMs = nowMsProvider()
        var dispatchUpMask = 0
        var dispatchDownMask = 0
        var dispatchMoveMask = 0
        val maxPhysicalSlot = reservedSyntheticMinSlot.coerceIn(1, 31)
        var snapshotRawX: IntArray? = null
        var snapshotRawY: IntArray? = null

        synchronized(slotStateLock) {
            when (type) {
                EV_KEY -> {
                    if (code == BTN_TOUCH) {
                        if (value != 0) {
                            if (!macroBtnTouchSent) {
                                hardwareBtnTouchDown = true
                                lastPhysicalEventMs = nowMs
                            }
                        } else {
                            hardwareBtnTouchDown = false
                            // When hardware confirms all physical touches lifted (and no synthetic touch is down),
                            // sweep any orphaned physical slots cleanly.
                            if (activeSyntheticSlotMask == 0) {
                                for (s in 0 until maxPhysicalSlot) {
                                    if ((activePhysicalSlotMask and (1 shl s)) != 0) {
                                        slotJustUp[s] = true
                                        slotJustDown[s] = false
                                        releasePointerIdForSlotLocked(s)
                                    }
                                }
                                activePhysicalSlotMask = 0
                                activePointerIdBits = 0
                                physicalDownTimeMs = 0L
                            }
                        }
                    }
                }
                EV_ABS -> {
                    when (code) {
                        ABS_MT_SLOT -> {
                            val clamped = value.coerceIn(0, 31)
                            currentReadSlot = clamped
                            if (clamped < reservedSyntheticMinSlot) {
                                lastPhysicalSlot = clamped
                            }
                        }
                        ABS_MT_TRACKING_ID -> {
                            val s = currentReadSlot
                            val wasSynthetic = isSyntheticSlot(s)
                            slotTrackingId[s] = value
                            val nowSynthetic = wasSynthetic || (value in 9100..65000) || (s >= reservedSyntheticMinSlot)
                            if (!nowSynthetic && s in 0..30) {
                                if (value >= 0) {
                                    ensureSlotMarkedPhysicalDownLocked(s, nowMs)
                                    hardwareBtnTouchDown = true
                                    slotJustDown[s] = true
                                    slotJustUp[s] = false
                                } else {
                                    activePhysicalSlotMask = activePhysicalSlotMask and (1 shl s).inv()
                                    releasePointerIdForSlotLocked(s)
                                    lastPhysicalEventMs = nowMs
                                    if (activePhysicalSlotMask == 0) {
                                        physicalDownTimeMs = 0L
                                        hardwareBtnTouchDown = false
                                    }
                                    slotJustUp[s] = true
                                    slotJustDown[s] = false
                                }
                            }
                        }
                        ABS_MT_POSITION_X -> {
                            val s = currentReadSlot
                            if (!isSyntheticSlot(s)) {
                                slotRawX[s] = value
                                slotDirtyPos[s] = true
                                ensureSlotMarkedPhysicalDownLocked(s, nowMs)
                                hardwareBtnTouchDown = true
                            }
                        }
                        ABS_MT_POSITION_Y -> {
                            val s = currentReadSlot
                            if (!isSyntheticSlot(s)) {
                                slotRawY[s] = value
                                slotDirtyPos[s] = true
                                ensureSlotMarkedPhysicalDownLocked(s, nowMs)
                                hardwareBtnTouchDown = true
                            }
                        }
                    }
                }
                EV_SYN -> {
                    if (code == SYN_REPORT) {
                        val cfg = boostController.currentConfig()
                        val shouldBoost = cfg.hasEffectiveBoost() && (isWritable || !macroActive)
                        for (s in 0 until maxPhysicalSlot) {
                            if (slotJustUp[s]) {
                                slotJustUp[s] = false
                                slotJustDown[s] = false
                                slotDirtyPos[s] = false
                                slotActive[s] = false
                                if (shouldBoost) dispatchUpMask = dispatchUpMask or (1 shl s)
                            } else if (slotJustDown[s]) {
                                slotJustDown[s] = false
                                slotDirtyPos[s] = false
                                slotActive[s] = true
                                if (shouldBoost && slotRawX[s] >= 0 && slotRawY[s] >= 0) {
                                    dispatchDownMask = dispatchDownMask or (1 shl s)
                                }
                            } else if (slotDirtyPos[s]) {
                                slotDirtyPos[s] = false
                                if (shouldBoost && slotActive[s] && slotRawX[s] >= 0 && slotRawY[s] >= 0) {
                                    dispatchMoveMask = dispatchMoveMask or (1 shl s)
                                }
                            }
                        }
                        if (dispatchDownMask != 0 || dispatchMoveMask != 0) {
                            snapshotRawX = IntArray(maxPhysicalSlot) { slotRawX[it] }
                            snapshotRawY = IntArray(maxPhysicalSlot) { slotRawY[it] }
                        }
                    }
                }
            }
        }

        // Dispatch TouchBoost outside slotStateLock so boostController never deadlocks with snapshot calls
        if (dispatchUpMask != 0 || dispatchDownMask != 0 || dispatchMoveMask != 0) {
            val cfg = boostController.currentConfig()
            for (s in 0 until maxPhysicalSlot) {
                val bit = 1 shl s
                when {
                    (dispatchUpMask and bit) != 0 -> boostController.onPhysicalFingerUp(s)
                    (dispatchDownMask and bit) != 0 -> {
                        val rx = snapshotRawX?.get(s) ?: continue
                        val ry = snapshotRawY?.get(s) ?: continue
                        val (sx, sy) = TouchAmplifierMath.sensorToScreen(
                            spec, rx, ry, cfg.screenW, cfg.screenH, cfg.rotation
                        )
                        boostController.onPhysicalFingerDown(s, sx, sy)
                    }
                    (dispatchMoveMask and bit) != 0 -> {
                        val rx = snapshotRawX?.get(s) ?: continue
                        val ry = snapshotRawY?.get(s) ?: continue
                        val (sx, sy) = TouchAmplifierMath.sensorToScreen(
                            spec, rx, ry, cfg.screenW, cfg.screenH, cfg.rotation
                        )
                        boostController.onPhysicalFingerMove(s, sx, sy)
                    }
                }
            }
        }
    }

    private fun startPassiveSlotReader(spec: TouchDeviceSpec) {
        val stream = inStream ?: return
        resetSlotTrackerState()
        runningReader = true
        readerThread = Thread({
            val buf = ByteArray(eventSizeBytes * 16)
            val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
            while (runningReader) {
                val n = try {
                    stream.read(buf)
                } catch (_: Throwable) {
                    break
                }
                if (n <= 0) break
                val count = n / eventSizeBytes
                for (i in 0 until count) {
                    val base = i * eventSizeBytes
                    val typeOffset = if (is64Bit) base + 16 else base + 8
                    val type = bb.getShort(typeOffset).toInt() and 0xFFFF
                    val code = bb.getShort(typeOffset + 2).toInt() and 0xFFFF
                    val value = bb.getInt(typeOffset + 4)
                    processEvdevEvent(spec, type, code, value)
                }
            }
        }, "xa-kernel-slot-reader").apply {
            isDaemon = true
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    @Synchronized
    fun startGeteventFallbackReaderIfNeeded(): Boolean {
        if (isReadable) return true
        if (isGeteventReaderRunning && geteventThread?.isAlive == true) return true
        val spec = deviceSpec ?: discoverTouchscreenDevice()?.also { deviceSpec = it } ?: return false

        stopGeteventFallbackReader()
        resetSlotTrackerState()
        val geteventBin = resolveGeteventBinary()
        val proc = runCatching {
            ProcessBuilder(geteventBin, spec.eventPath).redirectErrorStream(false).start()
        }.getOrNull() ?: return false

        geteventProcess = proc
        isGeteventReaderRunning = true
        geteventThread = Thread({
            try {
                BufferedReader(InputStreamReader(proc.inputStream)).use { br ->
                    while (isGeteventReaderRunning) {
                        val line = br.readLine() ?: break
                        val trimmed = line.trim()
                        if (trimmed.isEmpty()) continue
                        val tokens = trimmed.split(' ').filter { it.isNotEmpty() }
                        if (tokens.size < 3) continue
                        val offset = tokens.size - 3
                        val type = tokens[offset].toIntOrNull(16) ?: continue
                        val code = tokens[offset + 1].toIntOrNull(16) ?: continue
                        val value = tokens[offset + 2].toLongOrNull(16)?.toInt() ?: continue
                        processEvdevEvent(spec, type, code, value)
                    }
                }
            } catch (_: Throwable) {
                // Stream closed
            } finally {
                isGeteventReaderRunning = false
            }
        }, "xa-getevent-boost-reader").apply {
            isDaemon = true
            priority = Thread.MAX_PRIORITY
            start()
        }
        return true
    }

    @Synchronized
    fun stopGeteventFallbackReader() {
        isGeteventReaderRunning = false
        runCatching { geteventProcess?.destroyForcibly() }
        geteventProcess = null
        runCatching { geteventThread?.interrupt() }
        geteventThread = null
    }

    internal fun buildDownPacket(
        spec: TouchDeviceSpec,
        slotOffset: Int,
        screenX: Float,
        screenY: Float,
        screenW: Int,
        screenH: Int,
        rotation: Int,
        physicalFingerHint: Boolean = false
    ): ByteArray {
        val slot = (macroSlot - slotOffset.coerceIn(0, MAX_SLOT_OFFSET)).coerceAtLeast(1)
        val (rawX, rawY) = mapToSensor(spec, screenX, screenY, screenW, screenH, rotation)

        synchronized(writeLock) {
            trackingSeq = if (trackingSeq >= 65000) 9100 else trackingSeq + 1
            activeSyntheticSlotMask = activeSyntheticSlotMask or (1 shl slot)
            val anyPhysical = isAnyPhysicalFingerDown(physicalFingerHint)
            if (anyPhysical) {
                macroBtnTouchSent = false
            }
            val needBtnTouch = spec.hasBtnTouch && !anyPhysical && !macroBtnTouchSent
            val restoreSlot = resolveRestorePhysicalSlot()
            // +1 event for atomic ABS_MT_SLOT restore right before SYN_REPORT
            val eventCount = if (needBtnTouch) 10 else 8
            val buf = ByteBuffer.allocate(eventCount * eventSizeBytes).order(ByteOrder.LITTLE_ENDIAN)

            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_SLOT, slot)
            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_TRACKING_ID, trackingSeq)
            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_POSITION_X, rawX)
            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_POSITION_Y, rawY)
            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_TOUCH_MAJOR, 10)
            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_PRESSURE, 64)
            if (needBtnTouch) {
                putInputEvent(buf, 0L, 0L, EV_KEY, BTN_TOUCH, 1)
                putInputEvent(buf, 0L, 0L, EV_KEY, BTN_TOOL_FINGER, 1)
                macroBtnTouchSent = true
            }
            // CRITICAL: Atomically restore hardware driver's active physical slot before SYN_REPORT!
            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_SLOT, restoreSlot)
            putInputEvent(buf, 0L, 0L, EV_SYN, SYN_REPORT, 0)
            return buf.array()
        }
    }

    internal fun buildMovePacket(
        spec: TouchDeviceSpec,
        slotOffset: Int,
        screenX: Float,
        screenY: Float,
        screenW: Int,
        screenH: Int,
        rotation: Int
    ): ByteArray {
        val slot = (macroSlot - slotOffset.coerceIn(0, MAX_SLOT_OFFSET)).coerceAtLeast(1)
        val (rawX, rawY) = mapToSensor(spec, screenX, screenY, screenW, screenH, rotation)

        synchronized(writeLock) {
            val restoreSlot = resolveRestorePhysicalSlot()
            val buf = ByteBuffer.allocate(5 * eventSizeBytes).order(ByteOrder.LITTLE_ENDIAN)

            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_SLOT, slot)
            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_POSITION_X, rawX)
            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_POSITION_Y, rawY)
            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_SLOT, restoreSlot)
            putInputEvent(buf, 0L, 0L, EV_SYN, SYN_REPORT, 0)
            return buf.array()
        }
    }

    internal fun buildUpPacket(
        spec: TouchDeviceSpec,
        slotOffset: Int,
        physicalFingerHint: Boolean = false
    ): ByteArray {
        val slot = (macroSlot - slotOffset.coerceIn(0, MAX_SLOT_OFFSET)).coerceAtLeast(1)

        synchronized(writeLock) {
            activeSyntheticSlotMask = activeSyntheticSlotMask and (1 shl slot).inv()
            val anyPhysical = isAnyPhysicalFingerDown(physicalFingerHint)
            if (anyPhysical) {
                macroBtnTouchSent = false
            }
            val releaseBtnTouch = spec.hasBtnTouch &&
                !anyPhysical &&
                activeSyntheticSlotMask == 0 &&
                macroBtnTouchSent
            val restoreSlot = resolveRestorePhysicalSlot()
            // +1 event for atomic ABS_MT_SLOT restore right before SYN_REPORT
            val eventCount = if (releaseBtnTouch) 6 else 4
            val buf = ByteBuffer.allocate(eventCount * eventSizeBytes).order(ByteOrder.LITTLE_ENDIAN)

            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_SLOT, slot)
            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_TRACKING_ID, -1)
            if (releaseBtnTouch) {
                putInputEvent(buf, 0L, 0L, EV_KEY, BTN_TOUCH, 0)
                putInputEvent(buf, 0L, 0L, EV_KEY, BTN_TOOL_FINGER, 0)
                macroBtnTouchSent = false
            }
            putInputEvent(buf, 0L, 0L, EV_ABS, ABS_MT_SLOT, restoreSlot)
            putInputEvent(buf, 0L, 0L, EV_SYN, SYN_REPORT, 0)
            return buf.array()
        }
    }

    fun down(
        slotOffset: Int,
        screenX: Float,
        screenY: Float,
        screenW: Int,
        screenH: Int,
        rotation: Int,
        physicalFingerHint: Boolean = false
    ): Boolean {
        val spec = deviceSpec ?: return false
        val out = outStream ?: return false
        val packet = buildDownPacket(spec, slotOffset, screenX, screenY, screenW, screenH, rotation, physicalFingerHint)
        synchronized(writeLock) {
            return runCatching {
                out.write(packet)
                true
            }.getOrElse {
                isWritable = false
                false
            }
        }
    }

    fun move(
        slotOffset: Int,
        screenX: Float,
        screenY: Float,
        screenW: Int,
        screenH: Int,
        rotation: Int
    ): Boolean {
        val spec = deviceSpec ?: return false
        val out = outStream ?: return false
        val packet = buildMovePacket(spec, slotOffset, screenX, screenY, screenW, screenH, rotation)
        synchronized(writeLock) {
            return runCatching {
                out.write(packet)
                true
            }.getOrElse {
                isWritable = false
                false
            }
        }
    }

    fun up(slotOffset: Int, physicalFingerHint: Boolean = false): Boolean {
        val spec = deviceSpec ?: return false
        val out = outStream ?: return false
        val packet = buildUpPacket(spec, slotOffset, physicalFingerHint)
        synchronized(writeLock) {
            return runCatching {
                out.write(packet)
                true
            }.getOrElse {
                isWritable = false
                false
            }
        }
    }

    fun pulse(
        slotOffset: Int,
        screenX: Float,
        screenY: Float,
        screenW: Int,
        screenH: Int,
        rotation: Int,
        pressMs: Long,
        physicalFingerHint: Boolean = false
    ): Boolean {
        if (!down(slotOffset, screenX, screenY, screenW, screenH, rotation, physicalFingerHint)) return false
        SystemClock.sleep(pressMs.coerceIn(4L, 1200L))
        return up(slotOffset, physicalFingerHint)
    }

    @Synchronized
    fun close() {
        runningReader = false
        macroActive = false
        stopGeteventFallbackReader()
        runCatching { boostController.forceRelease() }
        for (slotIdx in 0..MAX_SLOT_OFFSET) {
            runCatching { up(slotIdx, physicalFingerHint = true) }
        }
        activeSyntheticSlotMask = 0
        runCatching { readerThread?.interrupt() }
        readerThread = null
        runCatching { inStream?.close() }
        inStream = null
        runCatching { outStream?.close() }
        outStream = null
        isWritable = false
        isReadable = false
    }

    private fun putInputEvent(
        buf: ByteBuffer,
        sec: Long,
        usec: Long,
        type: Int,
        code: Int,
        value: Int
    ) {
        if (is64Bit) {
            buf.putLong(sec)
            buf.putLong(usec)
        } else {
            buf.putInt(sec.toInt())
            buf.putInt(usec.toInt())
        }
        buf.putShort(type.toShort())
        buf.putShort(code.toShort())
        buf.putInt(value)
    }

    private fun mapToSensor(
        spec: TouchDeviceSpec,
        x: Float,
        y: Float,
        w: Int,
        h: Int,
        rotation: Int
    ): Pair<Int, Int> = TouchAmplifierMath.screenToSensor(spec, x, y, w, h, rotation)

    private fun resolveGeteventBinary(): String {
        val candidates = arrayOf("/system/bin/getevent", "/vendor/bin/getevent", "/system/xbin/getevent")
        for (path in candidates) {
            if (runCatching { File(path).exists() }.getOrDefault(false)) return path
        }
        return "getevent"
    }

    private fun discoverTouchscreenDevice(): TouchDeviceSpec? {
        val candidates = collectEventNodesFromProc().ifEmpty {
            (0..24).map { "/dev/input/event$it" }.filter { File(it).exists() }
        }
        for (path in candidates) {
            val spec = probeEventSpec(path)
            if (spec != null) return spec
        }
        return null
    }

    private fun collectEventNodesFromProc(): List<String> {
        val procFile = File("/proc/bus/input/devices")
        if (!procFile.canRead()) return emptyList()
        val prioritized = mutableListOf<String>()
        val others = mutableListOf<String>()
        var blockLooksLikeTouch = false
        val eventRegex = Regex("event(\\d+)")

        runCatching {
            procFile.forEachLine { line ->
                if (line.isBlank()) {
                    blockLooksLikeTouch = false
                } else {
                    val lower = line.lowercase()
                    if (lower.startsWith("n:") &&
                        (lower.contains("touch") || lower.contains("fts") || lower.contains("goodix") ||
                            lower.contains("synaptics") || lower.contains("novatek") || lower.contains("sec_touch") ||
                            lower.contains("focal") || lower.contains("ilitek") || lower.contains("atmel") ||
                            lower.contains("xiaomi") || lower.contains("chipone") || lower.contains("himax") ||
                            lower.contains("nt36") || lower.contains("gt9"))
                    ) {
                        blockLooksLikeTouch = true
                    }
                    if (lower.startsWith("h:") && lower.contains("handlers=")) {
                        val m = eventRegex.find(line)
                        if (m != null) {
                            val path = "/dev/input/event${m.groupValues[1]}"
                            if (blockLooksLikeTouch) prioritized.add(path) else others.add(path)
                        }
                    }
                }
            }
        }
        return (prioritized + others).distinct()
    }

    private fun probeEventSpec(path: String): TouchDeviceSpec? {
        val geteventBin = resolveGeteventBinary()
        val output = runCatching {
            val proc = ProcessBuilder(geteventBin, "-lp", path).redirectErrorStream(true).start()
            val finished = proc.waitFor(2, TimeUnit.SECONDS)
            val txt = proc.inputStream.bufferedReader().use { it.readText() }
            if (!finished) proc.destroyForcibly()
            txt
        }.getOrNull().orEmpty()

        val textToParse = if (output.contains("ABS_MT_POSITION_X") || output.contains("0035")) {
            output
        } else {
            runCatching {
                val proc = ProcessBuilder(geteventBin, "-p", path).redirectErrorStream(true).start()
                val finished = proc.waitFor(2, TimeUnit.SECONDS)
                val txt = proc.inputStream.bufferedReader().use { it.readText() }
                if (!finished) proc.destroyForcibly()
                txt
            }.getOrNull().orEmpty()
        }

        if (textToParse.isBlank()) return null

        val minMaxRegex = Regex("min\\s+(-?\\d+),\\s*max\\s+(-?\\d+)")
        var absMinX: Int? = null
        var absMaxX: Int? = null
        var absMinY: Int? = null
        var absMaxY: Int? = null
        var slotMax = 9
        var hasTracking = false
        var hasBtnTouch = false

        textToParse.lineSequence().forEach { line ->
            when {
                line.contains("BTN_TOUCH") || line.contains("014a") -> hasBtnTouch = true
                line.contains("ABS_MT_TRACKING_ID") || line.contains("0039") -> hasTracking = true
                line.contains("ABS_MT_SLOT") || line.contains("002f") -> {
                    minMaxRegex.find(line)?.let { m ->
                        slotMax = (m.groupValues[2].toIntOrNull() ?: 9).coerceIn(1, 15)
                    }
                }
                line.contains("ABS_MT_POSITION_X") || line.contains("0035") -> {
                    minMaxRegex.find(line)?.let { m ->
                        absMinX = m.groupValues[1].toIntOrNull() ?: 0
                        absMaxX = m.groupValues[2].toIntOrNull()
                    }
                }
                line.contains("ABS_MT_POSITION_Y") || line.contains("0036") -> {
                    minMaxRegex.find(line)?.let { m ->
                        absMinY = m.groupValues[1].toIntOrNull() ?: 0
                        absMaxY = m.groupValues[2].toIntOrNull()
                    }
                }
            }
        }

        val maxX = absMaxX ?: return null
        val maxY = absMaxY ?: return null
        if (!hasTracking || maxX <= 0 || maxY <= 0) return null

        return TouchDeviceSpec(
            eventPath = path,
            absMinX = absMinX ?: 0,
            absMaxX = maxX,
            absMinY = absMinY ?: 0,
            absMaxY = maxY,
            slotMax = slotMax,
            hasBtnTouch = hasBtnTouch
        )
    }

    companion object {
        const val MAX_SLOT_OFFSET = 3
        const val BOOST_SLOT_OFFSET = 3

        internal const val EV_SYN = 0x0000
        internal const val EV_KEY = 0x0001
        internal const val EV_ABS = 0x0003

        internal const val SYN_REPORT = 0x0000
        internal const val BTN_TOOL_FINGER = 0x0145
        internal const val BTN_TOUCH = 0x014a

        internal const val ABS_MT_SLOT = 0x002f
        internal const val ABS_MT_TOUCH_MAJOR = 0x0030
        internal const val ABS_MT_POSITION_X = 0x0035
        internal const val ABS_MT_POSITION_Y = 0x0036
        internal const val ABS_MT_TRACKING_ID = 0x0039
        internal const val ABS_MT_PRESSURE = 0x003a
    }
}

/**
 * Persistent Root daemon launched via `su -c "CLASSPATH=... app_process / com.xa.gamespace.RootTouchDaemon"`.
 * Accepts ultra-fast single-line commands over stdin and writes Slot-9..Slot-6 evdev packets in <0.15ms
 * with atomic `ABS_MT_SLOT` restoration so physical camera swipes never stutter or drop frames.
 */
@Keep
object RootTouchDaemon {
    @JvmStatic
    fun main(args: Array<String>) {
        val engine = KernelTouchEngine()
        if (!engine.initIfPermitted()) {
            println("UNAVAILABLE")
            System.out.flush()
            return
        }
        val spec = engine.deviceSpec!!
        println("READY ${spec.eventPath} ${engine.macroSlot}")
        System.out.flush()

        val reader = BufferedReader(InputStreamReader(System.`in`))
        while (true) {
            val line = try {
                reader.readLine()
            } catch (_: Throwable) {
                break
            } ?: break
            val parts = line.trim().split(' ')
            if (parts.isEmpty()) continue
            when (parts[0]) {
                "PING" -> {
                    println("PONG ${engine.isWritable} ${engine.isLiveBoostReaderActive}")
                    System.out.flush()
                }
                "MACRO_ACTIVE" -> {
                    val active = (parts.getOrNull(1)?.toIntOrNull() ?: 0) == 1
                    engine.setMacroActive(active)
                }
                "BOOST_CFG" -> {
                    TouchAmplifierConfig.fromDaemonArgs(parts)?.let { cfg ->
                        engine.updateBoostConfig(cfg)
                    }
                }
                "BOOST_STATUS" -> {
                    println("BOOST_STATUS ${engine.isLiveBoostReaderActive} ${engine.boostedFramesCount}")
                    System.out.flush()
                }
                "PULSE" -> {
                    if (parts.size >= 8) {
                        val slot = (parts[1].toIntOrNull() ?: 0).coerceIn(0, KernelTouchEngine.MAX_SLOT_OFFSET)
                        val x = parts[2].toFloatOrNull() ?: 0f
                        val y = parts[3].toFloatOrNull() ?: 0f
                        val w = parts[4].toIntOrNull() ?: 1080
                        val h = parts[5].toIntOrNull() ?: 2400
                        val rot = parts[6].toIntOrNull() ?: 0
                        val pressMs = parts[7].toLongOrNull() ?: 10L
                        val physHint = (parts.getOrNull(8)?.toIntOrNull() ?: 0) == 1
                        engine.pulse(slot, x, y, w, h, rot, pressMs, physicalFingerHint = physHint)
                    }
                }
                "DOWN" -> {
                    if (parts.size >= 7) {
                        val slot = (parts[1].toIntOrNull() ?: 0).coerceIn(0, KernelTouchEngine.MAX_SLOT_OFFSET)
                        val x = parts[2].toFloatOrNull() ?: 0f
                        val y = parts[3].toFloatOrNull() ?: 0f
                        val w = parts[4].toIntOrNull() ?: 1080
                        val h = parts[5].toIntOrNull() ?: 2400
                        val rot = parts[6].toIntOrNull() ?: 0
                        val physHint = (parts.getOrNull(7)?.toIntOrNull() ?: 0) == 1
                        engine.down(slot, x, y, w, h, rot, physicalFingerHint = physHint)
                    }
                }
                "MOVE" -> {
                    if (parts.size >= 7) {
                        val slot = (parts[1].toIntOrNull() ?: 0).coerceIn(0, KernelTouchEngine.MAX_SLOT_OFFSET)
                        val x = parts[2].toFloatOrNull() ?: 0f
                        val y = parts[3].toFloatOrNull() ?: 0f
                        val w = parts[4].toIntOrNull() ?: 1080
                        val h = parts[5].toIntOrNull() ?: 2400
                        val rot = parts[6].toIntOrNull() ?: 0
                        engine.move(slot, x, y, w, h, rot)
                    }
                }
                "UP" -> {
                    val slot = (parts.getOrNull(1)?.toIntOrNull() ?: 0).coerceIn(0, KernelTouchEngine.MAX_SLOT_OFFSET)
                    val physHint = (parts.getOrNull(2)?.toIntOrNull() ?: 0) == 1
                    engine.up(slot, physicalFingerHint = physHint)
                }
                "EXIT" -> break
            }
        }
        engine.close()
    }
}
