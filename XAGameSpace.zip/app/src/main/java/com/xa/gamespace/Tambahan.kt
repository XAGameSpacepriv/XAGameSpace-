package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

// Menu TAMBAHAN. Isi pertama: Pendingin.
// Pendingin menurunkan beban render (batas 60 Hz). Ini bisa menurunkan FPS, jadi bersifat opsional.
object Cooler {
    fun isOn(s: Store) = s.get("cooler") == "1"

    // notifikasi saat pendingin dinyalakan/dimatikan
    fun notify(ctx: Context, on: Boolean) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        val ch = "xa_cooler"
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(android.app.NotificationChannel(ch, "Pendingin", android.app.NotificationManager.IMPORTANCE_DEFAULT))
        }
        val b = if (android.os.Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(ctx, ch)
        else @Suppress("DEPRECATION") android.app.Notification.Builder(ctx)
        val n = b.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(if (on) "Pendingin aktif" else "Pendingin mati")
            .setContentText(if (on) "Performa diturunkan agar HP lebih dingin." else "Performa kembali normal.")
            .setAutoCancel(true)
            .build()
        nm.notify(4101, n)
    }
}

class TambahanSheet(private val ctx: Context, private val onProc: () -> Unit, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val status = TextView(ctx)

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(ctx.px(16), ctx.px(14), ctx.px(16), ctx.px(14))
        root.background = Hud.rounded(Color.argb(240, 8, 22, 42), Hud.neon, ctx.pxf(14f), 1.4f)
        root.addView(label("TAMBAHAN", 13f, Hud.neon, true))

        val s = Store(ctx)
        val on = Cooler.isOn(s)
        val chip = label(if (on) "PENDINGIN: NYALA" else "PENDINGIN: MATI", 12f,
            if (on) Color.parseColor("#04141F") else Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(ctx.px(12), ctx.px(9), ctx.px(12), ctx.px(9))
            background = if (on) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(10f), 1f)
            else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
        }
        chip.setOnClickListener {
            Sfx.tap()
            if (!Access.requires(ctx, "Pendingin", false)) return@setOnClickListener
            val nowOn = !Cooler.isOn(s)
            s.put("cooler", if (nowOn) "1" else "0")
            AutoReset.flag(ctx)
            // nyala: batas 60 Hz; mati: kembali ke render bawaan
            val cmd = if (nowOn) RateCmd.renderCmd("60") else RateCmd.renderDefaultCmd()
            Thread {
                val r = Access.run(cmd)
                Cooler.notify(ctx, nowOn)
                chip.post {
                    chip.text = if (nowOn) "PENDINGIN: NYALA" else "PENDINGIN: MATI"
                    chip.setTextColor(if (nowOn) Color.parseColor("#04141F") else Color.WHITE)
                    chip.background = if (nowOn) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(10f), 1f)
                    else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
                    status.text = (if (nowOn) "Pendingin nyala: performa diturunkan agar dingin.\n"
                        else "Pendingin mati: render kembali bawaan.\n") + r.ifBlank { "(berhasil)" }
                }
            }.start()
        }
        root.addView(chip, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(10) })

        status.textSize = 11f
        status.setTextColor(Hud.sub)
        root.addView(status, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(8) })

        root.addView(label("PROSES LATAR", 12f, Hud.neon, true).apply {
            gravity = Gravity.CENTER
            setPadding(ctx.px(12), ctx.px(9), ctx.px(12), ctx.px(9))
            background = Hud.rounded(Color.argb(90, 8, 40, 60), Hud.neon, ctx.pxf(10f), 1f)
            setOnClickListener { Sfx.tap(); onProc() }
        }, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(10) })





        root.addView(label("TUTUP", 11f, Color.WHITE).apply {
            gravity = Gravity.CENTER
            setPadding(ctx.px(12), ctx.px(6), ctx.px(12), ctx.px(6))
            background = Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
            setOnClickListener { Sfx.tap(); onClose() }
        }, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = ctx.px(10); it.gravity = Gravity.END })
    }
}
