package com.xa.gamespace

import android.content.Context

// Unlock dinonaktifkan - semua fitur bebas dipakai
object Unlock {
    fun active(ctx: Context): Boolean = true
    fun grant(ctx: Context, ms: Long) {}
    fun remainingText(ctx: Context): String = ""
    fun progress(ctx: Context): Int = 0
    fun setProgress(ctx: Context, n: Int) {}
    const val ONE_DAY   = 24L * 60 * 60 * 1000
    const val FIVE_DAYS = 5L  * 24 * 60 * 60 * 1000
}
