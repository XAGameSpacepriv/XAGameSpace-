package com.xa.gamespace

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

// Efek suara UI. Semua suara DIBUAT DI KODE (sintesis), tanpa file audio di APK.
// Paket: Lembut (bawaan), Ruang Angkasa, Warp, Kristal, atau Mati.
// Suara hanya berbunyi saat beranda terlihat (homeActive).
object Sfx {
    val packs = listOf(
        "off" to "Mati",
        "space" to "Ruang Angkasa",
        "warp" to "Warp",
        "crystal" to "Kristal",
        "soft" to "Lembut"
    )
    val events = listOf("tap" to "Klik fitur", "swipe" to "Geser", "open" to "Buka panel")
    private const val DEFAULT_PACK = "soft"
    private const val RATE = 44100

    private var sp: SoundPool? = null
    private var prefs: android.content.SharedPreferences? = null
    private val ids = ConcurrentHashMap<String, Int>()
    private val ready: MutableSet<Int> = ConcurrentHashMap.newKeySet()

    // suara hanya boleh terdengar saat beranda (MainActivity) terlihat
    @Volatile var homeActive = false

    var enabled: Boolean
        get() = prefs?.getBoolean("master", true) ?: true
        set(v) { prefs?.edit()?.putBoolean("master", v)?.apply() }

    fun init(ctx: Context) {
        if (sp != null) return
        val a = ctx.applicationContext
        prefs = a.getSharedPreferences("xa_sfx", Context.MODE_PRIVATE)
        // reset sekali ke bawaan terbaru (Lembut; "Buka panel" mati)
        if ((prefs?.getInt("pack_v", 0) ?: 0) < 2) {
            val ed = prefs!!.edit()
            for ((ev, _) in events) ed.remove("pack_$ev")
            ed.putInt("pack_v", 2).apply()
        }
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { _, id, status -> if (status == 0) ready.add(id) }
        sp = p
        Thread {
            val dir = File(a.cacheDir, "sfx_v4").apply { mkdirs() }
            for ((pk, _) in packs) {
                if (pk == "off") continue
                for (ev in events.map { it.first } + "intro") {
                    val f = File(dir, "${pk}_$ev.wav")
                    if (!f.exists()) f.writeBytes(toWav(render(pk, ev)))
                    ids["${pk}_$ev"] = p.load(f.absolutePath, 1)
                }
            }
        }.start()
    }

    // bawaan per kejadian: "Buka panel" mati, sisanya Lembut
    private fun defaultFor(ev: String) = if (ev == "open") "off" else DEFAULT_PACK

    fun pack(ev: String): String {
        val v = prefs?.getString("pack_$ev", defaultFor(ev)) ?: defaultFor(ev)
        return if (packs.any { it.first == v }) v else defaultFor(ev)
    }

    fun setPack(ev: String, pk: String) { prefs?.edit()?.putString("pack_$ev", pk)?.apply() }

    private fun fire(id: Int?, vol: Float) {
        val p = sp ?: return
        if (id == null || id !in ready) return
        try { p.play(id, vol, vol, 1, 0, 1f) } catch (e: Exception) {}
    }

    // key: tap | swipe | open (ikut pengaturan paket suara)
    fun play(key: String, vol: Float = 1f) {
        if (!enabled || !homeActive) return
        val pk = pack(key)
        if (pk == "off") return
        fire(ids["${pk}_$key"], vol)
    }

    // contoh suara saat memilih paket
    fun preview(ev: String, pk: String) {
        if (pk == "off" || !homeActive) return
        fire(ids["${pk}_$ev"], 1f)
    }

    // suara intro masuk game: ikut paket "open"
    fun playIntro(ctx: Context) {
        if (!enabled || !homeActive) return
        val pk = pack("tap")   // intro ikut paket klik (tetap berbunyi walau "Buka panel" mati)
        if (pk == "off") return
        fire(ids["${pk}_intro"], 0.9f)
    }

    fun tap() = play("tap", 0.8f)

    // ================= sintesis =================

    private fun len(ms: Int) = (RATE * ms / 1000f).toInt()

    private fun sweep(f0: Float, f1: Float, ms: Int, vol: Float, k: Float = 3f): FloatArray {
        val n = len(ms)
        val out = FloatArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            val t = i / n.toFloat()
            ph += 2 * PI * (f0 + (f1 - f0) * t) / RATE
            val e = min(1f, i / (0.006f * RATE)) * exp(-k * t)
            out[i] = (sin(ph) * e * vol).toFloat()
        }
        return out
    }

    private fun bell(f: Float, ms: Int, vol: Float): FloatArray {
        val n = len(ms)
        val out = FloatArray(n)
        val parts = arrayOf(1f to 1f, 2.76f to 0.45f, 5.4f to 0.18f)
        for ((r, a) in parts) {
            for (i in 0 until n) {
                val t = i / RATE.toFloat()
                out[i] += (sin(2 * PI * f * r * t) * a * exp(-6.0 * i / n) * vol).toFloat()
            }
        }
        return out
    }

    private fun noise(ms: Int, vol: Float, lp: Float, seed: Long = 7L): FloatArray {
        val n = len(ms)
        val out = FloatArray(n)
        val r = java.util.Random(seed)
        var y = 0f
        for (i in 0 until n) {
            val t = i / n.toFloat()
            y += lp * ((r.nextFloat() * 2f - 1f) - y)
            val e = sin(PI.toFloat() * t)
            out[i] = y * e * vol * 2.5f
        }
        return out
    }

    private fun mixAt(items: List<Pair<Int, FloatArray>>): FloatArray {
        val total = items.maxOf { (off, a) -> len(off) + a.size }
        val out = FloatArray(total)
        for ((off, a) in items) {
            val s = len(off)
            for (i in a.indices) out[s + i] += a[i]
        }
        return out
    }

    fun render(pk: String, ev: String): FloatArray = when (pk) {
        "space" -> when (ev) {
            "tap" -> mixAt(listOf(0 to sweep(1600f, 900f, 110, 0.5f), 0 to bell(2400f, 140, 0.15f)))
            "swipe" -> mixAt(listOf(0 to noise(170, 0.25f, 0.25f), 0 to sweep(300f, 1100f, 170, 0.25f)))
            "open" -> mixAt(listOf(0 to sweep(260f, 1300f, 300, 0.5f), 120 to bell(1300f, 240, 0.18f)))
            else -> mixAt(listOf(0 to sweep(180f, 1800f, 2200, 0.45f, 1.2f), 1400 to bell(1800f, 1200, 0.25f)))
        }
        "warp" -> when (ev) {
            "tap" -> mixAt(listOf(0 to sweep(260f, 120f, 70, 0.7f, 5f)))
            "swipe" -> mixAt(listOf(0 to noise(260, 0.45f, 0.35f, 11L)))
            "open" -> mixAt(listOf(0 to sweep(120f, 1700f, 340, 0.6f), 0 to noise(340, 0.15f, 0.5f, 13L)))
            else -> mixAt(listOf(0 to sweep(90f, 1400f, 2000, 0.5f, 1.2f), 0 to noise(2000, 0.12f, 0.6f, 17L)))
        }
        "crystal" -> when (ev) {
            "tap" -> mixAt(listOf(0 to bell(1320f, 200, 0.5f)))
            "swipe" -> mixAt(listOf(0 to bell(990f, 140, 0.35f)))
            "open" -> mixAt(listOf(0 to bell(880f, 380, 0.4f), 90 to bell(1320f, 380, 0.4f), 180 to bell(1760f, 420, 0.4f)))
            else -> mixAt(listOf(
                0 to bell(880f, 600, 0.35f), 260 to bell(1320f, 600, 0.35f),
                520 to bell(1760f, 600, 0.35f), 780 to bell(2640f, 1400, 0.3f)))
        }
        else -> when (ev) {   // lembut
            "tap" -> mixAt(listOf(0 to sweep(520f, 520f, 120, 0.35f, 2f)))
            "swipe" -> mixAt(listOf(0 to sweep(380f, 380f, 160, 0.25f, 2f)))
            "open" -> mixAt(listOf(0 to sweep(380f, 600f, 220, 0.3f, 2f)))
            else -> mixAt(listOf(0 to sweep(220f, 520f, 1800, 0.3f, 1.2f)))
        }
    }

    private fun toWav(x: FloatArray): ByteArray {
        val dataLen = x.size * 2
        val b = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt(36 + dataLen); b.put("WAVE".toByteArray())
        b.put("fmt ".toByteArray()); b.putInt(16); b.putShort(1); b.putShort(1)
        b.putInt(RATE); b.putInt(RATE * 2); b.putShort(2); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(dataLen)
        for (v in x) b.putShort((v.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
        return b.array()
    }
}
