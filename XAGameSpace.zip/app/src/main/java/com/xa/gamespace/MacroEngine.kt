package com.xa.gamespace

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.random.Random

// Engine macro: logika loop disalin dari GameOverlayService.startShizukuMacroLoop di XAGameSpacepanel.
object MacroEngine {
    private const val KEY = "macro_cfg_json"

    @Volatile
    var cfg: MacroConfig = MacroConfig()
        private set

    /** dipanggil di main thread setiap config berubah (untuk sinkron window overlay) */
    var onChange: (() -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private var store: Store? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    fun load(ctx: Context) {
        if (store != null) return
        val app = ctx.applicationContext
        val st = Store(app)
        store = st
        cfg = fromJson(st.get(KEY))
    }

    fun update(transform: (MacroConfig) -> MacroConfig) {
        cfg = transform(cfg)
        store?.put(KEY, toJson(cfg))
        main.post { onChange?.invoke() }
    }

    fun screenSize(c: Context): IntArray {
        val m = DisplayMetrics()
        (c.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(m)
        return intArrayOf(m.widthPixels, m.heightPixels)
    }

    fun toast(c: Context, msg: String) {
        main.post { Toast.makeText(c, msg, Toast.LENGTH_SHORT).show() }
    }

    /** true = macro berjalan. false = Shizuku/root belum siap. */
    fun start(ctx: Context): Boolean {
        load(ctx)
        if (!cfg.enabled) {
            toast(ctx, "Aktifkan Macro dulu di tab Macro.")
            return false
        }
        if (job?.isActive == true) return true
        ShizukuBridge.init(ctx)
        val st = ShizukuBridge.refresh(ctx, autoTriggerIfReady = true)
        if (!st.canRunPrivileged) {
            toast(ctx, "Aktifkan Shizuku (Wireless Debugging) atau ROOT untuk Macro.")
            return false
        }
        ShizukuBridge.ensureInputServiceBound()
        update { it.copy(isRunning = true) }
        val app = ctx.applicationContext
        job = scope.launch { runLoop(app) }
        return true
    }

    fun stop() {
        job?.cancel()
        job = null
        if (cfg.isRunning) update { it.copy(isRunning = false) }
    }

    fun toggle(ctx: Context) {
        if (cfg.isRunning) stop() else start(ctx)
    }

    // perilaku tombol Trigger, sama dengan panel: tahan = jalan, lepas = berhenti (kecuali mode Hold dimatikan = tap untuk toggle)
    fun onTriggerDown(ctx: Context) {
        // start() memanggil Shizuku/ROOT, jadi jalankan di luar thread UI
        if (cfg.holdToTrigger) scope.launch { start(ctx) }
    }

    fun onTriggerUp(ctx: Context) {
        if (cfg.holdToTrigger) stop() else toggle(ctx)
    }

    private fun finishRun() {
        if (cfg.isRunning) update { it.copy(isRunning = false) }
    }

    private fun rotationOf(c: Context): Int =
        (c.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation

    private suspend fun performMacroTap(
        x: Float,
        y: Float,
        pressMs: Long,
        mode: MacroInjectionMode,
        screenW: Int,
        screenH: Int,
        rotation: Int,
        slotOffset: Int,
        allowShellFallback: Boolean
    ): Boolean {
        if (ShizukuBridge.injectPulse(
                x = x, y = y, pressMs = pressMs, mode = mode,
                screenW = screenW, screenH = screenH, rotation = rotation, slotOffset = slotOffset
            )
        ) return true
        return allowShellFallback && ShizukuBridge.injectTapFallback(x, y, pressMs)
    }

    private suspend fun CoroutineScope.runLoop(ctx: Context) {
        var screen = screenSize(ctx)
        var rotation = rotationOf(ctx)
        var lastMetricsAtMs = SystemClock.uptimeMillis()
        var lastShellFallbackAtMs = 0L
        var consecutiveFailures = 0

        var warnedFailure = false
        fun notifySlowFailure(): Boolean {
            consecutiveFailures++
            if (!warnedFailure) {
                warnedFailure = true
                toast(ctx, "Tap ke game gagal. Pastikan Shizuku aktif (Izinkan) atau ROOT tersedia.")
            }
            if (consecutiveFailures >= 3) {
                toast(ctx, "Aktifkan 'Debugging USB (Setelan Keamanan)' agar Macro bekerja lancar tanpa lag.")
                return true
            }
            return false
        }

        fun live() = isActive && cfg.enabled && cfg.isRunning

        while (live()) {
            val nowMs = SystemClock.uptimeMillis()
            if (nowMs - lastMetricsAtMs >= 550L) {
                screen = screenSize(ctx)
                rotation = rotationOf(ctx)
                lastMetricsAtMs = nowMs
            }
            val screenW = screen[0]
            val screenH = screen[1]
            val cur = cfg
            val mode = cur.injectionMode
            val jitter = cur.randomJitterPx

            fun pointFor(normX: Float, normY: Float): Pair<Float, Float> {
                val jx = if (jitter > 0) Random.nextInt(-jitter, jitter + 1).toFloat() else 0f
                val jy = if (jitter > 0) Random.nextInt(-jitter, jitter + 1).toFloat() else 0f
                return (normX * screenW + jx).coerceIn(10f, (screenW - 10).coerceAtLeast(10).toFloat()) to
                    (normY * screenH + jy).coerceIn(10f, (screenH - 10).coerceAtLeast(10).toFloat())
            }

            val (tx1, ty1) = pointFor(cur.targetNormX, cur.targetNormY)
            val (tx2, ty2) = pointFor(cur.target2NormX, cur.target2NormY)
            val useSecondTarget = cur.enableTarget2 || cur.pattern == MacroPattern.QUICK_SWITCH
            val tapPressMs = if (cur.intervalMs <= 60) {
                cur.holdDurationMs.toLong().coerceIn(5L, 14L)
            } else {
                cur.holdDurationMs.toLong().coerceIn(6L, 38L)
            }
            val shellFallbackAllowed = cur.intervalMs >= 260 && (nowMs - lastShellFallbackAtMs >= 320L)

            suspend fun dispatchTap(x: Float, y: Float, hold: Long, slot: Int): Boolean {
                val ok = performMacroTap(x, y, hold, mode, screenW, screenH, rotation, slot, shellFallbackAllowed)
                if (ok) {
                    consecutiveFailures = 0
                    if (shellFallbackAllowed && !ShizukuBridge.wasRecentInjection(80L)) {
                        lastShellFallbackAtMs = SystemClock.uptimeMillis()
                    }
                    return true
                }
                return !notifySlowFailure()
            }

            when (cur.pattern) {
                MacroPattern.QUICK_SWITCH -> {
                    if (!dispatchTap(tx1, ty1, tapPressMs.coerceAtMost(24L), 0)) break
                    if (!live()) break
                    delay(cur.switchDelayMs.toLong().coerceIn(16L, 1200L))
                    if (!live()) break
                    if (!dispatchTap(tx2, ty2, tapPressMs.coerceAtMost(24L), 1)) break
                    delay(cur.intervalMs.toLong().coerceIn(12L, 2000L))
                }
                MacroPattern.REPEAT -> {
                    if (!dispatchTap(tx1, ty1, tapPressMs, 0)) break
                    if (useSecondTarget && live()) {
                        delay(cur.switchDelayMs.toLong().coerceIn(16L, 1200L))
                        if (live() && !dispatchTap(tx2, ty2, tapPressMs.coerceAtMost(24L), 1)) break
                    }
                    val gapMs = (cur.intervalMs.toLong() - tapPressMs).coerceAtLeast(4L)
                    delay(gapMs)
                }
                MacroPattern.BURST -> {
                    val burstPressMs = cur.holdDurationMs.toLong().coerceIn(5L, 14L)
                    var aborted = false
                    repeat(cur.burstCount.coerceIn(2, 8)) {
                        if (!live() || aborted) return@repeat
                        if (!dispatchTap(tx1, ty1, burstPressMs, 0)) {
                            aborted = true
                            return@repeat
                        }
                        delay(8L)
                    }
                    if (aborted) break
                    if (useSecondTarget && live()) {
                        delay(cur.switchDelayMs.toLong().coerceIn(16L, 1200L))
                        if (live() && !dispatchTap(tx2, ty2, burstPressMs, 1)) break
                    }
                    delay(cur.intervalMs.toLong().coerceIn(14L, 2000L))
                }
                MacroPattern.HOLD -> {
                    val downTime = SystemClock.uptimeMillis()
                    val downOk = ShizukuBridge.injectMotion(
                        MotionEvent.ACTION_DOWN, tx1, ty1, downTime, mode, screenW, screenH, rotation, 0
                    )
                    if (downOk) {
                        consecutiveFailures = 0
                        try {
                            val chunkMs = cur.holdDurationMs.toLong().coerceIn(120L, 1200L)
                            var elapsed = 0L
                            while (live() && elapsed < chunkMs) {
                                delay(30L)
                                elapsed += 30L
                            }
                        } finally {
                            withContext(NonCancellable) {
                                ShizukuBridge.injectMotion(
                                    MotionEvent.ACTION_UP, tx1, ty1, downTime, mode, screenW, screenH, rotation, 0
                                )
                            }
                        }
                        delay(8L)
                    } else if (nowMs - lastShellFallbackAtMs >= 320L) {
                        lastShellFallbackAtMs = nowMs
                        val ok = ShizukuBridge.injectTapFallback(
                            tx1, ty1, cur.holdDurationMs.toLong().coerceIn(120L, 1200L)
                        )
                        if (ok) consecutiveFailures = 0 else if (notifySlowFailure()) break
                    } else {
                        if (notifySlowFailure()) break
                        delay(40L)
                    }
                }
                MacroPattern.SWIPE -> {
                    // versi XA tidak punya TouchConfig, jadi geser lurus ke atas 180px
                    val endX = tx1.coerceIn(20f, (screenW - 20).coerceAtLeast(20).toFloat())
                    val endY = (ty1 - 180f).coerceIn(20f, (screenH - 20).coerceAtLeast(20).toFloat())
                    val dur = cur.holdDurationMs.toLong().coerceIn(60L, 400L)
                    val ok = ShizukuBridge.injectSwipe(tx1, ty1, endX, endY, dur, mode, screenW, screenH, rotation)
                    if (ok) consecutiveFailures = 0 else if (notifySlowFailure()) break
                    delay(cur.intervalMs.toLong().coerceIn(20L, 2000L))
                }
            }
        }
        finishRun()
    }

    // ---------- penyimpanan config (JSON di SharedPreferences) ----------

    private fun toJson(c: MacroConfig): String = JSONObject().apply {
        put("enabled", c.enabled)
        put("pattern", c.pattern.name)
        put("mode", c.injectionMode.name)
        put("triggerScale", c.triggerScale.toDouble())
        put("intervalMs", c.intervalMs)
        put("holdDurationMs", c.holdDurationMs)
        put("randomJitterPx", c.randomJitterPx)
        put("burstCount", c.burstCount)
        put("showTarget", c.showTarget)
        put("triggerNormX", c.triggerNormX.toDouble())
        put("triggerNormY", c.triggerNormY.toDouble())
        put("targetNormX", c.targetNormX.toDouble())
        put("targetNormY", c.targetNormY.toDouble())
        put("enableTarget2", c.enableTarget2)
        put("target2NormX", c.target2NormX.toDouble())
        put("target2NormY", c.target2NormY.toDouble())
        put("switchDelayMs", c.switchDelayMs)
        put("isLocked", c.isLocked)
        put("holdToTrigger", c.holdToTrigger)
        put("lockedOpacity", c.lockedOpacity.toDouble())
    }.toString()

    private fun fromJson(raw: String): MacroConfig {
        if (raw.isBlank()) return MacroConfig()
        return try {
            val o = JSONObject(raw)
            val d = MacroConfig()
            MacroConfig(
                enabled = o.optBoolean("enabled", d.enabled),
                pattern = enumOr(o.optString("pattern"), d.pattern),
                injectionMode = enumOr(o.optString("mode"), d.injectionMode),
                triggerScale = o.optDouble("triggerScale", d.triggerScale.toDouble()).toFloat(),
                intervalMs = o.optInt("intervalMs", d.intervalMs),
                holdDurationMs = o.optInt("holdDurationMs", d.holdDurationMs),
                randomJitterPx = o.optInt("randomJitterPx", d.randomJitterPx),
                burstCount = o.optInt("burstCount", d.burstCount),
                showTarget = o.optBoolean("showTarget", d.showTarget),
                triggerNormX = o.optDouble("triggerNormX", d.triggerNormX.toDouble()).toFloat(),
                triggerNormY = o.optDouble("triggerNormY", d.triggerNormY.toDouble()).toFloat(),
                targetNormX = o.optDouble("targetNormX", d.targetNormX.toDouble()).toFloat(),
                targetNormY = o.optDouble("targetNormY", d.targetNormY.toDouble()).toFloat(),
                enableTarget2 = o.optBoolean("enableTarget2", d.enableTarget2),
                target2NormX = o.optDouble("target2NormX", d.target2NormX.toDouble()).toFloat(),
                target2NormY = o.optDouble("target2NormY", d.target2NormY.toDouble()).toFloat(),
                switchDelayMs = o.optInt("switchDelayMs", d.switchDelayMs),
                isLocked = o.optBoolean("isLocked", d.isLocked),
                holdToTrigger = o.optBoolean("holdToTrigger", d.holdToTrigger),
                lockedOpacity = o.optDouble("lockedOpacity", d.lockedOpacity.toDouble()).toFloat(),
                isRunning = false
            )
        } catch (_: Exception) {
            MacroConfig()
        }
    }

    private inline fun <reified T : Enum<T>> enumOr(name: String, def: T): T =
        runCatching { enumValueOf<T>(name) }.getOrDefault(def)
}
