package com.xa.gamespace

import android.app.Activity
import android.content.Context

// Iklan dinonaktifkan
object Ads {
    fun init(ctx: Context) {}
    fun ready(): Boolean = false
    fun load(ctx: Context) {}
    fun awaitReady(ctx: Context, timeoutMs: Long, onReady: () -> Unit, onTimeout: () -> Unit) {}
    fun show(act: Activity, onReward: () -> Unit, onDismissed: () -> Unit, onFail: () -> Unit) {}
}
