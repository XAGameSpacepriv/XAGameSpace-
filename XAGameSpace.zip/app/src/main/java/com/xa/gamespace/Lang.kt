package com.xa.gamespace

import android.content.Context

// Pilihan bahasa yang tersedia di layar intro.
// Tambah entri baru di LANGS untuk bahasa tambahan.
object Lang {

    data class Entry(val code: String, val flag: String, val name: String)

    val LANGS = listOf(
        Entry("id", "🇮🇩", "Indonesia"),
        Entry("en", "🇺🇸", "English"),
        Entry("ph", "🇵🇭", "Filipino"),
        Entry("ms", "🇲🇾", "Melayu"),
        Entry("th", "🇹🇭", "ภาษาไทย"),
        Entry("vi", "🇻🇳", "Tiếng Việt"),
        Entry("zh", "🇨🇳", "中文"),
        Entry("ar", "🇸🇦", "العربية"),
        Entry("ru", "🇷🇺", "Русский"),
        Entry("pt", "🇧🇷", "Português"),
        Entry("es", "🇪🇸", "Español"),
        Entry("tr", "🇹🇷", "Türkçe"),
        Entry("hi", "🇮🇳", "हिन्दी"),
        Entry("de", "🇩🇪", "Deutsch"),
        Entry("fr", "🇫🇷", "Français"),
        Entry("ja", "🇯🇵", "日本語"),
        Entry("ko", "🇰🇷", "한국어")
    )

    private const val KEY = "app_lang"
    private const val DEFAULT = "id"

    fun get(ctx: Context): String = Store(ctx).get(KEY).ifBlank { DEFAULT }

    fun set(ctx: Context, code: String) = Store(ctx).put(KEY, code)

    fun entry(ctx: Context): Entry = LANGS.firstOrNull { it.code == get(ctx) } ?: LANGS[0]

    // ---- teks yang ditampilkan sesuai bahasa ----

    fun openButton(ctx: Context): String = when (get(ctx)) {
        "id" -> "BUKA GAME SPACE"
        "ph" -> "BUKSAN ANG GAME SPACE"
        "ms" -> "BUKA GAME SPACE"
        "th" -> "เปิด GAME SPACE"
        "vi" -> "MỞ GAME SPACE"
        "zh" -> "打开 GAME SPACE"
        "ar" -> "افتح مساحة الألعاب"
        "ru" -> "ОТКРЫТЬ GAME SPACE"
        "pt" -> "ABRIR GAME SPACE"
        "es" -> "ABRIR GAME SPACE"
        "tr" -> "OYUN ALANINI AÇ"
        "hi" -> "गेम स्पेस खोलें"
        "de" -> "GAME SPACE ÖFFNEN"
        "fr" -> "OUVRIR GAME SPACE"
        "ja" -> "ゲームスペースを開く"
        "ko" -> "게임 공간 열기"
        else -> "OPEN GAME SPACE"
    }

    fun selectLang(ctx: Context): String = s(ctx, "select_lang")

    // ================================================================
    //  s() — ambil string UI sesuai bahasa yang dipilih user
    //  Hanya mengubah teks DI DALAM XAGameSpace, tidak menyentuh sistem.
    // ================================================================
    fun s(ctx: Context, key: String): String = TABLE[get(ctx)]?.get(key)
        ?: TABLE["en"]?.get(key) ?: key

    // Tabel terjemahan: lang_code -> (key -> teks)
    private val TABLE: Map<String, Map<String, String>> = mapOf(

        "id" to mapOf(
            "select_lang"       to "Pilih Bahasa",
            "open_btn"          to "BUKA GAME SPACE",
            "perm_title"        to "PENGATURAN AWAL (OPSIONAL)",
            "perm_overlay_ok"   to "✓ Tampil di atas aplikasi",
            "perm_overlay_no"   to "✗ Tampil di atas aplikasi (tekan Izinkan)",
            "perm_write_ok"     to "✓ Modifikasi sistem",
            "perm_write_no"     to "• Modifikasi sistem (opsional)",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• Root / Shizuku belum ada (opsional)",
            "btn_overlay"       to "Izinkan Tampil di Atas",
            "btn_write"         to "Izinkan Modifikasi Sistem",
            "btn_root"          to "Akses Root / Shizuku",
            "btn_enter"         to "MASUK GAMESPACE",
            "btn_enter_no_perm" to "MASUK TANPA IZIN (fitur tertentu dikunci)",
            "detecting"         to "MENDETEKSI PERANGKAT...",
            "detected"          to "PERANGKAT TERDETEKSI",
            "detect_fail"       to "Deteksi tidak lengkap, tetap lanjut.",
            "lang_btn_prefix"   to "🌐  Bahasa:",
            "lang_dialog_title" to "🌐  Pilih Bahasa"
        ),

        "en" to mapOf(
            "select_lang"       to "Select Language",
            "open_btn"          to "OPEN GAME SPACE",
            "perm_title"        to "INITIAL SETUP (OPTIONAL)",
            "perm_overlay_ok"   to "✓ Display over other apps",
            "perm_overlay_no"   to "✗ Display over other apps (tap Allow)",
            "perm_write_ok"     to "✓ Modify system settings",
            "perm_write_no"     to "• Modify system settings (optional)",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• Root / Shizuku not found (optional)",
            "btn_overlay"       to "Allow Display Over Apps",
            "btn_write"         to "Allow Modify System",
            "btn_root"          to "Access Root / Shizuku",
            "btn_enter"         to "ENTER GAMESPACE",
            "btn_enter_no_perm" to "ENTER WITHOUT PERMISSION (some features locked)",
            "detecting"         to "DETECTING DEVICE...",
            "detected"          to "DEVICE DETECTED",
            "detect_fail"       to "Detection incomplete, continuing anyway.",
            "lang_btn_prefix"   to "🌐  Language:",
            "lang_dialog_title" to "🌐  Select Language"
        ),

        "ph" to mapOf(
            "select_lang"       to "Pumili ng Wika",
            "open_btn"          to "BUKSAN ANG GAME SPACE",
            "perm_title"        to "UNANG SETUP (OPSYONAL)",
            "perm_overlay_ok"   to "✓ Ipakita sa ibabaw ng apps",
            "perm_overlay_no"   to "✗ Ipakita sa ibabaw ng apps (pindutin ang Payagan)",
            "perm_write_ok"     to "✓ Baguhin ang sistema",
            "perm_write_no"     to "• Baguhin ang sistema (opsyonal)",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• Root / Shizuku hindi nahanap (opsyonal)",
            "btn_overlay"       to "Payagan ang Display sa Itaas",
            "btn_write"         to "Payagan ang Pagbabago ng Sistema",
            "btn_root"          to "I-access ang Root / Shizuku",
            "btn_enter"         to "PUMASOK SA GAMESPACE",
            "btn_enter_no_perm" to "PUMASOK NANG WALANG PAHINTULOT",
            "detecting"         to "NIDE-DETECT ANG DEVICE...",
            "detected"          to "NADETECT ANG DEVICE",
            "detect_fail"       to "Hindi kumpleto ang detection, magpatuloy.",
            "lang_btn_prefix"   to "🌐  Wika:",
            "lang_dialog_title" to "🌐  Pumili ng Wika"
        ),

        "ms" to mapOf(
            "select_lang"       to "Pilih Bahasa",
            "open_btn"          to "BUKA GAME SPACE",
            "perm_title"        to "PERSEDIAAN AWAL (PILIHAN)",
            "perm_overlay_ok"   to "✓ Papar atas aplikasi lain",
            "perm_overlay_no"   to "✗ Papar atas aplikasi lain (ketuk Benarkan)",
            "perm_write_ok"     to "✓ Ubah tetapan sistem",
            "perm_write_no"     to "• Ubah tetapan sistem (pilihan)",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• Root / Shizuku tidak dijumpai (pilihan)",
            "btn_overlay"       to "Benarkan Papar Atas Apps",
            "btn_write"         to "Benarkan Ubah Sistem",
            "btn_root"          to "Akses Root / Shizuku",
            "btn_enter"         to "MASUK GAMESPACE",
            "btn_enter_no_perm" to "MASUK TANPA KEBENARAN",
            "detecting"         to "MENGESAN PERANTI...",
            "detected"          to "PERANTI DIKESAN",
            "detect_fail"       to "Pengesanan tidak lengkap, teruskan.",
            "lang_btn_prefix"   to "🌐  Bahasa:",
            "lang_dialog_title" to "🌐  Pilih Bahasa"
        ),

        "th" to mapOf(
            "select_lang"       to "เลือกภาษา",
            "open_btn"          to "เปิด GAME SPACE",
            "perm_title"        to "ตั้งค่าเริ่มต้น (ไม่บังคับ)",
            "perm_overlay_ok"   to "✓ แสดงทับแอปอื่น",
            "perm_overlay_no"   to "✗ แสดงทับแอปอื่น (กดอนุญาต)",
            "perm_write_ok"     to "✓ แก้ไขการตั้งค่าระบบ",
            "perm_write_no"     to "• แก้ไขการตั้งค่าระบบ (ไม่บังคับ)",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• ไม่พบ Root / Shizuku (ไม่บังคับ)",
            "btn_overlay"       to "อนุญาตแสดงทับแอป",
            "btn_write"         to "อนุญาตแก้ไขระบบ",
            "btn_root"          to "เข้าถึง Root / Shizuku",
            "btn_enter"         to "เข้า GAMESPACE",
            "btn_enter_no_perm" to "เข้าโดยไม่มีสิทธิ์",
            "detecting"         to "กำลังตรวจสอบอุปกรณ์...",
            "detected"          to "ตรวจพบอุปกรณ์แล้ว",
            "detect_fail"       to "ตรวจสอบไม่สมบูรณ์ ดำเนินการต่อ",
            "lang_btn_prefix"   to "🌐  ภาษา:",
            "lang_dialog_title" to "🌐  เลือกภาษา"
        ),

        "vi" to mapOf(
            "select_lang"       to "Chọn Ngôn Ngữ",
            "open_btn"          to "MỞ GAME SPACE",
            "perm_title"        to "CÀI ĐẶT BAN ĐẦU (TÙY CHỌN)",
            "perm_overlay_ok"   to "✓ Hiển thị trên ứng dụng khác",
            "perm_overlay_no"   to "✗ Hiển thị trên ứng dụng khác (nhấn Cho phép)",
            "perm_write_ok"     to "✓ Sửa đổi hệ thống",
            "perm_write_no"     to "• Sửa đổi hệ thống (tùy chọn)",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• Không tìm thấy Root / Shizuku (tùy chọn)",
            "btn_overlay"       to "Cho phép hiển thị",
            "btn_write"         to "Cho phép sửa hệ thống",
            "btn_root"          to "Truy cập Root / Shizuku",
            "btn_enter"         to "VÀO GAMESPACE",
            "btn_enter_no_perm" to "VÀO KHÔNG CÓ QUYỀN",
            "detecting"         to "ĐANG PHÁT HIỆN THIẾT BỊ...",
            "detected"          to "ĐÃ PHÁT HIỆN THIẾT BỊ",
            "detect_fail"       to "Phát hiện chưa đầy đủ, tiếp tục.",
            "lang_btn_prefix"   to "🌐  Ngôn ngữ:",
            "lang_dialog_title" to "🌐  Chọn Ngôn Ngữ"
        ),

        "zh" to mapOf(
            "select_lang"       to "选择语言",
            "open_btn"          to "打开 GAME SPACE",
            "perm_title"        to "初始设置（可选）",
            "perm_overlay_ok"   to "✓ 在其他应用上显示",
            "perm_overlay_no"   to "✗ 在其他应用上显示（点击允许）",
            "perm_write_ok"     to "✓ 修改系统设置",
            "perm_write_no"     to "• 修改系统设置（可选）",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• 未找到 Root / Shizuku（可选）",
            "btn_overlay"       to "允许显示在上方",
            "btn_write"         to "允许修改系统",
            "btn_root"          to "访问 Root / Shizuku",
            "btn_enter"         to "进入 GAMESPACE",
            "btn_enter_no_perm" to "无权限进入",
            "detecting"         to "正在检测设备...",
            "detected"          to "设备已检测",
            "detect_fail"       to "检测不完整，继续。",
            "lang_btn_prefix"   to "🌐  语言:",
            "lang_dialog_title" to "🌐  选择语言"
        ),

        "ar" to mapOf(
            "select_lang"       to "اختر اللغة",
            "open_btn"          to "افتح مساحة الألعاب",
            "perm_title"        to "الإعداد الأولي (اختياري)",
            "perm_overlay_ok"   to "✓ العرض فوق التطبيقات",
            "perm_overlay_no"   to "✗ العرض فوق التطبيقات (اضغط سماح)",
            "perm_write_ok"     to "✓ تعديل إعدادات النظام",
            "perm_write_no"     to "• تعديل إعدادات النظام (اختياري)",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• لم يتم العثور على Root / Shizuku (اختياري)",
            "btn_overlay"       to "السماح بالعرض فوق التطبيقات",
            "btn_write"         to "السماح بتعديل النظام",
            "btn_root"          to "الوصول إلى Root / Shizuku",
            "btn_enter"         to "دخول GAMESPACE",
            "btn_enter_no_perm" to "دخول بدون إذن",
            "detecting"         to "جارٍ اكتشاف الجهاز...",
            "detected"          to "تم اكتشاف الجهاز",
            "detect_fail"       to "الاكتشاف غير مكتمل، المتابعة.",
            "lang_btn_prefix"   to "🌐  اللغة:",
            "lang_dialog_title" to "🌐  اختر اللغة"
        ),

        "ru" to mapOf(
            "select_lang"       to "Язык",
            "open_btn"          to "ОТКРЫТЬ GAME SPACE",
            "perm_title"        to "НАЧАЛЬНАЯ НАСТРОЙКА (НЕ ОБЯЗАТЕЛЬНО)",
            "perm_overlay_ok"   to "✓ Отображение поверх приложений",
            "perm_overlay_no"   to "✗ Отображение поверх приложений (нажмите Разрешить)",
            "perm_write_ok"     to "✓ Изменение системных настроек",
            "perm_write_no"     to "• Изменение системных настроек (необязательно)",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• Root / Shizuku не найдены (необязательно)",
            "btn_overlay"       to "Разрешить отображение поверх",
            "btn_write"         to "Разрешить изменение системы",
            "btn_root"          to "Доступ Root / Shizuku",
            "btn_enter"         to "ВОЙТИ В GAMESPACE",
            "btn_enter_no_perm" to "ВОЙТИ БЕЗ РАЗРЕШЕНИЯ",
            "detecting"         to "ОПРЕДЕЛЕНИЕ УСТРОЙСТВА...",
            "detected"          to "УСТРОЙСТВО ОПРЕДЕЛЕНО",
            "detect_fail"       to "Определение неполное, продолжаем.",
            "lang_btn_prefix"   to "🌐  Язык:",
            "lang_dialog_title" to "🌐  Выбор языка"
        ),

        "pt" to mapOf(
            "select_lang"       to "Idioma",
            "open_btn"          to "ABRIR GAME SPACE",
            "perm_title"        to "CONFIGURAÇÃO INICIAL (OPCIONAL)",
            "perm_overlay_ok"   to "✓ Exibir sobre outros apps",
            "perm_overlay_no"   to "✗ Exibir sobre outros apps (toque em Permitir)",
            "perm_write_ok"     to "✓ Modificar configurações do sistema",
            "perm_write_no"     to "• Modificar configurações do sistema (opcional)",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• Root / Shizuku não encontrado (opcional)",
            "btn_overlay"       to "Permitir Exibir Sobre Apps",
            "btn_write"         to "Permitir Modificar Sistema",
            "btn_root"          to "Acessar Root / Shizuku",
            "btn_enter"         to "ENTRAR NO GAMESPACE",
            "btn_enter_no_perm" to "ENTRAR SEM PERMISSÃO",
            "detecting"         to "DETECTANDO DISPOSITIVO...",
            "detected"          to "DISPOSITIVO DETECTADO",
            "detect_fail"       to "Detecção incompleta, continuando.",
            "lang_btn_prefix"   to "🌐  Idioma:",
            "lang_dialog_title" to "🌐  Selecionar Idioma"
        ),

        "es" to mapOf(
            "select_lang"       to "Idioma",
            "open_btn"          to "ABRIR GAME SPACE",
            "perm_title"        to "CONFIGURACIÓN INICIAL (OPCIONAL)",
            "perm_overlay_ok"   to "✓ Mostrar sobre otras apps",
            "perm_overlay_no"   to "✗ Mostrar sobre otras apps (toca Permitir)",
            "perm_write_ok"     to "✓ Modificar configuración del sistema",
            "perm_write_no"     to "• Modificar configuración del sistema (opcional)",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• Root / Shizuku no encontrado (opcional)",
            "btn_overlay"       to "Permitir Mostrar Sobre Apps",
            "btn_write"         to "Permitir Modificar Sistema",
            "btn_root"          to "Acceder Root / Shizuku",
            "btn_enter"         to "ENTRAR AL GAMESPACE",
            "btn_enter_no_perm" to "ENTRAR SIN PERMISO",
            "detecting"         to "DETECTANDO DISPOSITIVO...",
            "detected"          to "DISPOSITIVO DETECTADO",
            "detect_fail"       to "Detección incompleta, continuando.",
            "lang_btn_prefix"   to "🌐  Idioma:",
            "lang_dialog_title" to "🌐  Seleccionar Idioma"
        ),

        "ja" to mapOf(
            "select_lang"       to "言語",
            "open_btn"          to "ゲームスペースを開く",
            "perm_title"        to "初期設定（任意）",
            "perm_overlay_ok"   to "✓ 他のアプリの上に表示",
            "perm_overlay_no"   to "✗ 他のアプリの上に表示（許可をタップ）",
            "perm_write_ok"     to "✓ システム設定を変更",
            "perm_write_no"     to "• システム設定を変更（任意）",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• Root / Shizuku が見つかりません（任意）",
            "btn_overlay"       to "上に表示を許可",
            "btn_write"         to "システム変更を許可",
            "btn_root"          to "Root / Shizuku にアクセス",
            "btn_enter"         to "ゲームスペースに入る",
            "btn_enter_no_perm" to "許可なしで入る",
            "detecting"         to "デバイスを検出中...",
            "detected"          to "デバイスを検出しました",
            "detect_fail"       to "検出が不完全です。続行します。",
            "lang_btn_prefix"   to "🌐  言語:",
            "lang_dialog_title" to "🌐  言語を選択"
        ),

        "ko" to mapOf(
            "select_lang"       to "언어 선택",
            "open_btn"          to "게임 공간 열기",
            "perm_title"        to "초기 설정 (선택 사항)",
            "perm_overlay_ok"   to "✓ 다른 앱 위에 표시",
            "perm_overlay_no"   to "✗ 다른 앱 위에 표시 (허용 탭)",
            "perm_write_ok"     to "✓ 시스템 설정 변경",
            "perm_write_no"     to "• 시스템 설정 변경 (선택 사항)",
            "perm_root_ok"      to "✓ Root",
            "perm_shizuku_ok"   to "✓ Shizuku",
            "perm_access_no"    to "• Root / Shizuku 없음 (선택 사항)",
            "btn_overlay"       to "앱 위에 표시 허용",
            "btn_write"         to "시스템 수정 허용",
            "btn_root"          to "Root / Shizuku 접근",
            "btn_enter"         to "게임스페이스 입장",
            "btn_enter_no_perm" to "권한 없이 입장",
            "detecting"         to "기기 감지 중...",
            "detected"          to "기기 감지 완료",
            "detect_fail"       to "감지 불완전, 계속 진행.",
            "lang_btn_prefix"   to "🌐  언어:",
            "lang_dialog_title" to "🌐  언어 선택"
        )
    )
}
