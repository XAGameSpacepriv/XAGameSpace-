package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// =====================================================================
//  CompileCmd – ART dex2oat compilation via "cmd package compile"
//
//  Mode kompilasi ART (dari cepat ke paling optimal):
//  verify        → hanya verifikasi bytecode, tercepat, cold start lambat
//  quicken       → optimasi ringan, cold start lebih cepat
//  space-profile → hemat RAM + profil (Android default setelah beberapa hari pakai)
//  speed-profile → pakai profil JIT yang ada, cold start cepat
//  speed         → compile penuh tanpa profil, cold start paling cepat
//  everything    → compile semua method, paling lama tapi startup tercepat
// =====================================================================
object CompileCmd {

    data class Mode(
        val key: String,
        val label: String,
        val desc: String,
        val color: Int
    )

    val MODES = listOf(
        Mode("verify",        "Verify",        "Hanya verifikasi — tercepat prosesnya, tapi game masih lambat dibuka.", Color.parseColor("#888888")),
        Mode("quicken",       "Quicken",       "Optimasi ringan bytecode — sedikit lebih cepat dari bawaan.",          Color.parseColor("#64B5F6")),
        Mode("space-profile", "Space+Profile", "Hemat RAM, pakai profil JIT — keseimbangan penyimpanan & kecepatan.",  Color.parseColor("#4FC3F7")),
        Mode("speed-profile", "Speed+Profile", "Pakai profil JIT yang ada — cold start cepat, ukuran sedang.",        Color.parseColor("#38E8A5")),
        Mode("speed",         "Speed",         "Compile penuh semua kode — cold start sangat cepat.",                  Color.parseColor("#FFD54F")),
        Mode("everything",    "Everything",    "Compile semua method — startup tercepat, proses paling lama.",        Color.parseColor("#FF7043"))
    )

    // Compile satu package
    fun compile(pkg: String, mode: String, cb: (String) -> Unit) {
        Thread {
            if (!Access.hasAny()) { cb("Butuh ROOT atau Shizuku."); return@Thread }
            cb("⏳ Menghentikan $pkg...")
            Access.run("am force-stop $pkg")
            Thread.sleep(400)
            cb("⏳ Compile mode=$mode ...")
            val r = Access.run("cmd package compile -m $mode -f $pkg")
            val ok = r.contains("Success") || r.isBlank()
            cb(if (ok) "✓ Selesai ($mode)\n$r".trim() else "✕ Gagal:\n$r")
        }.start()
    }

    // Reset profil (hapus AOT, kembali ke JIT biasa)
    fun resetProfile(pkg: String, cb: (String) -> Unit) {
        Thread {
            if (!Access.hasAny()) { cb("Butuh ROOT atau Shizuku."); return@Thread }
            cb("⏳ Reset profil $pkg...")
            val r = Access.run("cmd package compile --reset $pkg")
            cb(if (r.contains("Success") || r.isBlank()) "✓ Profil direset." else "✕ $r")
        }.start()
    }

    // Dump info kompilasi saat ini
    fun dumpInfo(pkg: String, cb: (String) -> Unit) {
        Thread {
            val r = Access.run("cmd package dump $pkg 2>/dev/null | grep -A2 'compiler\\|dex\\|oat\\|compile'")
            cb(if (r.isBlank()) "Tidak ada info compile tersedia." else r.trim())
        }.start()
    }
}

// =====================================================================
//  CompileSheet – UI panel compile game
// =====================================================================
class CompileSheet(
    private val ctx: Context,
    private val pkg: String,
    private val gameLabel: String,
    private val onClose: () -> Unit
) {
    val root: LinearLayout = LinearLayout(ctx)

    private val log: TextView = TextView(ctx).apply {
        textSize = 10f
        setTextColor(Hud.sub)
        text = "Pilih mode kompilasi di bawah, lalu ketuk tombolnya.\n" +
               "⚠ Game akan dihentikan sementara saat proses berlangsung."
        setPadding(0, px(4), 0, px(8))
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(14), px(10), px(14), px(16))

        // Header
        val header = LinearLayout(ctx)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val titleTv = tv("Compile ART · $gameLabel", 13f, Color.WHITE, true)
        val closeTv = btn("✕") { onClose() }
        header.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(closeTv)
        root.addView(header, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(4) })

        root.addView(tv(
            "Kompilasi ulang bytecode game dengan ART dex2oat agar lebih cepat dibuka. " +
            "Efek terasa pada cold start (pertama kali buka game setelah reboot atau force-stop).",
            10f, Hud.sub
        ), LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(10) })

        // Log area
        root.addView(log, LinearLayout.LayoutParams(-1, -2))

        // Tombol dump info
        root.addView(btn("🔍 Cek Status Kompilasi Saat Ini") {
            log.setTextColor(Hud.sub); log.text = "Mengambil info..."
            CompileCmd.dumpInfo(pkg) { msg ->
                (ctx as? android.app.Activity)?.runOnUiThread { log.setTextColor(Hud.cyan); log.text = msg }
            }
        }, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(12) })

        // Mode tiles
        val modeTitle = tv("Mode Kompilasi", 12f, Color.WHITE, true)
        modeTitle.setPadding(0, 0, 0, px(6))
        root.addView(modeTitle)

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        val modeBox = LinearLayout(ctx)
        modeBox.orientation = LinearLayout.VERTICAL
        sv.addView(modeBox)

        for (mode in CompileCmd.MODES) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(px(10), px(8), px(10), px(8))
            row.background = Hud.rounded(Color.argb(50, 20, 60, 80), Color.argb(80, 46, 200, 255), ctx.pxf(10f), 1f)

            val info = LinearLayout(ctx)
            info.orientation = LinearLayout.VERTICAL
            val nameTv = tv(mode.label, 12f, mode.color, true)
            val descTv = tv(mode.desc, 9.5f, Hud.sub)
            info.addView(nameTv)
            info.addView(descTv)

            val goBtn = btn("▶ Compile") {
                log.setTextColor(Hud.sub); log.text = "Memulai compile ${mode.label}..."
                CompileCmd.compile(pkg, mode.key) { msg ->
                    (ctx as? android.app.Activity)?.runOnUiThread {
                        log.setTextColor(
                            if (msg.startsWith("✓")) Color.parseColor("#38E8A5")
                            else if (msg.startsWith("✕")) Color.parseColor("#FF6B6B")
                            else Hud.sub
                        )
                        log.text = msg
                    }
                }
            }

            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(goBtn)

            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = px(6)
            modeBox.addView(row, lp)
        }

        root.addView(sv, LinearLayout.LayoutParams(-1, -2).also {
            it.bottomMargin = px(10)
        })

        // Reset profil
        root.addView(btn("↺ Reset Profil ART (kembali ke JIT)") {
            log.setTextColor(Hud.sub); log.text = "Mereset profil..."
            CompileCmd.resetProfile(pkg) { msg ->
                (ctx as? android.app.Activity)?.runOnUiThread {
                    log.setTextColor(Color.parseColor("#38E8A5")); log.text = msg
                }
            }
        }, LinearLayout.LayoutParams(-1, -2))
    }

    // ---- helper UI (sama pola dengan TouchSheet) ----
    private fun px(dp: Int): Int = ctx.px(dp)
    private fun tv(t: String, size: Float, col: Int, bold: Boolean = false) = TextView(ctx).apply {
        text = t; textSize = size; setTextColor(col)
        if (bold) typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
    }
    private fun btn(label: String, primary: Boolean = false, onClick: () -> Unit) =
        android.widget.Button(ctx).apply {
            text = label
            textSize = 10.5f
            setTextColor(if (primary) Color.parseColor("#04141F") else Color.WHITE)
            background = Hud.rounded(
                if (primary) Hud.cyan else Color.argb(80, 46, 200, 255),
                if (primary) Hud.cyan else Color.argb(120, 46, 200, 255),
                ctx.pxf(10f), 1f
            )
            setPadding(px(12), px(6), px(12), px(6))
            isAllCaps = false
            setOnClickListener { Sfx.tap(); onClick() }
        }
}
