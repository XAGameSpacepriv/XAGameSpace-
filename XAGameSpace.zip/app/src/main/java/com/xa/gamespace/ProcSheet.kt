package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// Panel PROSES LATAR: daftar proses yang memakai RAM (butuh Shizuku/root).
class ProcSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val list = LinearLayout(ctx)
    private val status = TextView(ctx)

    private fun px(v: Int) = ctx.px(v)

    private fun load() {
        status.text = "Membaca proses..."
        Thread {
            val out = Access.run("ps -A -o RSS,NAME 2>/dev/null")
            val rows = out.lines().mapNotNull { line ->
                val t = line.trim().split(Regex("\\s+"), limit = 2)
                if (t.size < 2) null else t[0].toIntOrNull()?.let { it / 1024 to t[1] }
            }.filter { it.second.contains('.') && !it.second.startsWith("[") }
                .sortedByDescending { it.first }.take(25)
            android.os.Handler(android.os.Looper.getMainLooper()).post { show(rows) }
        }.start()
    }

    private fun show(rows: List<Pair<Int, String>>) {
        list.removeAllViews()
        if (!Access.isRoot && !Access.hasAny()) {
            status.text = "Butuh Shizuku atau root untuk membaca proses."
            return
        }
        status.text = "${rows.size} proses teratas (RAM terpakai)"
        val own = ctx.packageName
        for ((mb, name) in rows) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(px(8), px(6), px(8), px(6))
            }
            row.addView(TextView(ctx).apply {
                text = name; textSize = 11f; setTextColor(if (name == own) Color.parseColor("#3DDC84") else Color.WHITE)
                typeface = Typeface.MONOSPACE
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(ctx).apply { text = "$mb MB"; textSize = 11f; setTextColor(Color.argb(200, 200, 215, 235)) })
            if (name != own) {
                row.addView(TextView(ctx).apply {
                    text = "  TUTUP"; textSize = 10f; setTextColor(Color.parseColor("#FF8080")); typeface = Typeface.DEFAULT_BOLD
                    setOnClickListener {
                        Thread { Access.run("am force-stop $name"); load() }.start()
                    }
                })
            }
            list.addView(row)
        }
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(16), px(14), px(16), px(14))
        root.background = Hud.rounded(Color.argb(240, 8, 22, 42), Hud.neon, ctx.pxf(14f), 1.4f)
        root.addView(TextView(ctx).apply { text = "PROSES LATAR"; textSize = 13f; setTextColor(Hud.neon); typeface = Typeface.DEFAULT_BOLD })
        status.textSize = 11f; status.setTextColor(Hud.sub)
        root.addView(status, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(6) })
        val sv = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; addView(list) }
        root.addView(sv, LinearLayout.LayoutParams(-1, px(300)).also { it.topMargin = px(6) })
        root.addView(TextView(ctx).apply {
            text = "TUTUP"; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(px(12), px(6), px(12), px(6))
            background = Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
            setOnClickListener { Sfx.tap(); onClose() }
        }, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(10); it.gravity = Gravity.END })
        load()
    }
}
