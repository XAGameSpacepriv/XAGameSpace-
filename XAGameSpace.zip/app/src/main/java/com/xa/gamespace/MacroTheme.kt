package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView
import android.view.MotionEvent
import android.graphics.Typeface

// Palet tab Macro di XAGameSpacepanel (ui/theme/Color.kt, tema Obsidian + aksen MONO)
object MT {
    val surface = Color.parseColor("#14161B")
    val card = Color.parseColor("#1A1D24")
    val elevated = Color.parseColor("#222630")
    val border = Color.parseColor("#2B303C")
    val text = Color.parseColor("#F3F5F8")
    val sub = Color.parseColor("#9AA2B2")
    val accent = Color.parseColor("#F3F5F8")
    val onAccent = Color.parseColor("#0B0C0F")
    val cyan = Color.parseColor("#00E5FF")
    val green = Color.parseColor("#2CE59B")
    val amber = Color.parseColor("#FFB740")
    val red = Color.parseColor("#FF5263")

    fun box(c: Context, fill: Int, stroke: Int, radiusDp: Float = 10f): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = c.pxf(radiusDp)
            setStroke(c.px(1).coerceAtLeast(1), stroke)
        }

    // latar sheet macro: solid, sama dengan kartu panel
    fun sheetBg(c: Context): GradientDrawable = box(c, surface, border, 16f)

    // tombol: selected = aksen putih dengan teks gelap, lainnya = kartu elevated
    fun button(c: Context, label: String, primary: Boolean = false, color: Int = text, onClick: () -> Unit): TextView =
        TextView(c).apply {
            text = label
            textSize = 11f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            isClickable = true
            setTextColor(if (primary) onAccent else color)
            background = if (primary) box(c, accent, accent) else box(c, elevated, border)
            setPadding(c.px(12), c.px(8), c.px(12), c.px(8))
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.alpha = 0.7f
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
                }
                false
            }
            setOnClickListener { Sfx.tap(); onClick() }
        }
}
