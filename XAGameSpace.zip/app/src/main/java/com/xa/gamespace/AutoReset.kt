package com.xa.gamespace

import android.content.Context

// Setelan dari panel dikembalikan ke bawaan saat kembali ke GameSpace (keluar dari game).
object AutoReset {
    fun flag(ctx: Context) {
        Store(ctx).put("applied", "1")
    }

    fun run(ctx: Context) {
        val st = Store(ctx)
        if (Access.hasAny()) {
            Access.run(
                Texture.resetCmd() + "\n" +
                    RateCmd.renderDefaultCmd() + "\n" +
                    RateCmd.gpuVsyncCmd(false) + "\n" +
                    "settings put secure accessibility_display_daltonizer_enabled 0\n" +
                    "settings put secure accessibility_display_inversion_enabled 0"
            )
        }
        FilterLayer.clear(ctx)
        st.put("cooler", "0")
        st.put("render_light", "")
        st.put("filter_idx", "0")
        st.put(Texture.KEY_APPLIED, "")
        st.crossOn = false
        st.put("applied", "")
    }
}
