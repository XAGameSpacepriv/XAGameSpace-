package com.xa.gamespace

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// Menu bawah yang meluncur dari bawah ke atas (gaya Game Space Center):
// sidebar kiri berisi nama fitur, panel kanan berisi fitur yang dipilih.
// Isi kanan diambil dari tile menu yang sudah ada, supaya logika tiap fitur tidak ditulis ulang.
class MenuCenter(private val a: MainActivity, tiles: List<TextView>, private val onClose: () -> Unit) {
    val root = LinearLayout(a)
    private val right = FrameLayout(a)
    private val rows = ArrayList<TextView>()
    private val items: List<Pair<String, TextView>> = tiles.map {
        it.text.toString().replace(Regex("^[^A-Za-z]+"), "").trim() to it
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(248, 8, 14, 34), Color.argb(252, 4, 8, 22)))
        root.setPadding(a.px(14), a.px(12), a.px(14), a.px(14))
        root.isClickable = true

        // header: kembali, judul, tutup
        val header = LinearLayout(a)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val back = TextView(a)
        back.text = "←"
        back.textSize = 20f
        back.setTextColor(Color.WHITE)
        back.setPadding(a.px(8), a.px(4), a.px(12), a.px(4))
        back.setOnClickListener { onClose() }
        header.addView(back)
        val title = TextView(a)
        title.text = "XAGameSpace Center"
        title.textSize = 15f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(Color.parseColor("#3CC8FF"))
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val close = TextView(a)
        close.text = "✕"
        close.textSize = 18f
        close.setTextColor(Color.WHITE)
        close.setPadding(a.px(12), a.px(4), a.px(8), a.px(4))
        close.setOnClickListener { onClose() }
        header.addView(close)
        root.addView(header, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = a.px(10) })

        // badan: sidebar kiri + panel kanan
        val body = LinearLayout(a)
        body.orientation = LinearLayout.HORIZONTAL
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        val list = LinearLayout(a)
        list.orientation = LinearLayout.VERTICAL
        items.forEachIndexed { i, (label, _) ->
            val t = TextView(a)
            t.text = "◆   $label"
            t.textSize = 12.5f
            t.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            t.setPadding(a.px(14), a.px(12), a.px(8), a.px(12))
            t.minimumHeight = a.px(46)
            t.setOnClickListener { select(i) }
            rows.add(t)
            list.addView(t, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = a.px(6) })
        }
        sv.addView(list)
        body.addView(sv, LinearLayout.LayoutParams(0, -1, 0.34f).also { it.rightMargin = a.px(10) })

        val card = FrameLayout(a)
        card.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(230, 22, 16, 64), Color.argb(236, 10, 22, 40))).apply {
            cornerRadius = a.px(16).toFloat()
            setStroke(a.px(1), Color.argb(130, 60, 200, 255))
        }
        card.addView(right, FrameLayout.LayoutParams(-1, -1))
        body.addView(card, LinearLayout.LayoutParams(0, -1, 0.66f))
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    // mulai dari fitur pertama
    fun start() {
        if (items.isNotEmpty()) select(0)
    }

    private fun select(i: Int) {
        rows.forEachIndexed { k, t -> style(t, k == i) }
        right.removeAllViews()
        a.embedTarget = right
        try {
            items[i].second.performClick()
        } finally {
            a.embedTarget = null
        }
        // fitur tanpa panel sendiri (mis. Render Ringan, Mic): tampilkan kartu dengan tombol Jalankan
        if (right.childCount == 0) {
            val box = LinearLayout(a)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(a.px(16), a.px(16), a.px(16), a.px(16))
            val t = TextView(a)
            t.text = items[i].first
            t.textSize = 16f
            t.setTypeface(null, Typeface.BOLD)
            t.setTextColor(Color.parseColor("#3CC8FF"))
            box.addView(t, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = a.px(12) })
            val go = TextView(a)
            go.text = "JALANKAN"
            go.textSize = 13f
            go.gravity = Gravity.CENTER
            go.setTypeface(null, Typeface.BOLD)
            go.setTextColor(Color.parseColor("#04141F"))
            go.setPadding(a.px(12), a.px(12), a.px(12), a.px(12))
            go.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#5CE8FF"), Color.parseColor("#B05CFF"))).apply {
                cornerRadius = a.px(12).toFloat()
            }
            go.setOnClickListener { Sfx.tap(); items[i].second.performClick() }
            box.addView(go, LinearLayout.LayoutParams(-1, -2))
            right.addView(box, FrameLayout.LayoutParams(-1, -2))
        }
    }

    private fun style(t: TextView, on: Boolean) {
        t.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        t.setTextColor(if (on) Color.parseColor("#04141F") else Color.WHITE)
        t.background = if (on) {
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#5CE8FF"), Color.parseColor("#B05CFF"))).apply {
                cornerRadius = a.px(12).toFloat()
            }
        } else {
            GradientDrawable().apply {
                cornerRadius = a.px(12).toFloat()
                setColor(Color.argb(170, 16, 28, 52))
                setStroke(a.px(1), Color.argb(90, 60, 200, 255))
            }
        }
    }
}
