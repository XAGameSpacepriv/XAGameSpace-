package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

// Deteksi perangkat & driver. Bagian tanpa root: model, SoC, GPU, kernel, layar, RAM.
// Bagian ANGLE butuh Shizuku/root (membaca library di /system).
object DeviceInfo {
    fun collect(ctx: Context): List<Pair<String, String>> {
        val gpu = GpuDetect.detect()
        val prof = GpuDetect.profile(gpu.vendor)
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        val hz = try { wm.defaultDisplay.refreshRate.toInt() } catch (e: Exception) { 0 }
        val ram = try {
            File("/proc/meminfo").readLines().first { it.startsWith("MemTotal") }
                .filter { it.isDigit() }.toInt() / 1024
        } catch (e: Exception) { 0 }
        val angle = if (Access.isRoot || Access.hasAny())
            Access.run(GpuDetect.ANGLE_CHECK_CMD).lines().filter { it.isNotBlank() }.let {
                if (it.isEmpty()) "tidak ditemukan" else "ada (${it.size})"
            }
        else "butuh Shizuku/root untuk dicek"
        return listOf(
            "Perangkat" to "${Build.MANUFACTURER} ${Build.MODEL}",
            "Board / device" to "${Build.BOARD} / ${Build.DEVICE}",
            "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "Kernel" to (System.getProperty("os.version") ?: "?"),
            "ABI" to (Build.SUPPORTED_ABIS.firstOrNull() ?: "?"),
            "SoC" to gpu.soc,
            "GPU" to "${gpu.vendor} · ${gpu.model}",
            "EGL driver" to gpu.egl,
            "ANGLE" to angle,
            "RAM" to "$ram MB",
            "CPU core" to "${Runtime.getRuntime().availableProcessors()}",
            "Layar" to "${m.widthPixels}x${m.heightPixels} · ${hz} Hz",
            "Kelas" to AiTune.detect().tier,
            "Rekomendasi" to "${Texture.NAMES.getOrElse(prof.level) { "Asli" }} · ${prof.note}"
        )
    }
}

class DeviceSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(ctx.px(16), ctx.px(14), ctx.px(16), ctx.px(14))
        root.background = Hud.rounded(Color.argb(240, 8, 22, 42), Hud.neon, ctx.pxf(14f), 1.4f)
        root.addView(TextView(ctx).apply {
            text = "DETEKSI PERANGKAT"; textSize = 13f; setTextColor(Hud.neon); typeface = Typeface.DEFAULT_BOLD
        })
        val body = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        for ((k, v) in DeviceInfo.collect(ctx)) {
            body.addView(TextView(ctx).apply {
                text = "$k : $v"; textSize = 11f; setTextColor(Color.argb(230, 220, 240, 255))
                typeface = Typeface.MONOSPACE
                setPadding(0, ctx.px(3), 0, ctx.px(3))
            })
        }
        val sv = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; addView(body) }
        root.addView(sv, LinearLayout.LayoutParams(-1, ctx.px(300)).also { it.topMargin = ctx.px(8) })
        root.addView(TextView(ctx).apply {
            text = "TUTUP"; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(ctx.px(12), ctx.px(6), ctx.px(12), ctx.px(6))
            background = Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
            setOnClickListener { Sfx.tap(); onClose() }
        }, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = ctx.px(10); it.gravity = Gravity.END })
    }
}

// Info perangkat lengkap: membaca data yang sudah tersimpan saat layar deteksi pertama.
class DeviceInfoSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(ctx.px(16), ctx.px(14), ctx.px(16), ctx.px(14))
        root.background = Hud.rounded(Color.argb(240, 8, 22, 42), Hud.neon, ctx.pxf(14f), 1.4f)
        root.addView(TextView(ctx).apply {
            text = "INFO PERANGKAT"; textSize = 13f; setTextColor(Hud.neon); typeface = Typeface.DEFAULT_BOLD
        })
        val info = Store(ctx).get("dev_info").ifBlank { "Data belum tersimpan. Buka ulang aplikasi." }
        val body = TextView(ctx).apply {
            text = info; textSize = 11f; setTextColor(Color.argb(230, 220, 240, 255))
            typeface = Typeface.MONOSPACE
        }
        val sv = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; addView(body) }
        root.addView(sv, LinearLayout.LayoutParams(-1, ctx.px(320)).also { it.topMargin = ctx.px(8) })
        root.addView(TextView(ctx).apply {
            text = "TUTUP"; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(ctx.px(12), ctx.px(6), ctx.px(12), ctx.px(6))
            background = Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
            setOnClickListener { Sfx.tap(); onClose() }
        }, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = ctx.px(10); it.gravity = Gravity.END })
    }
}
