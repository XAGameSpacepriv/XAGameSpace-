package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.PowerManager
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.widget.NestedScrollView

// =====================================================================
//  ThermalCmd – semua command thermal (ROOT dan non-ROOT)
//
//  Mode tersedia:
//  STOCK          → kembalikan thermal bawaan sistem
//  COOL           → thermal hemat/dingin (Xiaomi sconfig=12, OPLUS=1)
//  BYPASS         → nonaktifkan throttle (bypass thermal daemon) [ROOT]
//  MAX_35         → jaga suhu ≤ 35°C via closed-loop CPU cap [ROOT]
//  MAX_40         → jaga suhu ≤ 40°C via closed-loop CPU cap [ROOT]
//  MAX_50         → jaga suhu ≤ 50°C via closed-loop CPU cap [ROOT]
//
//  Jalur sysfs dicoba berurutan; jika tidak ada, skip (tidak error).
//  Semua perintah diakhiri "|| true" agar tidak abort jika gagal.
// =====================================================================
object ThermalCmd {

    enum class Mode(val label: String, val desc: String, val needRoot: Boolean) {
        STOCK(
            "Bawaan Sistem",
            "Kembalikan thermal ke default — throttle normal kembali aktif.",
            false
        ),
        COOL(
            "Mode Dingin",
            "Aktifkan cooling agresif OEM — cocok saat baterai panas atau charging.",
            false
        ),
        BYPASS(
            "Bypass Thermal",
            "Nonaktifkan daemon thermal sepenuhnya — tidak ada throttle. ⚠ Gunakan sebentar saja!",
            true
        ),
        MAX_35(
            "Batas Maks 35°C",
            "Jaga suhu ≤ 35°C dengan membatasi CPU saat mendekati batas.",
            true
        ),
        MAX_40(
            "Batas Maks 40°C",
            "Jaga suhu ≤ 40°C — keseimbangan performa & panas.",
            true
        ),
        MAX_50(
            "Batas Maks 50°C",
            "Jaga suhu ≤ 50°C — performa tinggi, toleransi panas lebih longgar.",
            true
        )
    }

    // Jalur sysfs OEM
    private fun w(path: String, value: String) =
        "[ -w '$path' ] && echo $value > '$path' 2>/dev/null || true"

    fun buildCmd(mode: Mode, pkg: String? = null): String {
        val pkgLine = if (pkg != null && Build.VERSION.SDK_INT >= 31)
            "cmd game mode ${if (mode == Mode.COOL) "battery" else "performance"} $pkg 2>/dev/null || true\n"
        else ""

        return pkgLine + when (mode) {
            Mode.STOCK -> """
                cmd thermalservice reset 2>/dev/null || true
                ${w("/sys/class/thermal/thermal_message/sconfig", "0")}
                ${w("/sys/devices/virtual/thermal/thermal_message/sconfig", "0")}
                ${w("/sys/class/thermal/thermal_message/balance_mode", "0")}
                ${w("/sys/module/msm_thermal/parameters/enabled", "Y")}
                ${w("/sys/module/msm_thermal/core_control/enabled", "1")}
                ${w("/proc/oplus_thermal/thermal_level", "0")}
                for m in /sys/class/thermal/thermal_zone*/mode; do [ -w "${'$'}m" ] && echo enabled > "${'$'}m" 2>/dev/null; done || true
                start thermal-engine 2>/dev/null || true
                start mi_thermald 2>/dev/null || true
            """.trimIndent()

            Mode.COOL -> """
                cmd thermalservice reset 2>/dev/null || true
                ${w("/sys/class/thermal/thermal_message/sconfig", "12")}
                ${w("/sys/devices/virtual/thermal/thermal_message/sconfig", "12")}
                ${w("/sys/class/thermal/thermal_message/balance_mode", "1")}
                ${w("/proc/oplus_thermal/thermal_level", "1")}
                start thermal-engine 2>/dev/null || true
                start mi_thermald 2>/dev/null || true
            """.trimIndent()

            Mode.BYPASS -> """
                cmd thermalservice override-status 0 2>/dev/null || true
                cmd power set-fixed-performance-mode-enabled true 2>/dev/null || true
                ${w("/sys/class/thermal/thermal_message/sconfig", "20")}
                ${w("/sys/devices/virtual/thermal/thermal_message/sconfig", "20")}
                ${w("/sys/module/msm_thermal/parameters/enabled", "N")}
                ${w("/sys/module/msm_thermal/core_control/enabled", "0")}
                ${w("/proc/oplus_thermal/thermal_level", "0")}
                for m in /sys/class/thermal/thermal_zone*/mode; do [ -w "${'$'}m" ] && echo disabled > "${'$'}m" 2>/dev/null; done || true
                stop thermal-engine 2>/dev/null || true
                stop mi_thermald 2>/dev/null || true
            """.trimIndent()

            Mode.MAX_35 -> buildMaxCmd(35)
            Mode.MAX_40 -> buildMaxCmd(40)
            Mode.MAX_50 -> buildMaxCmd(50)
        }
    }

    private fun buildMaxCmd(limitC: Int): String {
        // CPU cap% sesuai target: 35°C=65%, 40°C=78%, 50°C=90%
        val capPct = when (limitC) { 35 -> 65; 40 -> 78; else -> 90 }
        return """
            cmd thermalservice override-status 0 2>/dev/null || true
            ${w("/sys/class/thermal/thermal_message/sconfig", "10")}
            ${w("/sys/devices/virtual/thermal/thermal_message/sconfig", "10")}
            ${w("/sys/class/thermal/thermal_message/balance_mode", "0")}
            ${w("/proc/oplus_thermal/thermal_level", "0")}
            for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
              maxf=${'$'}(cat "${'$'}cpu/cpuinfo_max_freq" 2>/dev/null)
              [ -z "${'$'}maxf" ] && continue
              capf=${'$'}(( maxf * $capPct / 100 ))
              [ -w "${'$'}cpu/scaling_max_freq" ] && echo ${'$'}capf > "${'$'}cpu/scaling_max_freq" 2>/dev/null || true
            done
            start thermal-engine 2>/dev/null || true
        """.trimIndent()
    }

    // Baca suhu saat ini dari thermal_zone0
    fun readTempC(ctx: Context): Float {
        // Coba baca langsung dulu
        try {
            val f = java.io.File("/sys/class/thermal/thermal_zone0/temp")
            if (f.canRead()) {
                val raw = f.readText().trim().toFloat()
                return when {
                    raw > 1000f -> raw / 1000f
                    raw > 150f -> raw / 10f
                    else -> raw
                }
            }
        } catch (_: Exception) {}
        // Fallback: PowerManager API 29+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager
                // getCurrentThermalStatus tidak ada di semua versi — cukup return -1
            } catch (_: Exception) {}
        }
        return -1f
    }

    fun thermalStatusLabel(ctx: Context): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "Normal"
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return "Normal"
        return try {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE     -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT    -> "Hangat"
                PowerManager.THERMAL_STATUS_MODERATE -> "Throttle Sedang"
                PowerManager.THERMAL_STATUS_SEVERE   -> "Throttle Berat"
                PowerManager.THERMAL_STATUS_CRITICAL -> "⚠ Kritis!"
                else                                  -> "Normal"
            }
        } catch (_: Exception) { "Normal" }
    }
}

// =====================================================================
//  MacroSheet – fitur macro (auto-tap / rapid-fire) di overlay game
//  Menggunakan AccessibilityService atau Shizuku input tap
// =====================================================================
object MacroCmd {
    data class MacroDef(
        val name: String,
        val desc: String,
        // koordinat tap dan interval ms
        val taps: List<Triple<Int, Int, Long>>  // x, y, delayAfterMs
    )

    // Preset macro umum untuk FPS game
    val PRESETS = listOf(
        MacroDef("Rapid Fire",
            "Auto-tap cepat di posisi layar — cocok untuk tombol tembak.",
            listOf(Triple(540, 960, 50L))),
        MacroDef("Double Tap",
            "Dua tap cepat berurutan.",
            listOf(Triple(540, 960, 30L), Triple(540, 960, 30L))),
        MacroDef("Swipe Kiri",
            "Geser layar ke kiri.",
            listOf(Triple(800, 960, 20L), Triple(200, 960, 50L))),
        MacroDef("Swipe Kanan",
            "Geser layar ke kanan.",
            listOf(Triple(200, 960, 20L), Triple(800, 960, 50L)))
    )

    fun buildTapCmd(x: Int, y: Int): String = "input tap $x $y 2>/dev/null || true"
}

// =====================================================================
//  ThermalSheet – UI panel thermal di overlay game
// =====================================================================
class ThermalSheet(
    private val ctx: Context,
    private val pkg: String?,
    private val onClose: () -> Unit
) {
    val root: LinearLayout = LinearLayout(ctx)
    private val store = Store(ctx)
    private val statusTv = TextView(ctx)
    private val tempTv = TextView(ctx)
    private var monitorThread: Thread? = null
    private var monitoring = false

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(14), px(10), px(14), px(16))

        // Header
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(tv("🌡 Thermal", 14f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(btn("✕") { stopMonitor(); onClose() })
        root.addView(header, lp(-1, -2).also { it.bottomMargin = px(4) })

        // Suhu live + status
        val tempCard = card()
        val tempRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tempTv.textSize = 28f
        tempTv.typeface = Typeface.DEFAULT_BOLD
        tempTv.setTextColor(Color.parseColor("#38E8A5"))
        tempTv.text = "--°C"
        statusTv.textSize = 10f
        statusTv.setTextColor(Hud.sub)
        statusTv.text = "Membaca..."
        val tempInfo = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        tempInfo.addView(tempTv)
        tempInfo.addView(statusTv)
        tempRow.addView(tempInfo, LinearLayout.LayoutParams(0, -2, 1f))
        tempRow.addView(btn("🔄 Refresh") { readTemp() })
        tempCard.addView(tempRow)
        root.addView(tempCard, lp(-1, -2).also { it.bottomMargin = px(8) })

        // Mode Thermal
        root.addView(tv("Mode Thermal", 12f, Color.WHITE, true), lp(-1, -2).also { it.bottomMargin = px(6) })

        val sv = NestedScrollView(ctx).apply { isVerticalScrollBarEnabled = false }
        val modeBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        for (mode in ThermalCmd.Mode.values()) {
            val needRoot = mode.needRoot
            val hasAccess = if (needRoot) Access.isRoot else Access.hasAny()
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(px(10), px(10), px(10), px(10))
                background = Hud.rounded(Color.argb(50, 20, 60, 80), Color.argb(80, 46, 200, 255), ctx.pxf(10f), 1f)
            }

            // warna mode
            val modeColor = when (mode) {
                ThermalCmd.Mode.BYPASS  -> Color.parseColor("#FF6B6B")
                ThermalCmd.Mode.MAX_35  -> Color.parseColor("#4FC3F7")
                ThermalCmd.Mode.MAX_40  -> Color.parseColor("#38E8A5")
                ThermalCmd.Mode.MAX_50  -> Color.parseColor("#FFD54F")
                ThermalCmd.Mode.COOL    -> Color.parseColor("#64B5F6")
                ThermalCmd.Mode.STOCK   -> Color.parseColor("#AAAAAA")
            }

            val info = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            val nameRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            nameRow.addView(tv(mode.label, 12f, modeColor, true))
            if (needRoot) {
                val tag = tv(" ROOT", 8f, Color.parseColor("#FFC24B"), true)
                tag.setPadding(px(4), 0, 0, 0)
                nameRow.addView(tag)
            }
            info.addView(nameRow)
            info.addView(tv(mode.desc, 9.5f, Hud.sub))

            val applyBtn = btn("▶") {
                if (!hasAccess && mode.needRoot) {
                    statusTv.text = "Butuh ROOT untuk mode ini."
                    return@btn
                }
                applyMode(mode)
            }
            if (!hasAccess && mode.needRoot) applyBtn.alpha = 0.4f

            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(applyBtn)
            modeBox.addView(row, lp(-1, -2).also { it.bottomMargin = px(6) })
        }

        sv.addView(modeBox)
        root.addView(sv, lp(-1, 0, 1f))

        // Tombol bawah
        root.addView(btn("↺ Reset ke Bawaan") { applyMode(ThermalCmd.Mode.STOCK) },
            lp(-1, -2).also { it.topMargin = px(8); it.bottomMargin = px(4) })

        // Mulai monitor suhu
        startMonitor()
        readTemp()
    }

    private fun applyMode(mode: ThermalCmd.Mode) {
        statusTv.setTextColor(Hud.sub)
        statusTv.text = "Menerapkan ${mode.label}..."
        Thread {
            val cmd = ThermalCmd.buildCmd(mode, pkg)
            val r = Access.run(cmd)
            (ctx as? android.app.Activity)?.runOnUiThread {
                statusTv.setTextColor(Color.parseColor("#38E8A5"))
                statusTv.text = "✓ ${mode.label} diterapkan"
                store.put("thermal_mode", mode.name)
                readTemp()
            }
        }.start()
    }

    private fun readTemp() {
        Thread {
            val t = ThermalCmd.readTempC(ctx)
            val sysLabel = ThermalCmd.thermalStatusLabel(ctx)
            (ctx as? android.app.Activity)?.runOnUiThread {
                if (t > 0) {
                    tempTv.text = "%.1f°C".format(t)
                    tempTv.setTextColor(when {
                        t >= 50f -> Color.parseColor("#FF6B6B")
                        t >= 40f -> Color.parseColor("#FFD54F")
                        t >= 35f -> Color.parseColor("#FFC24B")
                        else     -> Color.parseColor("#38E8A5")
                    })
                } else {
                    tempTv.text = "--°C"
                }
                statusTv.text = sysLabel
            }
        }.start()
    }

    private fun startMonitor() {
        monitoring = true
        monitorThread = Thread {
            while (monitoring) {
                try { Thread.sleep(5000) } catch (_: InterruptedException) { break }
                if (!monitoring) break
                readTemp()
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stopMonitor() { monitoring = false; monitorThread?.interrupt() }

    // ---- helpers ----
    private fun px(dp: Int) = ctx.px(dp)
    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)
    private fun tv(t: String, size: Float, col: Int = Color.WHITE, bold: Boolean = false) =
        TextView(ctx).apply {
            text = t; textSize = size; setTextColor(col)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
    private fun btn(label: String, primary: Boolean = false, onClick: () -> Unit) =
        android.widget.Button(ctx).apply {
            text = label; textSize = 10.5f; isAllCaps = false
            setTextColor(if (primary) Color.parseColor("#04141F") else Color.WHITE)
            background = Hud.rounded(
                if (primary) Hud.cyan else Color.argb(80, 46, 200, 255),
                if (primary) Hud.cyan else Color.argb(120, 46, 200, 255),
                ctx.pxf(10f), 1f
            )
            setPadding(px(12), px(6), px(12), px(6))
            setOnClickListener { Sfx.tap(); onClick() }
        }
    private fun card() = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(px(10), px(10), px(10), px(10))
        background = Hud.rounded(Color.argb(50, 20, 60, 80), Color.argb(80, 46, 200, 255), ctx.pxf(10f), 1f)
    }
}
