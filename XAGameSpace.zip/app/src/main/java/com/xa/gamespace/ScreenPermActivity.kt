package com.xa.gamespace

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast

// Dialog izin rekam layar. Hasil izin diserahkan ke ScreenRecService,
// yang menjalankan foreground service lebih dulu sebelum memakai MediaProjection.
class ScreenPermActivity : Activity() {
    private val reqCode = 5150

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(0, 0)
        if (Store(this).get("rec_pending") == "perm_mic") {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 5151)
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        Store(this).put("rec_pending", "")
        val ok = grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED
        Toast.makeText(this, if (ok) "Mic diizinkan. Tekan MULAI REKAM lagi." else "Izin mic ditolak", Toast.LENGTH_SHORT).show()
        finish()
        overridePendingTransition(0, 0)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCode && resultCode == RESULT_OK && data != null) {
            val mode = Store(this).get("rec_pending")
            Store(this).put("rec_pending", "")
            val i = Intent(this, ScreenRecService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
                .putExtra("mode", mode)
            try {
                startForegroundService(i)
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal memulai rekam: ${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "Izin rekam layar dibatalkan", Toast.LENGTH_SHORT).show()
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
