package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// 6 filter layar.
// Grayscale & Invert: pengaturan aksesibilitas sistem (butuh Shizuku/root, lewat WRITE_SECURE_SETTINGS).
// Hangat, Dingin, Redup: lapisan warna di atas layar (tanpa root, butuh izin "tampil di atas aplikasi").
// Catatan: lapisan warna tidak bisa menambah kontras/saturasi sungguhan; "Redup", "Vivid", "Full Color" adalah pendekatan.
object FilterLayer {
    val NAMES = listOf("Normal", "Grayscale", "Invert", "Hangat", "Dingin", "Redup", "Vivid", "Full Color")
    private var layer: View? = null

    private fun removeLayer(ctx: Context) {
        val v = layer ?: return
        try { (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) {}
        layer = null
    }

    private fun addTint(ctx: Context, color: Int): String {
        if (!android.provider.Settings.canDrawOverlays(ctx)) return "Izinkan 'tampil di atas aplikasi' untuk filter ini."
        android.os.Handler(android.os.Looper.getMainLooper()).post { addTintNow(ctx, color) }
        return ""
    }

    private fun addTintNow(ctx: Context, color: Int) {
        try { addTintInner(ctx, color) } catch (e: Exception) {}
    }

    private fun addTintInner(ctx: Context, color: Int) {
        val app = ctx.applicationContext
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = View(app)
        v.setBackgroundColor(color)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, lp)
        layer = v
    }

    // idx 0..5 sesuai NAMES
    fun clear(ctx: Context) = removeLayer(ctx)

    fun apply(ctx: Context, idx: Int): String {
        removeLayer(ctx)
        val reset = "settings put secure accessibility_display_daltonizer_enabled 0\n" +
            "settings put secure accessibility_display_inversion_enabled 0"
        val msg = when (idx) {
            1 -> { Access.run(reset + "\nsettings put secure accessibility_display_daltonizer_enabled 1\nsettings put secure accessibility_display_daltonizer 0"); "" }
            2 -> { Access.run(reset + "\nsettings put secure accessibility_display_inversion_enabled 1"); "" }
            3 -> { Access.run(reset); addTint(ctx, Color.argb(60, 255, 160, 60)) }
            4 -> { Access.run(reset); addTint(ctx, Color.argb(55, 60, 140, 255)) }
            5 -> { Access.run(reset); addTint(ctx, Color.argb(120, 0, 0, 0)) }
            6 -> { Access.run(reset); addTint(ctx, Color.argb(40, 255, 40, 180)) }   // vivid (pendekatan)
            7 -> { Access.run(reset); addTint(ctx, Color.argb(40, 40, 255, 200)) }   // full color (pendekatan)
            else -> { Access.run(reset); "" }
        }
        Store(ctx).put("filter_idx", idx.toString())
        AutoReset.flag(ctx)
        return if (msg.isBlank()) "Filter: ${NAMES[idx]}" else msg
    }
}

class FilterSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val out = TextView(ctx)

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(ctx.px(16), ctx.px(14), ctx.px(16), ctx.px(14))
        root.background = Hud.rounded(Color.argb(240, 8, 22, 42), Hud.neon, ctx.pxf(14f), 1.4f)
        val head = TextView(ctx).apply {
            text = "FILTER LAYAR"; textSize = 12f; setTextColor(Hud.neon)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(head)
        val cur = Store(ctx).get("filter_idx").toIntOrNull() ?: 0
        val grid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        FilterLayer.NAMES.chunked(3).forEachIndexed { row, names ->
            val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            names.forEachIndexed { col, n ->
                val idx = row * 3 + col
                val on = idx == cur
                val t = TextView(ctx).apply {
                    text = n; textSize = 11f; gravity = Gravity.CENTER
                    setTextColor(if (on) Color.parseColor("#04141F") else Color.WHITE)
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(ctx.px(8), ctx.px(8), ctx.px(8), ctx.px(8))
                    background = if (on) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(10f), 1f)
                    else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
                    setOnClickListener {
                        Sfx.tap()
                        if (!Access.requires(ctx, "Filter Layar", false)) return@setOnClickListener
                        Thread {
                            val m = FilterLayer.apply(ctx, idx)
                            out.post { out.text = m }
                        }.start()
                    }
                }
                r.addView(t, LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(ctx.px(3), ctx.px(3), ctx.px(3), ctx.px(3)) })
            }
            grid.addView(r)
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(8) })
        out.textSize = 11f; out.setTextColor(Hud.sub)
        root.addView(out, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(8) })
        val close = TextView(ctx).apply {
            text = "TUTUP"; textSize = 11f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(ctx.px(12), ctx.px(6), ctx.px(12), ctx.px(6))
            background = Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(10f), 1f)
            setOnClickListener { Sfx.tap(); onClose() }
        }
        root.addView(close, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = ctx.px(8); it.gravity = Gravity.END })
    }
}
