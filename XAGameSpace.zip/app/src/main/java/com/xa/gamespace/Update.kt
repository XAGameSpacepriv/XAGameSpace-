package com.xa.gamespace

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// Cek update lewat file version.json di repo GitHub (dibaca publik)
object Update {
    const val URL_JSON = "https://raw.githubusercontent.com/Xanz-crypto/xa-gamespace/main/version.json"
    const val LINK_CHANNEL = "https://whatsapp.com/channel/0029Vb9oX42LikgFESrDLY1J"

    private const val CH_ID   = "xa_update"
    private const val NOTIF_ID_SOFT  = 1001   // update biasa
    private const val NOTIF_ID_FORCE = 1002   // update wajib

    class Info(val latest: Int, val min: Int, val name: String, val link: String, val notes: String)

    fun currentCode(ctx: Context): Int =
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionCode } catch (e: Exception) { 0 }

    // latest: versi terbaru. min: versi terendah yang masih boleh dipakai.
    fun check(act: Activity, onResult: (Info?, Int) -> Unit) {
        val cur = currentCode(act)
        Thread {
            val info = try {
                val c = URL(URL_JSON).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val body = c.inputStream.bufferedReader().use { it.readText() }
                val j = JSONObject(body)
                Info(j.getInt("latest"), j.getInt("min"), j.optString("name"), j.optString("link"), j.optString("notes"))
            } catch (e: Exception) { null }   // offline: aplikasi tetap bisa dipakai
            Handler(Looper.getMainLooper()).post { onResult(info, cur) }
        }.start()
    }

    // ── push notifikasi ──────────────────────────────────────────────────────

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CH_ID) == null) {
                val ch = NotificationChannel(CH_ID, "Update XAGameSpace", NotificationManager.IMPORTANCE_HIGH)
                ch.description = "Pemberitahuan versi baru XAGameSpace"
                nm.createNotificationChannel(ch)
            }
        }
    }

    private fun linkIntent(ctx: Context, url: String): PendingIntent {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        return PendingIntent.getActivity(
            ctx, 0, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Notif update biasa — tap → buka link GitHub */
    fun pushSoftUpdate(ctx: Context, info: Info) {
        ensureChannel(ctx)
        val nb = NotificationCompat.Builder(ctx, CH_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("Update tersedia — v${info.name}")
            .setContentText("Versi baru XAGameSpace sudah rilis. Tap untuk unduh.")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("Versi baru XAGameSpace sudah rilis.\n${info.notes}\n\nTap untuk unduh."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(linkIntent(ctx, LINK_CHANNEL))
            .addAction(android.R.drawable.ic_menu_save, "Unduh", linkIntent(ctx, info.link))
        try { NotificationManagerCompat.from(ctx).notify(NOTIF_ID_SOFT, nb.build()) } catch (_: SecurityException) {}
    }

    /** Notif update WAJIB — tidak bisa digeser, tap → unduh, ada tombol WhatsApp */
    fun pushForceUpdate(ctx: Context, info: Info) {
        ensureChannel(ctx)
        val nb = NotificationCompat.Builder(ctx, CH_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("⚠️ UPDATE WAJIB — v${info.name}")
            .setContentText("Versi ini tidak bisa dipakai lagi. Wajib update sekarang.")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("Versi ini tidak bisa dipakai lagi.\n${info.notes}\n\nUnduh versi terbaru atau bergabung ke saluran WhatsApp kami."))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(linkIntent(ctx, LINK_CHANNEL))
            .addAction(android.R.drawable.ic_menu_save, "Unduh Sekarang", linkIntent(ctx, info.link))
            .addAction(android.R.drawable.ic_dialog_info, "Saluran WhatsApp", linkIntent(ctx, LINK_CHANNEL))
        try { NotificationManagerCompat.from(ctx).notify(NOTIF_ID_FORCE, nb.build()) } catch (_: SecurityException) {}
    }
}
