package com.xa.gamespace

import android.content.Context

class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("xa3", Context.MODE_PRIVATE)

    var stabil: Boolean
        get() = sp.getBoolean("stabil", true)
        set(v) { sp.edit().putBoolean("stabil", v).apply() }

    var smooth: Boolean
        get() = sp.getBoolean("smooth", true)
        set(v) { sp.edit().putBoolean("smooth", v).apply() }

    var auto: Boolean
        get() = sp.getBoolean("auto", true)
        set(v) { sp.edit().putBoolean("auto", v).apply() }

    var touch: Boolean
        get() = sp.getBoolean("touch", true)
        set(v) { sp.edit().putBoolean("touch", v).apply() }

    var touchSmooth: Boolean
        get() = sp.getBoolean("touch_smooth", true)
        set(v) { sp.edit().putBoolean("touch_smooth", v).apply() }

    var touchAnim: Float
        get() = sp.getFloat("touch_anim", 0.5f)
        set(v) { sp.edit().putFloat("touch_anim", v).apply() }

    // Sensitivitas sentuhan sumbu X dan Y: 1.0 = bawaan sistem, 0.1–3.0
    var touchSensX: Float
        get() = sp.getFloat("touch_sens_x", 1.0f)
        set(v) { sp.edit().putFloat("touch_sens_x", v).apply() }

    var touchSensY: Float
        get() = sp.getFloat("touch_sens_y", 1.0f)
        set(v) { sp.edit().putFloat("touch_sens_y", v).apply() }

    var crossOn: Boolean
        get() = sp.getBoolean("cross_on", false)
        set(v) { sp.edit().putBoolean("cross_on", v).apply() }

    var crossStyle: Int
        get() = sp.getInt("cross_style", 0)
        set(v) { sp.edit().putInt("cross_style", v).apply() }

    var monitorOn: Boolean
        get() = sp.getBoolean("monitor_on", false)
        set(v) { sp.edit().putBoolean("monitor_on", v).apply() }

    var handleSide: Int
        get() = sp.getInt("handle_side", 0)
        set(v) { sp.edit().putInt("handle_side", v).apply() }

    var handleY: Float
        get() = sp.getFloat("handle_y", 0.5f)
        set(v) { sp.edit().putFloat("handle_y", v).apply() }

    var active: Boolean
        get() = sp.getBoolean("active", false)
        set(v) { sp.edit().putBoolean("active", v).apply() }

    var game: String?
        get() = sp.getString("game", null)
        set(v) { sp.edit().putString("game", v).apply() }

    fun get(k: String): String = sp.getString(k, "") ?: ""
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }
}
