package com.xa.gamespace

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File

// Rekam layar + audio (mic atau suara sistem).
// Video: MediaCodec (input dari VirtualDisplay). Audio: AudioRecord -> AAC MediaCodec.
// Keduanya digabung oleh MediaMuxer. Tanpa root (memakai izin MediaProjection).
object ScreenRec {
    var projection: MediaProjection? = null
    var display: VirtualDisplay? = null
    var recording = false
    var lastFile = ""
    private var appCtx: Context? = null

    private var vEnc: MediaCodec? = null
    private var aEnc: MediaCodec? = null
    private var aRec: AudioRecord? = null
    private var muxer: MediaMuxer? = null
    private var vTrack = -1
    private var aTrack = -1
    private var hasAudio = false
    private var muxStarted = false
    private val lock = Any()
    private var vThread: Thread? = null
    private var aThread: Thread? = null
    @Volatile private var running = false

    fun outDir(ctx: Context): File =
        (ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: ctx.filesDir).also { it.mkdirs() }

    // lebar, tinggi (genap), dpi sesuai pengaturan resolusi
    fun dims(ctx: Context): Triple<Int, Int, Int> {
        val m = DisplayMetrics()
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(m)
        val short = when (Store(ctx).get("rec_res")) { "480" -> 480; "1080" -> 1080; else -> 720 }
        val scale = short.toFloat() / minOf(m.widthPixels, m.heightPixels)
        val w = (m.widthPixels * scale).toInt() and 1.inv()
        val h = (m.heightPixels * scale).toInt() and 1.inv()
        return Triple(w, h, m.densityDpi)
    }

    fun startRecord(ctx: Context): String {
        val p = projection ?: return "NEED_PERMISSION"
        if (recording) return "Sudah merekam."
        val st = Store(ctx)
        val fps = st.get("rec_fps").toIntOrNull() ?: 30
        val mbps = st.get("rec_bitrate").toIntOrNull() ?: 4
        val (w, h, dpi) = dims(ctx)
        appCtx = ctx.applicationContext
        val file = File(outDir(ctx), "rec_${System.currentTimeMillis()}.mp4")
        lastFile = file.absolutePath

        val audioMode = st.get("rec_audio")
        val granted = ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val wantAudio = (audioMode == "mic" || (audioMode == "sys" && Build.VERSION.SDK_INT >= 29)) && granted
        var note = when {
            audioMode == "sys" && Build.VERSION.SDK_INT < 29 -> " · suara sistem butuh Android 10+, tanpa audio"
            (audioMode == "mic" || audioMode == "sys") && !granted -> " · izin mic belum diberikan, tanpa audio"
            else -> ""
        }

        try {
            // ---- video ----
            val vf = MediaFormat.createVideoFormat("video/avc", w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, mbps * 1_000_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val venc = MediaCodec.createEncoderByType("video/avc")
            venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = venc.createInputSurface()
            venc.start()
            vEnc = venc
            muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            vTrack = -1; aTrack = -1; muxStarted = false
            running = true
            hasAudio = false

            // ---- audio (opsional) ----
            if (wantAudio) {
                hasAudio = try { startAudio(p, audioMode == "sys") } catch (e: Exception) {
                    note = " · audio gagal (${e.message}), tanpa audio"; false
                }
            }

            // video sebelum display: penangkapan layar mulai setelah encoder siap
            display = p.createVirtualDisplay("xa_rec", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null)

            vThread = Thread {
                val info = MediaCodec.BufferInfo()
                while (!drain(venc, info, false, 4_000)) { }
            }.apply { name = "xa-video"; start() }

            recording = true
            return "Merekam ${h}p · ${fps} FPS · ${mbps} Mbps" +
                (if (hasAudio) " · " + (if (audioMode == "sys") "suara sistem" else "mic") else note)
        } catch (e: Exception) {
            cleanup()
            return "Gagal mulai rekam: ${e.message}"
        }
    }

    private fun startAudio(p: MediaProjection, sys: Boolean): Boolean {
        val rate = 44_100
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(rate)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val bufSize = maxOf(minBuf, rate * 4 / 10)
        val rec = if (sys) {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(p)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(cfg)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(bufSize)
                .build()
        } else {
            AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_STEREO,
                AudioFormat.ENCODING_PCM_16BIT, bufSize)
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return false }

        val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 2).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, bufSize)
        }
        val aenc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        aenc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        aenc.start()
        aEnc = aenc
        aRec = rec
        rec.startRecording()
        aThread = Thread { audioLoop(rec, aenc, bufSize, rate) }.apply { name = "xa-audio"; start() }
        return true
    }

    private fun audioLoop(rec: AudioRecord, enc: MediaCodec, bufSize: Int, rate: Int) {
        val buf = ByteArray(bufSize)
        val info = MediaCodec.BufferInfo()
        val startUs = System.nanoTime() / 1000
        var sampleFrames = 0L
        while (running) {
            val n = rec.read(buf, 0, buf.size)
            if (n <= 0) continue
            val inIdx = enc.dequeueInputBuffer(10_000)
            if (inIdx >= 0) {
                val ib = enc.getInputBuffer(inIdx)
                if (ib != null) {
                    ib.clear(); ib.put(buf, 0, n)
                    val pts = startUs + sampleFrames * 1_000_000L / rate
                    enc.queueInputBuffer(inIdx, 0, n, pts, 0)
                    sampleFrames += n / 4
                }
            }
            drain(enc, info, true, 0)
        }
        // akhir: kirim end-of-stream ke encoder audio
        val inIdx = enc.dequeueInputBuffer(10_000)
        if (inIdx >= 0) enc.queueInputBuffer(inIdx, 0, 0,
            startUs + sampleFrames * 1_000_000L / rate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        while (!drain(enc, info, true, 10_000)) { }
    }

    // ambil output encoder dan tulis ke muxer. Mengembalikan true saat end-of-stream.
    private fun drain(enc: MediaCodec, info: MediaCodec.BufferInfo, audio: Boolean, wait: Long): Boolean {
        while (true) {
            val idx = enc.dequeueOutputBuffer(info, wait)
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) return false
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                synchronized(lock) {
                    val m = muxer ?: return false
                    val t = m.addTrack(enc.outputFormat)
                    if (audio) aTrack = t else vTrack = t
                    if (vTrack >= 0 && (!hasAudio || aTrack >= 0) && !muxStarted) {
                        m.start(); muxStarted = true
                    }
                }
                continue
            }
            if (idx < 0) continue
            val out = enc.getOutputBuffer(idx)
            val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
            if (out != null && info.size > 0 && !isConfig) {
                synchronized(lock) {
                    if (muxStarted) {
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        muxer?.writeSampleData(if (audio) aTrack else vTrack, out, info)
                    }
                }
            }
            enc.releaseOutputBuffer(idx, false)
            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true
        }
    }

    fun stopRecord(): String {
        if (!recording) return "Belum merekam."
        running = false
        try { display?.release() } catch (e: Exception) {}
        display = null
        try { vEnc?.signalEndOfInputStream() } catch (e: Exception) {}
        try { vThread?.join(4000) } catch (e: Exception) {}
        try { aThread?.join(4000) } catch (e: Exception) {}
        cleanup()
        recording = false
        val f = File(lastFile)
        appCtx?.let { publish(it, f) }
        return "Tersimpan ke Galeri (Movies/XAGameSpace)"
    }

    // tutup semua encoder, audio, dan muxer (aman dipanggil berulang)
    private fun cleanup() {
        try { aRec?.stop() } catch (e: Exception) {}
        try { aRec?.release() } catch (e: Exception) {}
        try { vEnc?.stop() } catch (e: Exception) {}
        try { vEnc?.release() } catch (e: Exception) {}
        try { aEnc?.stop() } catch (e: Exception) {}
        try { aEnc?.release() } catch (e: Exception) {}
        try { if (muxStarted) muxer?.stop() } catch (e: Exception) {}
        try { muxer?.release() } catch (e: Exception) {}
        aRec = null; aEnc = null; vEnc = null; muxer = null
        vThread = null; aThread = null
        muxStarted = false; vTrack = -1; aTrack = -1; hasAudio = false
    }

    // pindahkan rekaman ke MediaStore supaya muncul di Galeri, lalu hapus salinan sementara
    private fun publish(ctx: Context, src: File) {
        Thread {
            try {
                val cr = ctx.contentResolver
                val v = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, src.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= 29) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/XAGameSpace")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }
                val uri = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return@Thread
                cr.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
                if (Build.VERSION.SDK_INT >= 29) {
                    cr.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                }
                src.delete()
            } catch (e: Exception) {}
        }.start()
    }
}
