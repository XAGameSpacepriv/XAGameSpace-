package com.xa.gamespace

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// CONTROL PANEL, mengikuti tata letak video menit 0:17:
// sidebar kiri (7 item), banner "Active", kartu "Performance settings" dengan "Control source",
// dial mode dengan daftar tingkat di kanan, dan kartu CPU. Warna memakai palet XAGameSpace.
class SettingsCenter(private val a: MainActivity, private val pkg: String) {
    // key settings global untuk Composition (ubah di sini bila nama key di ROM berbeda)
    private val COMPOSITION_KEY = "composition_type"

    val root = LinearLayout(a)
    private val content = LinearLayout(a)
    private val rows = ArrayList<TextView>()
    private val store = Store(a)
    private var dialLevel = 0f
    private val labels = listOf("Adjust operation", "Game Mode", "Texture", "GPU", "Display", "Audio", "Network", "Restore defaults")

    init {
        root.orientation = LinearLayout.HORIZONTAL
        root.setPadding(a.px(8), a.px(8), a.px(8), a.px(8))

        val side = LinearLayout(a)
        side.orientation = LinearLayout.VERTICAL
        labels.forEachIndexed { i, label ->
            val t = TextView(a)
            t.text = label
            t.textSize = 12f
            t.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            t.setPadding(a.px(14), a.px(10), a.px(8), a.px(10))
            t.minimumHeight = a.px(42)
            t.setOnClickListener { select(i) }
            rows.add(t)
            side.addView(t, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = a.px(5) })
        }
        root.addView(side, LinearLayout.LayoutParams(0, -1, 0.33f).also { it.rightMargin = a.px(10) })

        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        content.orientation = LinearLayout.VERTICAL
        sv.addView(content)
        root.addView(sv, LinearLayout.LayoutParams(0, -1, 0.67f))

        select(1)
    }

    private fun select(i: Int) {
        rows.forEachIndexed { k, t -> styleRow(t, k == i) }
        content.removeAllViews()
        banner()
        when (i) {
            0 -> content.addView(TouchSheet(a) {}.root, LinearLayout.LayoutParams(-1, -2))
            1 -> buildMode()
            2 -> content.addView(TexturePanel(a, pkg).root, LinearLayout.LayoutParams(-1, -2))
            3 -> buildGpu()
            4 -> buildDisplay()
            5 -> content.addView(SoundHub(a).root, LinearLayout.LayoutParams(-1, -2))
            6 -> content.addView(NetSheet(a, {}) {}.root, LinearLayout.LayoutParams(-1, -2))
            else -> content.addView(ResetSheet(a) {}.root, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun styleRow(t: TextView, on: Boolean) {
        t.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        t.setTextColor(if (on) Color.parseColor("#04141F") else Color.WHITE)
        t.background = if (on) {
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#5CE8FF"), Color.parseColor("#B05CFF"))).apply {
                cornerRadius = a.px(10).toFloat()
            }
        } else {
            GradientDrawable().apply {
                cornerRadius = a.px(10).toFloat()
                setColor(Color.argb(150, 16, 28, 52))
                setStroke(a.px(1), Color.argb(80, 60, 200, 255))
            }
        }
    }

    // banner "Active: <mode> · Default" di atas, seperti video
    private fun banner() {
        val cur = Modes.current(store)
        val t = TextView(a)
        t.text = "Active: ${cur.name} · ${store.get("control_source").ifBlank { "Default" }.replaceFirstChar { it.uppercase() }}"
        t.textSize = 12f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(Color.parseColor("#3CC8FF"))
        t.setPadding(a.px(12), a.px(10), a.px(12), a.px(10))
        t.background = GradientDrawable().apply {
            cornerRadius = a.px(12).toFloat()
            setColor(Color.argb(120, 20, 30, 64))
            setStroke(a.px(1), Color.parseColor("#3CC8FF"))
        }
        content.addView(t, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = a.px(10) })
    }

    // kartu seperti "Performance settings"
    private fun card(name: String): LinearLayout {
        val c = LinearLayout(a)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(a.px(12), a.px(10), a.px(12), a.px(12))
        c.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(225, 22, 16, 64), Color.argb(230, 10, 22, 40))).apply {
            cornerRadius = a.px(14).toFloat()
            setStroke(a.px(1), Color.argb(120, 60, 200, 255))
        }
        val t = TextView(a)
        t.text = name
        t.textSize = 13f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(Color.WHITE)
        c.addView(t, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = a.px(8) })
        content.addView(c, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = a.px(10) })
        return c
    }

    // tombol segmen: satu pilihan aktif (gradasi cyan-ungu)
    private fun seg(parent: LinearLayout, opts: List<Pair<String, String>>, cur: String, pick: (String) -> Unit) {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        for ((label, value) in opts) {
            val on = value == cur
            val t = TextView(a)
            t.text = label
            t.textSize = 11f
            t.gravity = Gravity.CENTER
            t.setTypeface(null, Typeface.BOLD)
            t.setTextColor(if (on) Color.parseColor("#04141F") else Color.WHITE)
            t.setPadding(a.px(4), a.px(8), a.px(4), a.px(8))
            t.background = if (on) {
                GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(Color.parseColor("#5CE8FF"), Color.parseColor("#B05CFF"))).apply {
                    cornerRadius = a.px(10).toFloat()
                }
            } else {
                GradientDrawable().apply {
                    cornerRadius = a.px(10).toFloat()
                    setColor(Color.argb(170, 30, 42, 70))
                    setStroke(a.px(1), Color.argb(110, 60, 200, 255))
                }
            }
            t.setOnClickListener { Sfx.tap(); pick(value) }
            row.addView(t, LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(a.px(3), 0, a.px(3), 0) })
        }
        parent.addView(row, LinearLayout.LayoutParams(-1, -2))
    }

    private fun note(parent: LinearLayout, text: String) {
        val t = TextView(a)
        t.text = text
        t.textSize = 11f
        t.setTextColor(Hud.sub)
        parent.addView(t, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = a.px(6) })
    }

    // jalankan perintah sistem di background, lalu refresh layar
    private fun run(cmd: String, after: () -> Unit) {
        if (!Access.requires(a, "Pengaturan sistem", false)) return
        Thread {
            Access.run(cmd)
            a.runOnUiThread { after() }
        }.start()
    }

    private fun levelOf(k: String): Float = when (k) {
        "normal" -> 0.25f
        "better" -> 0.45f
        "performa" -> 0.70f
        "esport" -> 0.90f
        else -> 0.55f
    }

    // ---------- Game Mode ----------
    private fun buildMode() {
        val cur = Modes.current(store)
        val c = card("Performance settings")
        seg(c, listOf("Default" to "default", "Auto" to "auto", "Custom" to "custom"),
            store.get("control_source").ifBlank { "default" }) { v ->
            store.put("control_source", v)
            select(1)
        }

        val title = TextView(a)
        title.text = "Current mode"
        title.textSize = 11f
        title.setTextColor(Hud.sub)
        c.addView(title, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = a.px(10) })
        val name = TextView(a)
        name.text = cur.name
        name.textSize = 22f
        name.setTypeface(null, Typeface.BOLD)
        name.setTextColor(Hud.cyan)
        c.addView(name, LinearLayout.LayoutParams(-1, -2))

        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val dial = PowerDial(a)
        dial.label = cur.name
        dial.startPulse()
        dial.setLevel(levelOf(cur.key), dialLevel)
        dialLevel = levelOf(cur.key)
        row.addView(dial, LinearLayout.LayoutParams(0, a.px(190), 1f))

        // daftar tingkat di kanan dial (Stabil di atas, seperti Rise di video)
        val stops = LinearLayout(a)
        stops.orientation = LinearLayout.VERTICAL
        listOf("Stabil" to "stabil", "Esport" to "esport", "Performa" to "performa", "Better" to "better", "Normal" to "normal")
            .forEach { (label, key) ->
                val on = key == cur.key
                val t = TextView(a)
                t.text = label
                t.textSize = 11f
                t.gravity = Gravity.CENTER
                t.setTypeface(null, Typeface.BOLD)
                t.setTextColor(if (on) Color.parseColor("#04141F") else Color.WHITE)
                t.setPadding(a.px(6), a.px(7), a.px(6), a.px(7))
                t.background = if (on) {
                    GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                        intArrayOf(Color.parseColor("#5CE8FF"), Color.parseColor("#B05CFF"))).apply {
                        cornerRadius = a.px(10).toFloat()
                    }
                } else {
                    GradientDrawable().apply {
                        cornerRadius = a.px(10).toFloat()
                        setColor(Color.argb(160, 30, 42, 70))
                        setStroke(a.px(1), Color.argb(90, 60, 200, 255))
                    }
                }
                t.setOnClickListener {
                    Sfx.tap()
                    Modes.apply(a, Modes.ALL.first { it.key == key })
                    select(1)
                }
                stops.addView(t, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = a.px(6) })
            }
        row.addView(stops, LinearLayout.LayoutParams(0, -2, 0.42f).also { it.leftMargin = a.px(8) })
        c.addView(row, LinearLayout.LayoutParams(-1, -2))
        note(c, cur.desc)

        buildCpu()
    }

    // ---------- CPU (per cluster) ----------
    private fun buildCpu() {
        Thread {
            val pols = try { Cpu.read() } catch (e: Exception) { emptyList() }
            a.runOnUiThread {
                if (pols.isEmpty()) {
                    val t = TextView(a)
                    t.text = "CPU tidak terbaca. Pastikan ROOT atau Shizuku aktif."
                    t.setTextColor(Hud.sub)
                    content.addView(t)
                    return@runOnUiThread
                }
                for (p in pols) {
                    val c = card("CPU ${p.name}")
                    seg(c, p.govs.map { it to it }, p.gov) { g ->
                        Thread {
                            Cpu.apply(listOf("echo $g > ${p.path}/scaling_governor"))
                            a.runOnUiThread { select(1) }
                        }.start()
                    }
                    val step = maxOf(1, p.freqs.size / 5)
                    val picks = p.freqs.filterIndexed { i, _ -> i % step == 0 }
                    seg(c, picks.map { "${it / 1000} MHz" to it.toString() }, p.max.toString()) { f ->
                        Thread {
                            Cpu.apply(listOf("echo $f > ${p.path}/scaling_max_freq"))
                            a.runOnUiThread { select(1) }
                        }.start()
                    }
                    note(c, "Governor: ${p.gov} · Max: ${p.max / 1000} MHz · Sekarang: ${p.cur / 1000} MHz")
                }
            }
        }.start()
    }

    // ---------- GPU / Renderer ----------
    private fun buildGpu() {
        val curDrv = store.get("driver_mode").ifBlank { DriverMode.DEFAULT.name }
        val mode = try { DriverMode.valueOf(curDrv) } catch (e: Exception) { DriverMode.DEFAULT }
        val r = card("Renderer")
        seg(r, DriverMode.values().map { it.label to it.name }, mode.name) { n ->
            val m = DriverMode.valueOf(n)
            store.put("driver_mode", n)
            run("settings put global angle_gl_driver_all_angle ${if (m == DriverMode.ANGLE) 1 else 0}") { select(3) }
        }
        note(r, mode.desc)

        val th = store.get("thread_mode").ifBlank { "standard" }
        val tc = card("Thread")
        seg(tc, listOf("Normal" to "standard", "Tinggi" to "performance", "Hemat" to "battery"), th) { v ->
            store.put("thread_mode", v)
            run("cmd game mode $v $pkg 2>/dev/null || true") { select(3) }
        }
        note(tc, "Prioritas thread game (Game Mode per aplikasi, Android 12 ke atas).")

        val comp = store.get("composition").ifBlank { "gpu" }
        val cc = card("Composition")
        seg(cc, listOf("GPU" to "gpu", "CPU" to "cpu", "Dyn" to "dyn"), comp) { v ->
            store.put("composition", v)
            run("settings put global $COMPOSITION_KEY $v") { select(3) }
        }
        note(cc, "Diterapkan lewat settings put global $COMPOSITION_KEY")

        val vs = store.get("vsync_gpu").ifBlank { "0" }
        val v = card("VSync GPU")
        seg(v, listOf("Aktif" to "1", "Mati" to "0"), vs) { x ->
            store.put("vsync_gpu", x)
            run(RateCmd.gpuVsyncCmd(x == "1")) { select(3) }
        }
    }

    // ---------- Display ----------
    private fun buildDisplay() {
        val hz = store.get("render_hz").ifBlank { "default" }
        val r = card("Render Hz")
        seg(r, listOf("Default" to "default", "60" to "60", "90" to "90", "120" to "120"), hz) { h ->
            store.put("render_hz", h)
            run(if (h == "default") RateCmd.renderDefaultCmd() else RateCmd.renderCmd(h)) { select(4) }
        }

        val fps = store.get("vsync_fps").ifBlank { "0" }
        val v = card("VSync FPS")
        seg(v, listOf("Mati" to "0", "30" to "30", "60" to "60"), fps) { f ->
            store.put("vsync_fps", f)
            run(RateCmd.vsyncFpsCmd(f)) { select(4) }
        }
    }
}

// Dial daya bergaya Control Panel: busur bercahaya yang bergerak ke level mode, dengan denyut halus.
class PowerDial(c: Context) : View(c) {
    var label: String = ""
    private var level = 0f
    private var pulse = 0f
    private var anim: ValueAnimator? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val arcP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val centerP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val knobP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(255, 159, 184, 208); textAlign = Paint.Align.CENTER }
    private val oval = RectF()

    fun setLevel(to: Float, from: Float) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(from, to).apply {
            duration = 700
            interpolator = DecelerateInterpolator()
            addUpdateListener { level = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun startPulse() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1600
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val d = context.resources.displayMetrics.density
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f - 14f * d
        oval.set(cx - r, cy - r, cx + r, cy + r)

        track.strokeWidth = 10f * d
        track.color = Color.argb(70, 60, 200, 255)
        cv.drawArc(oval, 135f, 270f, false, track)

        arcP.strokeWidth = 10f * d
        arcP.color = Color.parseColor("#3CC8FF")
        arcP.setShadowLayer(14f * d, 0f, 0f, Color.argb(220, 180, 92, 255))
        cv.drawArc(oval, 135f, 270f * level, false, arcP)

        val ang = Math.toRadians(135.0 + 270.0 * level)
        knobP.color = Color.WHITE
        knobP.setShadowLayer(10f * d, 0f, 0f, Color.argb(230, 92, 232, 255))
        cv.drawCircle(cx + (r * cos(ang)).toFloat(), cy + (r * sin(ang)).toFloat(), 7f * d, knobP)

        val inner = r - 18f * d
        centerP.color = Color.argb(235, 16, 12, 48)
        cv.drawCircle(cx, cy, inner, centerP)
        ringP.strokeWidth = 2f * d
        ringP.color = Color.argb((80 + 90 * pulse).toInt(), 180, 92, 255)
        cv.drawCircle(cx, cy, inner, ringP)

        txt.textSize = 17f * d
        cv.drawText(label, cx, cy + 2f * d, txt)
        sub.textSize = 10f * d
        cv.drawText("Game mode", cx, cy + 20f * d, sub)
    }
}
