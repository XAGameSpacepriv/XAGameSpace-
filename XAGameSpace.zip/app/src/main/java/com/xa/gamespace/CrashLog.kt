package com.xa.gamespace

import android.app.AlertDialog
import android.app.Activity
import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

// Mencatat crash ke file di data app. Saat dibuka lagi, isi crash ditampilkan
// supaya bisa disalin dan dikirim untuk diperbaiki.
object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "crash.txt")

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                file(app).writeText("thread=${t.name}\n$sw")
            } catch (_: Exception) {}
            prev?.uncaughtException(t, e)
        }
    }

    fun showPending(act: Activity) {
        val f = file(act)
        if (!f.exists()) return
        val text = try { f.readText() } catch (e: Exception) { "" }
        f.delete()
        if (text.isBlank()) return
        AlertDialog.Builder(act)
            .setTitle("Crash sebelumnya")
            .setMessage(text.take(3000))
            .setPositiveButton("OK", null)
            .show()
    }
}
