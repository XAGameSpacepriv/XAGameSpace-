package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

// =====================================================================
//  Touch Optimizer + Touch Smooth
//  - Touch Optimizer : respons sentuhan lebih cepat (touch panel mode game, input boost CPU, long-press cepat)
//  - Touch Smooth    : animasi sistem dipercepat supaya geser/scroll terasa licin, tidak patah-patah
//  Semua nilai asli disimpan dulu (snapshot) dan dikembalikan saat boost dimatikan / tombol Reset.
//  Jalur kernel hanya ditulis bila ada di HP dan bisa ditulis (khusus root); yang tidak ada dilewati.
// =====================================================================
object TouchOpt {
    private const val KEY = "snap_touch"

    // jalur touch panel (mode game / sampling) -> nilai aktif
    private val PANEL = listOf(
        "/proc/touchpanel/game_switch_enable" to "1",
        "/sys/devices/virtual/touch/touch_dev/bump_sample_rate" to "1",
        "/sys/class/touch/touch_dev/bump_sample_rate" to "1"
    )

    // input boost: CPU dinaikkan sesaat setiap ada sentuhan (milidetik)
    private val BOOST = listOf(
        "/sys/module/cpu_boost/parameters/input_boost_ms" to "120",
        "/sys/devices/system/cpu/cpu_boost/input_boost_ms" to "120",
        "/sys/module/cpu_input_boost/parameters/input_boost_duration" to "120",
        "/sys/module/msm_performance/parameters/touchboost" to "1"
    )

    private val FILES = PANEL + BOOST
    private val FILE_SET = FILES.map { it.first }.toSet()

    private val GLOBAL_KEYS = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
    private val SECURE_KEYS = listOf("long_press_timeout", "multi_press_timeout")
    private val SET_KEYS = GLOBAL_KEYS.map { "global|$it" } + SECURE_KEYS.map { "secure|$it" }

    private val NUM = Regex("^[0-9.]+$")
    private val INT = Regex("^[0-9]+$")

    private fun snapScript(): String {
        val sb = StringBuilder()
        for (k in GLOBAL_KEYS) sb.append("echo \"S|global|$k|§(settings get global $k)\"\n")
        for (k in SECURE_KEYS) sb.append("echo \"S|secure|$k|§(settings get secure $k)\"\n")
        for ((p, _) in FILES) sb.append("[ -w $p ] && echo \"F|$p|§(head -n 1 $p 2>/dev/null)\"\n")
        return sb.toString().replace('§', '$')
    }

    // Terapkan. Mengembalikan laporan singkat apa yang aktif.
    fun apply(ctx: Context, boost: Boolean, smooth: Boolean, anim: Float): String {
        val s = Store(ctx)
        if (s.get(KEY).isBlank()) {
            val snap = Access.run(snapScript())
            if (snap.lines().any { it.startsWith("S|") || it.startsWith("F|") }) s.put(KEY, snap)
        }
        val c = ArrayList<String>()
        if (boost) {
            c.add("settings put secure long_press_timeout 250")
            c.add("settings put secure multi_press_timeout 250")
            for ((p, v) in FILES) c.add("[ -w $p ] && echo $v > $p")
        }
        if (smooth) {
            val a = anim.coerceIn(0.2f, 1f).toString()
            for (k in GLOBAL_KEYS) c.add("settings put global $k $a")
        }
        if (c.isNotEmpty()) Access.run(c.joinToString("\n"))

        val found = s.get(KEY).lines().filter { it.startsWith("F|") }.map { it.split("|").getOrElse(1) { "" } }
        val panel = found.filter { p -> PANEL.any { it.first == p } }.map { it.substringAfterLast('/') }
        val boosts = found.filter { p -> BOOST.any { it.first == p } }.map { it.substringAfterLast('/') }
        val out = StringBuilder()
        if (boost) {
            out.append("Touch Optimizer aktif.\n")
            out.append("• Respons tekan-tahan dipercepat\n")
            out.append("• Touch panel: ").append(if (panel.isEmpty()) "tidak ada jalur di HP ini / butuh root" else panel.joinToString()).append("\n")
            out.append("• Input boost CPU: ").append(if (boosts.isEmpty()) "tidak ada jalur di HP ini / butuh root" else boosts.joinToString()).append("\n")
        }
        if (smooth) out.append("Touch Smooth aktif: animasi sistem ${anim}x (lebih cepat = lebih licin).\n")
        if (!boost && !smooth) out.append("Tidak ada fitur touch yang dinyalakan.")
        return out.toString().trim()
    }

    // Baca ulang dari sistem: apakah nilai yang diminta benar-benar masuk.
    fun verify(boost: Boolean, smooth: Boolean, anim: Float): String {
        val sb = StringBuilder()
        if (smooth) {
            val want = anim.coerceIn(0.2f, 1f)
            val got = Access.run("settings get global window_animation_scale").lines()
                .map { it.trim() }.lastOrNull { it.isNotEmpty() && it != "null" } ?: ""
            val ok = got.toFloatOrNull()?.let { kotlin.math.abs(it - want) < 0.01f } == true
            sb.append(if (ok) "✓ Animasi ${want}x berhasil diterapkan\n"
                      else "✕ Animasi tidak berubah (sistem membaca: ${got.ifEmpty { "kosong" }})\n")
        }
        if (boost) {
            val pOk = Access.run("for p in ${PANEL.joinToString(" ") { it.first }}; do [ -w \$p ] && echo OK; done").contains("OK")
            sb.append(if (pOk) "✓ Jalur touch panel terbaca\n" else "✕ Jalur touch panel tidak bisa ditulis di HP ini\n")
        }
        return sb.toString().trim()
    }

    // Kembalikan semua nilai asli.
    fun restore(ctx: Context): String {
        val s = Store(ctx)
        val snap = s.get(KEY)
        if (snap.isBlank()) return "Tidak ada yang perlu dikembalikan."
        val c = ArrayList<String>()
        for (l in snap.lines()) {
            val p = l.trim().split("|")
            if (p.size >= 4 && p[0] == "S" && "${p[1]}|${p[2]}" in SET_KEYS) {
                val v = p[3]
                if (v.isBlank() || v == "null") c.add("settings delete ${p[1]} ${p[2]}")
                else if (NUM.matches(v)) c.add("settings put ${p[1]} ${p[2]} $v")
            } else if (p.size >= 3 && p[0] == "F" && p[1] in FILE_SET && INT.matches(p[2])) {
                c.add("[ -w ${p[1]} ] && echo ${p[2]} > ${p[1]}")
            }
        }
        if (c.isNotEmpty()) Access.run(c.joinToString("\n"))
        s.put(KEY, "")
        return "Touch dikembalikan ke bawaan HP."
    }

    // Info jalur touch yang ada di HP ini (untuk ditampilkan).
    fun detect(): String {
        val sb = StringBuilder()
        for ((p, _) in FILES) sb.append("[ -e $p ] && { [ -w $p ] && echo \"W|$p\" || echo \"R|$p\"; }\n")
        sb.append("echo \"D1|§(ls /proc/touchpanel 2>/dev/null | head -n 24 | tr '\\n' ' ')\"\n")
        sb.append("echo \"D2|§(ls /sys/devices/virtual/touch/touch_dev 2>/dev/null | head -n 24 | tr '\\n' ' ')\"\n")
        val o = Access.run(sb.toString().replace('§', '$'))
        val w = o.lines().count { it.startsWith("W|") }
        val r = o.lines().count { it.startsWith("R|") }
        val d1 = o.lines().firstOrNull { it.startsWith("D1|") }?.removePrefix("D1|")?.trim().orEmpty()
        val d2 = o.lines().firstOrNull { it.startsWith("D2|") }?.removePrefix("D2|")?.trim().orEmpty()
        val res = StringBuilder()
        res.append("Jalur kernel yang cocok: $w bisa ditulis")
        if (r > 0) res.append(", $r hanya baca")
        res.append(".")
        if (d1.isNotEmpty()) res.append("\n/proc/touchpanel: ").append(d1.take(160))
        if (d2.isNotEmpty()) res.append("\ntouch_dev: ").append(d2.take(160))
        return res.toString()
    }
}

// Sheet Touch Optimizer (dipakai di Game Panel dan menu utama)
// =====================================================================
//  TouchAccel – akselerasi sentuhan (input_mt fuzz / touch linearization)
//  TouchSmoothing – smoothing jalur sentuhan (touch report latency / filter)
// =====================================================================
object TouchAccel {
    // Akselerasi: semakin tinggi, semakin agresif akselerasi kecepatan geser
    // Android tidak punya API tunggal; kita coba jalur sysfs OEM + motion prediction
    private val ACCEL_PATHS = listOf(
        "/sys/devices/virtual/touch/touch_dev/touch_accel",
        "/sys/class/touch/touch_dev/accel",
        "/proc/touchpanel/touch_accel",
        "/sys/module/ft5x06_ts/parameters/accel"
    )
    // motion_prediction: Android 13+ mengaktifkan prediksi gerak layar
    // latency_ms: delay report touch (lebih rendah = lebih responsif, kurang smooth)
    private val LATENCY_PATHS = listOf(
        "/sys/devices/virtual/touch/touch_dev/report_rate",
        "/sys/class/touch/touch_dev/report_rate",
        "/proc/touchpanel/report_rate"
    )

    // level 0–4: 0=mati, 1=rendah, 2=sedang, 3=tinggi, 4=max
    val LEVELS = listOf("Mati", "Rendah", "Sedang", "Tinggi", "Max")

    fun apply(ctx: Context, level: Int): String {
        if (level == 0) return reset(ctx)
        val sb = StringBuilder()
        val sysVal = level.toString()
        // coba jalur sysfs
        var done = false
        for (p in ACCEL_PATHS) {
            val r = Access.run("[ -w $p ] && echo $sysVal > $p && echo OK")
            if (r.contains("OK")) { sb.append("✓ accel → $p\n"); done = true; break }
        }
        // motion prediction via settings (Android 13+)
        val motVal = if (level >= 2) "1" else "0"
        Access.run("settings put secure motion_prediction_enabled $motVal 2>/dev/null || true")
        sb.append("• motion_prediction → $motVal\n")
        // report rate boost
        val rateVal = when (level) { 1 -> "120"; 2 -> "180"; 3 -> "240"; else -> "360" }
        for (p in LATENCY_PATHS) {
            val r = Access.run("[ -w $p ] && echo $rateVal > $p && echo OK")
            if (r.contains("OK")) { sb.append("✓ report_rate → ${rateVal}Hz\n"); break }
        }
        if (sb.isBlank()) sb.append("Jalur sysfs tidak ada; motion_prediction saja yang diterapkan.")
        Store(ctx).put("touch_accel_lv", level.toString())
        return sb.toString().trim()
    }

    fun reset(ctx: Context): String {
        for (p in ACCEL_PATHS) Access.run("[ -w $p ] && echo 0 > $p")
        Access.run("settings delete secure motion_prediction_enabled 2>/dev/null || true")
        Store(ctx).put("touch_accel_lv", "0")
        return "Akselerasi direset."
    }

    fun current(ctx: Context): Int = Store(ctx).get("touch_accel_lv").toIntOrNull() ?: 0
}

object TouchSmoothing {
    // Smoothing: rata-rata jalur sentuhan supaya tidak patah-patah
    // Jalur sysfs OEM + Android input filter
    private val SMOOTH_PATHS = listOf(
        "/sys/devices/virtual/touch/touch_dev/touch_smooth",
        "/sys/class/touch/touch_dev/smooth",
        "/proc/touchpanel/touch_smooth"
    )

    // level 0–4: 0=mati(raw), 4=paling halus
    val LEVELS = listOf("Mati (Raw)", "Ringan", "Sedang", "Halus", "Super Halus")

    fun apply(ctx: Context, level: Int): String {
        if (level == 0) return reset(ctx)
        val sb = StringBuilder()
        val sysVal = level.toString()
        for (p in SMOOTH_PATHS) {
            val r = Access.run("[ -w $p ] && echo $sysVal > $p && echo OK")
            if (r.contains("OK")) { sb.append("✓ smooth → $p\n"); break }
        }
        // Android input filter via input_sensitivity (Xiaomi/MIUI)
        val filtVal = when (level) { 1 -> "0"; 2 -> "1"; 3 -> "2"; else -> "3" }
        Access.run("settings put system input_pointer_sensitivity $filtVal 2>/dev/null || true")
        sb.append("• input_pointer_sensitivity → $filtVal\n")
        // Animator duration supaya gerakan UI terasa lebih mulus saat dipakai
        val animScale = when (level) { 1 -> "0.8"; 2 -> "0.6"; 3 -> "0.4"; else -> "0.2" }
        Access.run("settings put global window_animation_scale $animScale 2>/dev/null || true")
        Access.run("settings put global transition_animation_scale $animScale 2>/dev/null || true")
        if (sb.isBlank()) sb.append("Jalur sysfs tidak ada; filter sistem saja yang diterapkan.")
        Store(ctx).put("touch_smooth_lv", level.toString())
        return sb.toString().trim()
    }

    fun reset(ctx: Context): String {
        for (p in SMOOTH_PATHS) Access.run("[ -w $p ] && echo 0 > $p")
        Access.run("settings delete system input_pointer_sensitivity 2>/dev/null || true")
        Store(ctx).put("touch_smooth_lv", "0")
        return "Smoothing direset."
    }

    fun current(ctx: Context): Int = Store(ctx).get("touch_smooth_lv").toIntOrNull() ?: 0
}

// =====================================================================
//  TouchSens – sensitivitas sumbu X dan Y sentuhan layar
//
//  Strategi (dicoba berurutan, berhenti di yang berhasil):
//  1. /proc/touchpanel/report_rate_mode  — Xiaomi/Poco rate multiplier
//  2. settings put system pointer_speed  — Android system pointer speed (-7 s/d 7)
//     (nilai dikonversi dari skala 0.1–3.0 kita ke skala –7..7)
//  3. getevent / sendevent tidak bisa dipakai langsung tanpa driver custom,
//     jadi fallback: tulis ke sysfs x_scale / y_scale jika ada.
//
//  Catatan: Android tidak punya API publik untuk memisahkan sensitivitas X dan Y
//  pada layar sentuh kapasitif standar. Jalur sysfs di bawah bersifat OEM-spesifik
//  (Xiaomi, OPPO/Realme, Samsung). Jika tidak ada jalur yang cocok di perangkat,
//  fitur tetap berjalan tapi menyimpan nilai saja (berpengaruh saat jalur tersedia).
// =====================================================================
object TouchSens {

    // Jalur sysfs per-sumbu (OEM-specific, skip jika tidak ada)
    private val X_PATHS = listOf(
        "/sys/devices/virtual/touch/touch_dev/x_scale",
        "/sys/class/touch/touch_dev/x_scale",
        "/proc/touchpanel/x_sensitivity",
        "/sys/module/ft5x06_ts/parameters/x_scale"
    )
    private val Y_PATHS = listOf(
        "/sys/devices/virtual/touch/touch_dev/y_scale",
        "/sys/class/touch/touch_dev/y_scale",
        "/proc/touchpanel/y_sensitivity",
        "/sys/module/ft5x06_ts/parameters/y_scale"
    )

    // pointer_speed range: -7 (paling lambat) .. 7 (paling cepat), default 0 = 1.0×
    // Skala kita 0.1–5.0: 1.0 = 0, 0.1 = -7, 5.0 = 7
    private fun toPointerSpeed(v: Float): Int =
        if (v <= 1.0f) ((v - 1.0f) / 0.9f * 7f).coerceIn(-7f, 0f).toInt()
        else           ((v - 1.0f) / 4.0f * 7f).coerceIn(0f, 7f).toInt()

    // scale sysfs biasanya integer 1–10 atau float 0.0–2.0
    // kita kirim float 1 desimal
    private fun toSysfs(v: Float): String = "%.1f".format(v)

    fun apply(ctx: Context, sensX: Float, sensY: Float): String {
        val sb = StringBuilder()

        // --- coba jalur sysfs X ---
        var xDone = false
        for (p in X_PATHS) {
            val r = Access.run("[ -w $p ] && echo ${toSysfs(sensX)} > $p && echo OK")
            if (r.contains("OK")) { sb.append("✓ X → $p\n"); xDone = true; break }
        }

        // --- coba jalur sysfs Y ---
        var yDone = false
        for (p in Y_PATHS) {
            val r = Access.run("[ -w $p ] && echo ${toSysfs(sensY)} > $p && echo OK")
            if (r.contains("OK")) { sb.append("✓ Y → $p\n"); yDone = true; break }
        }

        // --- fallback: pointer_speed (tidak memisahkan X/Y tapi lebih universal) ---
        if (!xDone && !yDone) {
            // rata-rata X dan Y untuk pointer_speed
            val avg = (sensX + sensY) / 2f
            val spd = toPointerSpeed(avg)
            val r = Access.run("settings put system pointer_speed $spd")
            sb.append(if (r.isBlank()) "✓ pointer_speed → $spd (rata-rata X+Y)\n"
                      else "✕ pointer_speed gagal: $r\n")
        }

        if (sb.isBlank()) sb.append("Jalur sysfs tidak ditemukan di perangkat ini.\nNilai disimpan, aktif jika jalur tersedia setelah update ROM.")
        return sb.toString().trim()
    }

    fun reset(ctx: Context) {
        for (p in X_PATHS) Access.run("[ -w $p ] && echo 1.0 > $p")
        for (p in Y_PATHS) Access.run("[ -w $p ] && echo 1.0 > $p")
        Access.run("settings put system pointer_speed 0")
    }

    fun detect(): String {
        val sb = StringBuilder()
        val allPaths = X_PATHS + Y_PATHS
        val found = allPaths.filter { Access.run("[ -e $it ] && echo Y").contains("Y") }
        if (found.isEmpty()) sb.append("Tidak ada jalur sysfs X/Y di perangkat ini.\nFallback ke pointer_speed sistem.\n")
        else found.forEach { sb.append("• $it\n") }
        // cek pointer_speed
        val spd = Access.run("settings get system pointer_speed").trim()
        sb.append("pointer_speed saat ini: ${spd.ifEmpty { "0 (default)" }}")
        return sb.toString().trim()
    }
}

class TouchSheet(private val ctx: Context, private val onClose: () -> Unit) {
    val root = LinearLayout(ctx)
    private val box = LinearLayout(ctx)
    private val result = TextView(ctx)
    private val info = TextView(ctx)
    private val animRow = LinearLayout(ctx)
    private val store = Store(ctx)
    private var sensStartIdx = -1
    private val SENS_VIEW_COUNT = 5

    private fun px(v: Int) = ctx.px(v)

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun btn(t: String, primary: Boolean = false, on: Boolean = false, click: () -> Unit): TextView {
        val hi = primary || on
        val v = tv(t, 11f, if (hi) Color.parseColor("#04141F") else Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.setPadding(px(12), px(7), px(12), px(7))
        v.background = if (hi) Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(16f), 1f)
        else Hud.rounded(Color.argb(90, 255, 255, 255), Color.argb(60, 255, 255, 255), ctx.pxf(16f), 1f)
        v.setOnClickListener { Sfx.tap(); click() }
        return v
    }

    private fun section(title: String, desc: String, tag: String, pill: Pill?) {
        val h = LinearLayout(ctx)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.addView(tv(title, 12f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        h.addView(tv(tag, 9f, Color.parseColor("#FFC24B"), true).also { it.setPadding(0, 0, px(8), 0) })
        if (pill != null) h.addView(pill)
        box.addView(h, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(10) })
        box.addView(tv(desc, 10f, Hud.sub), LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(5) })
    }

    private fun renderAnim() {
        animRow.removeAllViews()
        val opts = listOf("Normal" to 1.0f, "Halus" to 0.7f, "Licin" to 0.5f, "Super" to 0.3f)
        for ((name, v) in opts) {
            animRow.addView(btn(name, on = store.touchAnim == v) {
                store.touchAnim = v
                renderAnim()
                applyLive()
            }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(6) })
        }
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.background = Hud.rounded(Color.argb(240, 8, 22, 40), Hud.cyanDim, ctx.pxf(10f), 1f)
        root.setPadding(px(12), px(10), px(12), px(10))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("TOUCH OPTIMIZER", 12f, Hud.cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        val x = tv("✕", 16f)
        x.setPadding(px(10), px(2), px(4), px(2))
        x.setOnClickListener { Sfx.tap(); onClose() }
        head.addView(x)
        root.addView(head)

        val sv = androidx.core.widget.NestedScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        box.orientation = LinearLayout.VERTICAL
        sv.addView(box)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val pOpt = Pill(ctx)
        pOpt.setOn(store.touch)
        pOpt.onToggle = { v -> store.touch = v; applyLive() }
        section("Touch Optimizer",
            "Sentuhan lebih responsif: mode game touch panel, input boost CPU saat layar disentuh, dan tekan-tahan lebih cepat. " +
                "Otomatis aktif saat game dibuka dan dikembalikan saat selesai.", "ROOT/SHIZUKU", pOpt)

        val pSm = Pill(ctx)
        pSm.setOn(store.touchSmooth)
        pSm.onToggle = { v -> store.touchSmooth = v; applyLive() }
        section("Touch Smooth",
            "Geser dan scroll jadi licin, tidak patah-patah: animasi sistem dipercepat. " +
                "Untuk hasil terbaik nyalakan juga Smooth FPS (kunci refresh rate) dan Stabil FPS (clock tidak naik-turun).",
            "ROOT/SHIZUKU", pSm)
        animRow.orientation = LinearLayout.HORIZONTAL
        renderAnim()
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(animRow)
        box.addView(hs)

        // ---- Acceleration ----
        buildPickerSection(
            title = "Touch Acceleration",
            desc = "Akselerasi kecepatan geser: semakin tinggi semakin agresif. " +
                   "Berguna untuk swipe cepat di game FPS/battle royale.",
            levels = TouchAccel.LEVELS,
            getCur = { TouchAccel.current(ctx) },
            onApply = { lv ->
                result.setTextColor(Hud.sub); result.text = "Menerapkan Acceleration..."
                Thread {
                    val r = TouchAccel.apply(ctx, lv)
                    root.post { result.setTextColor(Color.parseColor("#38E8A5")); result.text = r }
                }.start()
            }
        )

        // ---- Smoothing ----
        buildPickerSection(
            title = "Touch Smoothing",
            desc = "Haluskan jalur sentuhan agar gerakan tidak patah-patah. " +
                   "Mati = raw (paling responsif), Super Halus = paling mulus.",
            levels = TouchSmoothing.LEVELS,
            getCur = { TouchSmoothing.current(ctx) },
            onApply = { lv ->
                result.setTextColor(Hud.sub); result.text = "Menerapkan Smoothing..."
                Thread {
                    val r = TouchSmoothing.apply(ctx, lv)
                    root.post { result.setTextColor(Color.parseColor("#38E8A5")); result.text = r }
                }.start()
            }
        )

        // ---- Sensitivitas X / Y ----
        sensStartIdx = box.childCount
        buildSensSection()

        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.addView(btn("Terapkan sekarang", primary = true) { applyNow() },
            LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(8) })
        bar.addView(btn("Reset ke bawaan") { resetNow() })
        box.addView(bar, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(14) })

        result.textSize = 10f
        result.setTextColor(Color.parseColor("#38E8A5"))
        box.addView(result, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(8) })

        info.textSize = 9.5f
        info.setTextColor(Hud.sub)
        info.text = "Memeriksa jalur touch di HP ini..."
        box.addView(info, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(10) })
        Thread {
            Access.ensure()
            val d = if (Access.hasAny()) TouchOpt.detect() else "Aktifkan root/Shizuku untuk memeriksa jalur touch."
            root.post { info.text = d }
        }.start()
    }

    // bila boost sedang aktif, langsung terapkan perubahan toggle
    private fun reapplyIfActive() {
        if (store.active) Thread { Boost.refresh(ctx) }.start()
    }

    // dipakai saat toggle / pilihan animasi diubah: langsung terapkan lalu tampilkan hasil
    private fun applyLive() {
        if (!Access.requires(ctx, "Touch Optimizer", false)) return
        result.setTextColor(Hud.sub)
        result.text = "Menerapkan..."
        Thread {
            TouchOpt.restore(ctx)
            val r = TouchOpt.apply(ctx, store.touch, store.touchSmooth, store.touchAnim)
            val v = TouchOpt.verify(store.touch, store.touchSmooth, store.touchAnim)
            root.post { result.setTextColor(Color.parseColor("#38E8A5")); result.text = r + "\n" + v }
        }.start()
    }

    private fun applyNow() = applyLive()

    private fun resetNow() {
        if (!Access.requires(ctx, "Touch Optimizer", false)) return
        Thread {
            val r = TouchOpt.restore(ctx)
            root.post { result.setTextColor(Color.parseColor("#38E8A5")); result.text = r }
        }.start()
    }

    // ---- Sensitivitas X / Y ----
    // Dipanggil setelah section animasi; menyisipkan baris slider ke dalam box.
    // Picker tombol horizontal untuk Acceleration & Smoothing
    private fun buildPickerSection(
        title: String, desc: String,
        levels: List<String>,
        getCur: () -> Int,
        onApply: (Int) -> Unit
    ) {
        val titleRow = LinearLayout(ctx)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        val titleTv = tv(title, 12f, Color.WHITE, true)
        val tagTv   = tv("ROOT/SHIZUKU", 9f, Color.parseColor("#FFC24B"), true)
        tagTv.setPadding(0, 0, px(8), 0)
        titleRow.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f))
        titleRow.addView(tagTv)
        box.addView(titleRow, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(12) })
        box.addView(tv(desc, 10f, Hud.sub), LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(6) })

        val chipRow = LinearLayout(ctx)
        chipRow.orientation = LinearLayout.HORIZONTAL
        val chips = ArrayList<TextView>()

        fun refreshChips(selected: Int) {
            for ((i, chip) in chips.withIndex()) {
                val sel = i == selected
                chip.setTextColor(if (sel) Color.parseColor("#04141F") else Color.WHITE)
                chip.background = if (sel)
                    Hud.rounded(Hud.cyan, Hud.cyan, ctx.pxf(14f), 1f)
                else
                    Hud.rounded(Color.argb(80, 255, 255, 255), Color.argb(50, 255, 255, 255), ctx.pxf(14f), 1f)
            }
        }

        for ((i, name) in levels.withIndex()) {
            val chip = tv(name, 10.5f, Color.WHITE, true)
            chip.gravity = Gravity.CENTER
            chip.setPadding(px(10), px(6), px(10), px(6))
            chip.setOnClickListener {
                Sfx.tap()
                refreshChips(i)
                onApply(i)
            }
            chips.add(chip)
            val lp = LinearLayout.LayoutParams(-2, -2)
            lp.rightMargin = px(5)
            chipRow.addView(chip, lp)
        }

        val cur = getCur()
        refreshChips(cur)

        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chipRow)
        box.addView(hs, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(4) })
    }

    // ================================================================
    //  SENSITIVITAS X / Y — slider drag SeekBar (100 step = 0.1–5.0)
    //  MIN=0.1, MAX=5.0, step 0.05 → 98 langkah (progress 0..98)
    //  progress 0 = 0.1×, progress 18 = 1.0× (default), progress 98 = 5.0×
    //
    //  Kenapa SeekBar bukan custom track:
    //  SeekBar Android sudah handle drag, accessibility, dan touch event
    //  dengan benar — tidak ada bug geser yang bertabrakan dengan ScrollView.
    //  Kita pakai requestDisallowInterceptTouchEvent agar scroll panel
    //  tidak "mencuri" sentuhan saat user drag slider.
    // ================================================================

    private val SENS_MIN    = 0.1f
    private val SENS_MAX    = 5.0f
    private val SENS_STEPS  = 98   // (5.0 - 0.1) / 0.05 = 98 langkah
    private val SENS_DEFAULT_PROGRESS = 18  // 0.1 + 18*0.05 = 1.0

    // Konversi progress (0..98) ↔ nilai float (0.1..5.0)
    private fun progressToSens(p: Int): Float =
        (SENS_MIN + p * 0.05f).coerceIn(SENS_MIN, SENS_MAX)
            .let { kotlin.math.round(it * 20) / 20f }

    private fun sensToProgress(v: Float): Int =
        ((v - SENS_MIN) / 0.05f).toInt().coerceIn(0, SENS_STEPS)

    private fun buildSensSection() {
        // --- Judul ---
        val titleRow = LinearLayout(ctx)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        val titleTv = tv("Sensitivitas X / Y", 12f, Color.WHITE, true)
        val tagTv   = tv("ROOT/SHIZUKU", 9f, Color.parseColor("#FFC24B"), true)
        tagTv.setPadding(0, 0, px(8), 0)
        titleRow.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f))
        titleRow.addView(tagTv)
        box.addView(titleRow, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(12) })

        box.addView(tv(
            "↔ X = kecepatan geser KIRI-KANAN (aim horizontal, swipe menu).\n" +
            "↕ Y = kecepatan geser ATAS-BAWAH (aim vertikal, kontrol recoil).\n" +
            "Pilih preset: Normal = bawaan sistem (1.0×). Makin tinggi = makin cepat.",
            10f, Hud.sub
        ), LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(8) })

        // --- Slider X ---
        box.addView(makeSensSeekRow(
            label    = "↔  Sumbu X  (Horizontal / Kiri-Kanan)",
            isX      = true,
            initVal  = store.touchSensX
        ))

        // --- Slider Y ---
        box.addView(makeSensSeekRow(
            label    = "↕  Sumbu Y  (Vertikal / Atas-Bawah)",
            isX      = false,
            initVal  = store.touchSensY
        ))

        // --- Tombol reset ---
        val rBtn = btn("↺  Reset X & Y ke 1.0× (bawaan)") {
            store.touchSensX = 1.0f
            store.touchSensY = 1.0f
            // hapus rowX & rowY lama (2 view sebelum rBtn) lalu rebuild
            val rIdx = box.childCount   // rBtn belum ditambah, jadi ini idx tepat setelah Y
            // remove rowY (idx-1) dan rowX (idx-2) dari box setelah btn masuk
            // mudahnya: rebuild seluruh section
            rebuildSens()
            applySens()
        }
        box.addView(rBtn, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(6) })
    }

    // Hitung berapa view yang dipakai buildSensSection (title,desc,rowX,rowY,resetBtn)

    private fun rebuildSens() {
        if (sensStartIdx < 0) return
        repeat(SENS_VIEW_COUNT) {
            if (sensStartIdx < box.childCount) box.removeViewAt(sensStartIdx)
        }
        // ---- sisipkan ulang ----
        val at = sensStartIdx
        val titleRow = LinearLayout(ctx).also { r ->
            r.orientation = LinearLayout.HORIZONTAL; r.gravity = Gravity.CENTER_VERTICAL
            r.addView(tv("Sensitivitas X / Y", 12f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
            val tag = tv("ROOT/SHIZUKU", 9f, Color.parseColor("#FFC24B"), true)
            tag.setPadding(0, 0, px(8), 0); r.addView(tag)
        }
        box.addView(titleRow, at)
        box.addView(tv(
            "↔ X = kiri-kanan   ↕ Y = atas-bawah   |   1.0× = bawaan   >1.0 = lebih cepat",
            10f, Hud.sub
        ), at + 1)
        box.addView(makeSensSeekRow("↔  Sumbu X  (Horizontal)", true,  store.touchSensX), at + 2)
        box.addView(makeSensSeekRow("↕  Sumbu Y  (Vertikal)",   false, store.touchSensY), at + 3)
        box.addView(btn("↺  Reset X & Y ke 1.0×") {
            store.touchSensX = 1.0f; store.touchSensY = 1.0f
            rebuildSens(); applySens()
        }, at + 4)
    }

    // Preset sensitivitas (klik, bukan geser)
    // dibuat sebagai fungsi (bukan properti) karena dipanggil dari init; properti belum terisi saat itu
    private fun sensPresets() = listOf(
        "Lambat" to 0.5f,
        "Normal" to 1.0f,
        "Medium" to 1.5f,
        "High" to 2.0f,
        "Maksimal" to 3.0f,
        "Ultra" to 4.0f,
        "Extra" to 5.0f
    )

    // Satu baris: label + nilai aktif + tombol preset (klik untuk memilih)
    private fun makeSensSeekRow(label: String, isX: Boolean, initVal: Float): LinearLayout {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.VERTICAL
        row.background = Hud.card(ctx)
        row.setPadding(px(10), px(8), px(10), px(8))

        val header = LinearLayout(ctx)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val valTv = tv(sensLabel(initVal), 12f, Hud.cyan, true)
        valTv.gravity = Gravity.END
        header.addView(tv(label, 11f, Color.parseColor("#B8E0FF")), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(valTv)
        row.addView(header, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(8) })

        val chips = ArrayList<Pair<Float, TextView>>()
        fun currentVal() = if (isX) store.touchSensX else store.touchSensY
        fun refreshChips() {
            val cur = currentVal()
            for ((v, t) in chips) {
                val on = kotlin.math.abs(v - cur) < 0.01f
                t.setTextColor(if (on) Color.parseColor("#04141F") else Color.WHITE)
                t.background = Hud.rounded(
                    if (on) Hud.cyan else Color.argb(40, 0, 230, 255),
                    if (on) Hud.cyan else Color.argb(90, 0, 230, 255),
                    ctx.pxf(8f), 1f
                )
            }
            valTv.text = sensLabel(cur)
        }

        val perRow = 4
        sensPresets().chunked(perRow).forEach { chunk ->
            val r = LinearLayout(ctx)
            r.orientation = LinearLayout.HORIZONTAL
            for ((name, v) in chunk) {
                val t = TextView(ctx).apply {
                    text = "$name\n${"%.1f×".format(v)}"
                    textSize = 10f
                    gravity = Gravity.CENTER
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    setPadding(px(2), px(8), px(2), px(8))
                    isClickable = true
                    setOnClickListener {
                        if (isX) store.touchSensX = v else store.touchSensY = v
                        refreshChips()
                        applySens()
                    }
                }
                chips.add(v to t)
                r.addView(t, LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(px(2), px(2), px(2), px(2)) })
            }
            row.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        refreshChips()
        return row
    }

    private fun sensLabel(v: Float): String {
        val s = "%.1f×".format(v)
        return when {
            v < 1.0f -> "$s  ▼ lebih lambat"
            v > 1.0f -> "$s  ▲ lebih cepat"
            else     -> "$s  (bawaan)"
        }
    }

    private fun applySens() {
        Thread {
            TouchSens.apply(ctx, store.touchSensX, store.touchSensY)
        }.start()
    }
}


