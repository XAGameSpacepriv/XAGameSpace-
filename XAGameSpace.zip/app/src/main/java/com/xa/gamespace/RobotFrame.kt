package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.drawable.Drawable

// Latar panel menu bawah bergaya robot.
// - sudut atas & bawah terpotong (chamfer) seperti bingkai mecha
// - isi gradasi gelap, highlight tipis di dalam tepi
// - garis neon bercahaya di tepi (semua garis berada di dalam bingkai)
// - bracket mekanik bersegmen di sisi kiri dan kanan
class RobotFrameDrawable(ctx: Context, private val fill: Int, private val stroke: Int) : Drawable() {

    /** Lebar potongan sudut (dp). Garis apa pun di atas harus dibatasi di dalam area ini. */
    val cutDp = 24f

    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    /** posisi kilatan neon (0..1), diubah oleh animasi di MainActivity */
    var phase = 0f

    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val sweepP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
        strokeCap = Paint.Cap.BUTT
    }
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1.4f)
        color = stroke
        strokeJoin = Paint.Join.MITER   // sudut tajam, tidak membulat / melebar
        strokeMiter = 2f
        setShadowLayer(dp(5f), 0f, 0f, stroke)
    }
    private val innerP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
        color = Color.argb(70, 255, 255, 255)
    }
    private val barP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = stroke
        setShadowLayer(dp(6f), 0f, 0f, stroke)
    }
    private val dimP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(70, Color.red(stroke), Color.green(stroke), Color.blue(stroke))
    }
    private val path = Path()
    private val innerPath = Path()

    private fun framePath(p: Path, l: Float, t: Float, r: Float, bo: Float, cut: Float) {
        p.reset()
        p.moveTo(l + cut, t)
        p.lineTo(r - cut, t)
        p.lineTo(r, t + cut)
        p.lineTo(r, bo - cut)
        p.lineTo(r - cut, bo)
        p.lineTo(l + cut, bo)
        p.lineTo(l, bo - cut)
        p.lineTo(l, t + cut)
        p.close()
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val l = b.left.toFloat()
        val t = b.top.toFloat()
        val r = b.right.toFloat()
        val bo = b.bottom.toFloat()
        val cut = dp(cutDp)

        // semua gambar dipotong di dalam batas bingkai, supaya tidak ada garis yang keluar
        canvas.save()
        canvas.clipRect(b)

        // isi gradasi: atas sedikit lebih terang, bawah lebih gelap
        val bottomCol = Color.argb(Color.alpha(fill), 4, 10, 22)
        fillP.shader = LinearGradient(0f, t, 0f, bo, fill, bottomCol, Shader.TileMode.CLAMP)

        framePath(path, l, t, r, bo, cut)
        canvas.drawPath(path, fillP)
        canvas.drawPath(path, lineP)

        // highlight tipis 3dp di dalam bingkai
        val ins = dp(3f)
        framePath(innerPath, l + ins, t + ins, r - ins, bo - ins, cut * 0.9f)
        canvas.drawPath(innerPath, innerP)

        // takik di tengah tepi atas (kepala robot)
        val cx = (l + r) / 2f
        val notchW = dp(70f)
        val notchH = dp(4f)
        canvas.drawRect(cx - notchW / 2, t - notchH / 2, cx + notchW / 2, t + notchH / 2, barP)

        // kilatan neon di tepi atas (maju) dan bawah (mundur), di dalam bingkai
        canvas.save()
        canvas.clipPath(path)
        val span = (r - l) - 2f * cut
        val half = dp(60f)
        val xTop = l + cut + span * phase
        val xBot = l + cut + span * (1f - phase)
        sweepP.shader = LinearGradient(xTop - half, t, xTop + half, t,
            intArrayOf(Color.TRANSPARENT, Color.argb(230, 180, 245, 255), Color.TRANSPARENT),
            null, Shader.TileMode.CLAMP)
        canvas.drawLine(xTop - half, t + dp(1f), xTop + half, t + dp(1f), sweepP)
        sweepP.shader = LinearGradient(xBot - half, bo, xBot + half, bo,
            intArrayOf(Color.TRANSPARENT, Color.argb(230, 180, 245, 255), Color.TRANSPARENT),
            null, Shader.TileMode.CLAMP)
        canvas.drawLine(xBot - half, bo - dp(1f), xBot + half, bo - dp(1f), sweepP)
        canvas.restore()

        // bracket mekanik bersegmen di kedua sisi (di dalam area lurus sisi)
        val inset = dp(7f)
        val segTop = t + cut + dp(10f)
        val segBottom = bo - cut - dp(10f)
        val segH = dp(14f)
        val gap = dp(6f)
        var y = segTop
        var i = 0
        while (y + segH <= segBottom) {
            val p = if (i % 3 == 1) dimP else barP
            canvas.drawRect(l + inset, y, l + inset + dp(3f), y + segH, p)
            canvas.drawRect(r - inset - dp(3f), y, r - inset, y + segH, p)
            y += segH + gap
            i++
        }
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {
        fillP.alpha = alpha
        lineP.alpha = alpha
        innerP.alpha = alpha
        barP.alpha = alpha
        dimP.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillP.colorFilter = colorFilter
        lineP.colorFilter = colorFilter
        barP.colorFilter = colorFilter
        dimP.colorFilter = colorFilter
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
