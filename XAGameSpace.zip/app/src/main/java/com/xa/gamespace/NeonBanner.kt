package com.xa.gamespace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View

// Banner musik: animasi neon (grid perspektif, sorotan melintas, partikel) yang digambar langsung
// di resolusi layar. Tajam di HD dan halus 60 fps karena dijadwalkan ke vsync.
class NeonBanner(c: Context) : View(c) {
    private val t0 = System.nanoTime()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        color = Color.WHITE
        letterSpacing = 0.12f
    }
    private val rnd = java.util.Random(3)
    private val dots = Array(40) { floatArrayOf(rnd.nextFloat(), rnd.nextFloat(), 0.05f + rnd.nextFloat() * 0.12f) }
    private val dens = c.resources.displayMetrics.density

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val t = (System.nanoTime() - t0) / 1_000_000_000f

        // latar: ungu ke biru malam
        fill.shader = LinearGradient(0f, 0f, 0f, h,
            Color.parseColor("#2A1450"), Color.parseColor("#07203C"), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, fill)
        fill.shader = null

        // sorotan melintas
        val sx = ((t * 0.18f) % 1.4f - 0.2f) * w
        fill.shader = RadialGradient(sx, h * 0.35f, w * 0.45f,
            intArrayOf(Color.argb(110, 120, 240, 255), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, fill)
        fill.shader = null

        // grid perspektif: garis horizontal mengalir ke bawah
        val hor = h * 0.42f
        line.strokeWidth = 1.2f * dens
        val scroll = (t * 0.5f) % 1f
        for (i in 0..11) {
            val f = (i + scroll) / 12f
            val y = hor + (h - hor) * f * f
            line.color = Color.argb((160 * f).toInt().coerceIn(20, 170), 80, 220, 255)
            cv.drawLine(0f, y, w, y, line)
        }
        for (i in -10..10) {
            line.color = Color.argb(90, 80, 220, 255)
            cv.drawLine(w / 2f + i * w * 0.09f * 0.25f, h, w / 2f + i * w * 0.09f, hor, line)
        }

        // partikel naik
        fill.shader = null
        for (d in dots) {
            val y = ((d[1] - t * d[2]) % 1f + 1f) % 1f
            fill.color = Color.argb(150, 180, 240, 255)
            cv.drawCircle(d[0] * w, y * h, 1.6f * dens, fill)
        }

        // judul di pojok kiri bawah
        txt.textSize = 13f * dens
        txt.setShadowLayer(10f * dens, 0f, 0f, Color.argb(160, 60, 200, 255))
        cv.drawText("XA GAMESPACE", 12f * dens, h - 12f * dens, txt)

        postInvalidateOnAnimation()
    }
}
