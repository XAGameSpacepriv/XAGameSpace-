package com.xa.gamespace

import java.io.File

// ============================================================
//  Deteksi GPU & driver (TANPA ROOT)
//  Hanya membaca properti sistem (getprop) dan sysfs yang bisa dibaca app.
//  Vendor dipetakan dari SoC / driver EGL. Rekomendasi per vendor berbeda (beda driver beda kode).
// ============================================================
object GpuDetect {
    data class Info(val vendor: String, val model: String, val soc: String, val egl: String)
    data class Profile(val level: Int, val sharp: Boolean, val mip: Boolean, val note: String)

    private fun prop(k: String): String = try {
        Runtime.getRuntime().exec(arrayOf("getprop", k)).inputStream.bufferedReader().readText().trim()
    } catch (e: Exception) { "" }

    private fun readFile(path: String): String = try { File(path).readText().trim() } catch (e: Exception) { "" }

    fun detect(): Info {
        val soc = listOf(prop("ro.soc.model"), prop("ro.board.platform"), android.os.Build.HARDWARE)
            .firstOrNull { it.isNotBlank() } ?: "?"
        val egl = prop("ro.hardware.egl")
        val hint = "$soc $egl ${android.os.Build.HARDWARE} ${android.os.Build.BOARD}".lowercase()
        val kgsl = readFile("/sys/class/kgsl/kgsl-3d0/gpu_model")
        val vendor = when {
            kgsl.isNotBlank() || hint.contains("adreno") || hint.contains("qcom") ||
                hint.contains("snapdragon") || hint.contains("kona") || hint.contains("lahaina") -> "ADRENO"
            hint.contains("xclipse") -> "XCLIPSE"
            hint.contains("mali") || hint.contains("mt6") || hint.contains("mt8") ||
                hint.contains("dimensity") || hint.contains("exynos") || hint.contains("kirin") -> "MALI"
            hint.contains("powervr") || hint.contains("pvr") || hint.contains("unisoc") ||
                hint.contains("sc98") || hint.contains("tiger") -> "POWERVR"
            else -> "UNKNOWN"
        }
        val model = if (kgsl.isNotBlank()) kgsl else vendor
        return Info(vendor, model, soc, egl.ifBlank { "?" })
    }

    // Rekomendasi per vendor. Ini preset awal, bukan hasil ukur FPS. Silakan dites di perangkat.
    fun profile(vendor: String): Profile = when (vendor) {
        "ADRENO"  -> Profile(2, false, false, "Adreno: Retro, tanpa piksel & batas")
        "MALI"    -> Profile(1, false, false, "Mali: Ringan, tanpa piksel & batas")
        "XCLIPSE" -> Profile(2, false, false, "Xclipse: Retro, tanpa piksel & batas")
        "POWERVR" -> Profile(0, false, false, "PowerVR: Asli dulu, ANGLE sering tidak stabil")
        else      -> Profile(0, false, false, "GPU tidak dikenal: Asli, paling aman")
    }

    // Cek library ANGLE di sistem. Butuh Shizuku/root (shell), jadi dipanggil dari AiTune.
    val ANGLE_CHECK_CMD = "ls -d /system/*/*angle* /vendor/*/*angle* 2>/dev/null | head -n 3"
}
