package com.xa.gamespace

// Model sentuhan: disalin dari XAGameSpacepanel (model/BoosterModels.kt)

enum class TouchArea(val label: String) {
    ALL("Semua"), LEFT("Kiri"), RIGHT("Kanan")
}

data class TouchConfig(
    val enabled: Boolean = false,
    val speedX: Int = 0,          // -50..200%
    val speedY: Int = 0,          // -50..200%
    val responseBoost: Int = 0,   // 0..100%
    val area: TouchArea = TouchArea.ALL,
    val smoothing: Int = 0,       // 0..100%
    val deadzone: Int = 0,        // 0..50%
    val dpiBoostEnabled: Boolean = true,
    val nubiaGameTweakEnabled: Boolean = true,
    val liveAimPadEnabled: Boolean = false,
    val aimPadNormX: Float = 0.76f,
    val aimPadNormY: Float = 0.44f,
    val aimPadLocked: Boolean = false,
    // field di bawah dipakai TouchAmplifierMath (tidak ada di panel, ditambahkan dengan default aman)
    val touchSlopReduction: Int = 0,
    val pollingPreset: TouchPollingPreset = TouchPollingPreset.DEFAULT,
    val edgeRejectionOff: Boolean = false,
    val unifiedMultiTouch: Boolean = false
) {
    fun gainX(): Float = (1f + speedX / 100f + responseBoost * 0.0025f).coerceIn(0.45f, 3.25f)

    fun gainY(): Float = (1f + speedY / 100f + responseBoost * 0.0025f).coerceIn(0.45f, 3.25f)

    fun estimatedDensity(physicalDensity: Int): Int {
        val base = physicalDensity.coerceAtLeast(240)
        val weightedPct = speedX * 0.45f + speedY * 0.55f + responseBoost * 0.15f
        val scale = if (weightedPct >= 0f) {
            1f - (weightedPct / 215f) * 0.34f
        } else {
            1f + ((-weightedPct) / 50f) * 0.14f
        }
        return (base * scale).toInt().coerceIn(240, maxOf(base + 120, 640))
    }
}

// Catatan: enum ini tidak ada di project panel (dipakai tapi belum dideklarasikan), dibuat di sini
enum class TouchPollingPreset { DEFAULT, HIGH_240, ULTRA_480, MAX_HARDWARE }
