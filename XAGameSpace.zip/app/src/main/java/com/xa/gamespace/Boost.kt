package com.xa.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.WindowManager

data class RunApp(val pkg: String, val label: String, val system: Boolean, val memMb: Int, var selected: Boolean)

object Boost {
    const val AUTO_ROOT_TUNE = false

    private val lock = Any()

    private val PROTECT = listOf(
        "com.android.systemui", "com.android.phone", "com.android.providers.", "com.android.server.",
        "com.android.bluetooth", "com.android.nfc", "com.android.shell", "com.android.inputmethod",
        "com.android.networkstack", "com.android.permissioncontroller", "com.android.location",
        "com.android.settings", "com.android.launcher", "com.android.cellbroadcast",
        "com.android.carrierconfig", "com.android.stk", "com.android.se", "com.android.vending",
        "com.google.android.gms", "com.google.android.gsf", "com.google.android.inputmethod",
        "com.google.android.permissioncontroller", "com.google.android.networkstack",
        "com.google.android.ext", "com.qualcomm", "com.qti", "org.codeaurora", "com.mediatek",
        "vendor.", "com.miui.core", "com.miui.system", "com.miui.home", "com.miui.powerkeeper",
        "com.xiaomi.xmsf", "com.samsung.android.incallui", "com.samsung.android.dialer",
        "com.sec.android.app.launcher", "com.samsung.android.app.telephonyui"
    )

    private fun fixedProtect(ctx: Context): Set<String> {
        val s = HashSet<String>()
        s.add(ctx.packageName)
        val pm = ctx.packageManager
        try {
            pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
                ?.activityInfo?.packageName?.let { s.add(it) }
        } catch (e: Exception) {}
        try {
            val ime = android.provider.Settings.Secure.getString(ctx.contentResolver, "default_input_method")
            ime?.substringBefore('/')?.let { s.add(it) }
        } catch (e: Exception) {}
        try {
            (ctx.getSystemService(Context.TELECOM_SERVICE) as? android.telecom.TelecomManager)
                ?.defaultDialerPackage?.let { s.add(it) }
        } catch (e: Exception) {}
        return s
    }

    private fun isProtected(p: String, fixed: Set<String>): Boolean =
        p in fixed || p == "android" || p.startsWith("android.") || PROTECT.any { p.startsWith(it) }

    // paket yang satu keluarga dengan game (com.pubg.a dan com.pubg.b) ikut dilindungi
    private fun isGameFamily(p: String, keep: String?): Boolean {
        if (keep == null) return false
        return p.split('.').take(3) == keep.split('.').take(3)
    }

    // helper game dari OEM / Google (GameCenter, Game Booster, Play Games, dll)
    private val GAME_HINTS = listOf("game", "turbo", "com.google.android.play.games")
    private fun isGameHelper(p: String): Boolean = GAME_HINTS.any { p.contains(it) }

    // ---------- Scan aplikasi berjalan (user + sistem) ----------
    fun scan(ctx: Context, keep: String?): List<RunApp> {
        val pm = ctx.packageManager
        val installed = HashMap<String, android.content.pm.ApplicationInfo>()
        try { pm.getInstalledApplications(0).forEach { installed[it.packageName] = it } } catch (e: Exception) {}
        var out = Root.run("ps -A -o NAME,RSS 2>/dev/null")
        val mem = HashMap<String, Long>()
        if (out.isBlank() || !out.contains(Regex("\\d"))) {
            out = Root.run("ps")
            for (l in out.lines()) {
                val t = l.trim().split(Regex("\\s+"))
                if (t.size >= 8) mem[t.last().substringBefore(':')] =
                    (mem[t.last().substringBefore(':')] ?: 0L) + (t[4].toLongOrNull() ?: 0L)
            }
        } else {
            for (l in out.lines()) {
                val t = l.trim().split(Regex("\\s+"))
                if (t.size >= 2) {
                    val n = t[0].substringBefore(':')
                    mem[n] = (mem[n] ?: 0L) + (t[1].toLongOrNull() ?: 0L)
                }
            }
        }
        val fixed = fixedProtect(ctx)
        val list = ArrayList<RunApp>()
        for ((p, kb) in mem) {
            val ai = installed[p] ?: continue
            if (isProtected(p, fixed) || p == keep || isGameFamily(p, keep) || isGameHelper(p)) continue
            val sys = (ai.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
            list.add(RunApp(p, ai.loadLabel(pm).toString(), sys, (kb / 1024).toInt(), true))
        }
        return list.sortedByDescending { it.memMb }
    }

    fun stop(pkgs: List<String>) {
        // "am kill" hanya mematikan proses di latar (cached), tidak menandai aplikasi sebagai "stopped",
        // sehingga layanan/alarm/sinkronisasi game tidak dimatikan paksa dan tidak memicu download ulang data.
        if (pkgs.isNotEmpty()) Root.run(pkgs.joinToString("; ") { "am kill $it" })
    }

    fun killBackground(ctx: Context, keep: String?): Int {
        val t = scan(ctx, keep)
        stop(t.map { it.pkg })
        return t.size
    }

    // Diagnosa: daftar APK sistem yang kemungkinan berhubungan dengan game
    fun systemGameApps(): List<String> {
        val hints = listOf("game", "turbo", "gms", "play", "vending", "miui", "samsung", "huawei",
            "oppo", "realme", "vivo", "xiaomi", "download", "provider", "gos", "gamespace")
        return Root.run("pm list packages -s").lines()
            .map { it.removePrefix("package:").trim() }
            .filter { it.isNotEmpty() && hints.any { h -> it.contains(h, ignoreCase = true) } }
            .sorted()
    }

    // ---------- Bersihkan RAM ----------
    private fun availMb(ctx: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.availMem / 1048576
    }

    // daftar aplikasi yang TIDAK boleh di-clear (dicentang di menu Clear RAM)
    fun protectedSet(ctx: Context): Set<String> =
        Store(ctx).get("ram_keep").split(",").filter { it.isNotBlank() }.toSet()

    // Optimasi RAM: bertahap sampai RAM bebas >= targetPct% dari total (maks 3 putaran).
    // Putaran 1 hanya aplikasi pengguna; putaran berikutnya ikut aplikasi sistem non-inti (inti tetap dilindungi scan).
    fun optimizeRam(ctx: Context, keep: String?, targetPct: Int, includeSystem: Boolean = false): String {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        fun freePct(): Int {
            am.getMemoryInfo(mi)
            return if (mi.totalMem > 0) (100L * mi.availMem / mi.totalMem).toInt() else 0
        }
        val before = availMb(ctx)
        val prot = protectedSet(ctx)
        var killed = 0
        var round = 0
        while (round < 3 && freePct() < targetPct) {
            round++
            Root.run("sync; echo 3 > /proc/sys/vm/drop_caches")
            val list = scan(ctx, keep).filter { it.pkg !in prot && it.pkg != keep }
            // mode biasa: aplikasi sistem tidak dihentikan (penyebab game restart / minta download data)
            // mode Ultra (includeSystem): aplikasi sistem non-inti ikut; inti tetap dilindungi PROTECT
            val batch = if (includeSystem) list else list.filter { !it.system }
            killed += batch.size
            stop(batch.map { it.pkg })
            try { Thread.sleep(900) } catch (e: InterruptedException) {}
        }
        val after = freePct()
        val gain = (availMb(ctx) - before).coerceAtLeast(0)
        val tail = if (after >= targetPct) "Target $targetPct% tercapai."
        else "Target $targetPct% belum tercapai di HP ini; sudah dimaksimalkan untuk kondisi sekarang."
        return "RAM bebas $after% · $killed aplikasi dihentikan · +$gain MB. $tail"
    }

    fun cleanRam(ctx: Context, keep: String? = null): Long {
        val before = availMb(ctx)
        // tidak memakai "am kill-all" agar aplikasi yang dikecualikan tetap jalan
        Root.run("sync; echo 3 > /proc/sys/vm/drop_caches")
        val prot = protectedSet(ctx)
        val user = scan(ctx, keep).filter { !it.system && it.pkg !in prot }
        stop(user.map { it.pkg })
        try { Thread.sleep(800) } catch (e: InterruptedException) {}
        return (availMb(ctx) - before).coerceAtLeast(0)
    }

    // ---------- GPU ----------
    private const val GPU_READ = """
for d in /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/*gpu* /sys/class/devfreq/*mali*; do
  [ -f §d/min_freq ] || continue
  echo "G|§d|§(cat §d/min_freq 2>/dev/null)|§(cat §d/max_freq 2>/dev/null)|§(cat §d/available_frequencies 2>/dev/null)"
done
"""

    private fun readGpu(): List<List<String>> =
        Root.run(GPU_READ.replace('§', '$')).lines().filter { it.startsWith("G|") }.map { it.split("|") }

    private fun refreshMax(ctx: Context): Int {
        return try {
            if (Build.VERSION.SDK_INT >= 23) {
                val d = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay
                d.supportedModes.maxOf { it.refreshRate }.toInt().coerceAtLeast(60)
            } else 60
        } catch (e: Exception) { 60 }
    }

    private val REFRESH_KEYS = listOf("min_refresh_rate", "peak_refresh_rate", "user_refresh_rate")

    private fun readSettings(): String = Root.run(
        REFRESH_KEYS.joinToString("; ") { "echo \"system|$it|\$(settings get system $it)\"" } +
            "; echo \"global|low_power|\$(settings get global low_power)\""
    )

    private fun restoreSettings(saved: String): List<String> = saved.lines().mapNotNull {
        val p = it.trim().split("|")
        if (p.size == 3) {
            if (p[2].isBlank() || p[2] == "null") "settings delete ${p[0]} ${p[1]}"
            else "settings put ${p[0]} ${p[1]} ${p[2]}"
        } else null
    }

    // ---------- Boost ON / OFF ----------
    fun on(ctx: Context, game: String?) { synchronized(lock) {
        val s = Store(ctx)
        if (!s.active) { /* tidak ada snapshot yang perlu disimpan */ }
        s.active = true
        s.game = game

        val c = ArrayList<String>()
        // Hanya jalankan GameCmd yang sudah disimpan user untuk game ini
        if (game != null) {
            val gc = s.get("gc_$game")
            if (gc.isNotBlank()) c.add(gc)
        }
        // Texture ANGLE: hanya bila mode "Auto saat main" aktif
        val tex = game?.let { s.get(Texture.levelKey(it)) } ?: ""
        if (Access.isRoot && s.get(Texture.KEY_AUTO) == "1" && tex.isNotBlank() && tex != "0") {
            c.add(Texture.applyCmd(tex, s.get(Texture.KEY_SHARP) == "1", s.get(Texture.KEY_MIP) == "1"))
            s.put(Texture.KEY_APPLIED, "1")
        }
        if (c.isNotEmpty()) Root.run(c.joinToString("\n"))
        if (s.get("wifi_lock") != "0") NetOpt.holdWifi(ctx, true)
        // RAM TIDAK dibersihkan otomatis saat game dibuka.
        // Pembersihan hanya manual (tombol Clean RAM / Stop App di Game Panel atau menu utama).
    } }

    fun off(ctx: Context) { synchronized(lock) {
        val s = Store(ctx)
        if (!s.active) return@synchronized
        val c = ArrayList<String>()
        // Kembalikan texture ANGLE hanya bila boost yang memasangnya (mode Auto)
        if (s.get(Texture.KEY_APPLIED) == "1") {
            c.add(Texture.resetCmd())
            s.put(Texture.KEY_APPLIED, "")
        }
        // Reset GameCmd game
        s.game?.let {
            if (s.get("gc_$it").isNotBlank()) c.add("cmd game reset $it")
            c.add("cmd game mode standard $it")
        }
        if (c.isNotEmpty()) Root.run(c.filter { it.isNotBlank() }.joinToString("\n"))
        NetOpt.holdWifi(ctx, false)
        NetOpt.idle(ctx, false)
        s.active = false
        s.game = null
    } }

    // dipanggil saat toggle Stabil/Smooth diubah ketika boost sedang aktif
    fun refresh(ctx: Context) {
        val s = Store(ctx)
        if (!s.active) return
        val g = s.game
        off(ctx)
        on(ctx, g)
    }
}
