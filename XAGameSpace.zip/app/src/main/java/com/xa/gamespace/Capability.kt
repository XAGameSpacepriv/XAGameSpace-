package com.xa.gamespace

import android.content.Context
import android.os.Build
import android.provider.Settings

// Cek fitur yang bisa jalan di HP ini, sesuai akses (tanpa / Shizuku / root) dan versi Android.
object Capability {
    // (nama fitur, bisa dipakai?, alasan kalau tidak)
    fun report(ctx: Context): List<Triple<String, Boolean, String>> {
        val access = Access.isRoot || Access.hasAny() || Access.shizukuGranted()
        val noAccess = "butuh Shizuku atau root"
        val overlay = Settings.canDrawOverlays(ctx)
        val list = ArrayList<Triple<String, Boolean, String>>()
        list.add(Triple("Info perangkat, Latar, Mode 2, Aktivitas", true, ""))
        list.add(Triple("Filter Hangat/Dingin/Redup/Vivid/Full Color", overlay, "butuh izin tampil di atas aplikasi"))
        list.add(Triple("Filter Grayscale & Invert", access, noAccess))
        list.add(Triple("Texture (ANGLE)", access && Build.VERSION.SDK_INT >= 35,
            if (Build.VERSION.SDK_INT < 35) "butuh Android 15 minimal" else noAccess))
        list.add(Triple("Render ringan & paling ringan", access, noAccess))

        list.add(Triple("Pendingin", access, noAccess))
        list.add(Triple("Mode HP (Normal/Balance/Performa)", access, noAccess))
        list.add(Triple("Clear RAM & Stop App", access, noAccess))
        list.add(Triple("Optimal Jaringan (Boost)", access, noAccess))
        return list
    }
}
