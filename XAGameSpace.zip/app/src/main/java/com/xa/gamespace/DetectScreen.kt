package com.xa.gamespace

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

// Layar PERTAMA KALI saat aplikasi dibuka:
// 1) pengizinan (tampil di atas aplikasi, modifikasi sistem, root / Shizuku)
// 2) deteksi perangkat & driver, hasil disimpan
// 3) hitung mundur 3 detik lalu masuk GameSpace
class DetectScreen(private val ctx: Context, private val onDone: () -> Unit) : FrameLayout(ctx) {
    private val title = TextView(ctx)
    private val info = TextView(ctx)
    private val permBox = LinearLayout(ctx)
    private val countdown = TextView(ctx)
    private var detectStarted = false
    private var enterBtn: TextView? = null
    private var langBtnRef: TextView? = null
    private var finished = false

    private fun showLangDialog() {
        // Dialog pilih bahasa — AlertDialog dengan chip grid
        val dialogView = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.px(16), ctx.px(12), ctx.px(16), ctx.px(8))
        }

        val titleTv = TextView(ctx).apply {
            text = Lang.s(ctx,"lang_dialog_title")
            textSize = 13f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, ctx.px(12))
        }
        dialogView.addView(titleTv)

        // Grid chip 2 kolom
        var row: LinearLayout? = null
        for ((i, entry) in Lang.LANGS.withIndex()) {
            if (i % 2 == 0) {
                row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
                dialogView.addView(row, LinearLayout.LayoutParams(-1, -2).also {
                    it.bottomMargin = ctx.px(6)
                })
            }
            val isCur = entry.code == Lang.get(ctx)
            val chip = TextView(ctx).apply {
                text = "${entry.flag}  ${entry.name}"
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(ctx.px(8), ctx.px(10), ctx.px(8), ctx.px(10))
                setTextColor(if (isCur) Color.parseColor("#04141F") else Color.WHITE)
                background = Hud.rounded(
                    if (isCur) Hud.cyan else Color.argb(60, 46, 200, 255),
                    if (isCur) Hud.cyan else Color.argb(100, 46, 200, 255),
                    ctx.pxf(10f), 1f
                )
            }
            val lp = LinearLayout.LayoutParams(0, -2, 1f)
            if (i % 2 == 0) lp.rightMargin = ctx.px(6)
            row!!.addView(chip, lp)
        }
        // isi baris terakhir jika ganjil
        if (Lang.LANGS.size % 2 != 0) row?.addView(View(ctx), LinearLayout.LayoutParams(0, -2, 1f))

        val sv = android.widget.ScrollView(ctx).apply {
            isVerticalScrollBarEnabled = false
            addView(dialogView)
        }

        val dialog = android.app.AlertDialog.Builder(ctx)
            .setView(sv)
            .create()
        dialog.window?.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(Color.parseColor("#0D1E30"))
        )

        // set onClick setelah dialog dibuat agar bisa dismiss
        var chipIdx = 0
        for (j in 0 until dialogView.childCount) {
            val v = dialogView.getChildAt(j)
            if (v !is LinearLayout) continue
            for (k in 0 until v.childCount) {
                val chip = v.getChildAt(k) as? TextView ?: continue
                val entry = Lang.LANGS.getOrNull(chipIdx++) ?: continue
                chip.setOnClickListener {
                    Lang.set(ctx, entry.code)
                    // update teks tombol di permBox
                    langBtnRef?.text = Lang.s(ctx,"lang_btn_prefix") + " ${entry.flag} ${entry.name}"
                    dialog.dismiss()
                }
            }
        }

        dialog.show()
    }

    private class RobotView(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val green = Color.parseColor("#3DDC84")
            p.color = green
            p.style = Paint.Style.STROKE
            p.strokeWidth = w * 0.025f
            p.strokeCap = Paint.Cap.ROUND
            cv.drawLine(w * 0.36f, h * 0.20f, w * 0.28f, h * 0.06f, p)
            cv.drawLine(w * 0.64f, h * 0.20f, w * 0.72f, h * 0.06f, p)
            p.style = Paint.Style.FILL
            cv.drawArc(RectF(w * 0.22f, h * 0.18f, w * 0.78f, h * 0.18f + w * 0.56f), 180f, 180f, true, p)
            cv.drawRoundRect(RectF(w * 0.22f, h * 0.50f, w * 0.78f, h * 0.78f), w * 0.06f, w * 0.06f, p)
            cv.drawRoundRect(RectF(w * 0.08f, h * 0.50f, w * 0.18f, h * 0.74f), w * 0.05f, w * 0.05f, p)
            cv.drawRoundRect(RectF(w * 0.82f, h * 0.50f, w * 0.92f, h * 0.74f), w * 0.05f, w * 0.05f, p)
            cv.drawRoundRect(RectF(w * 0.32f, h * 0.78f, w * 0.46f, h * 0.96f), w * 0.04f, w * 0.04f, p)
            cv.drawRoundRect(RectF(w * 0.54f, h * 0.78f, w * 0.68f, h * 0.96f), w * 0.04f, w * 0.04f, p)
            p.color = Color.parseColor("#06101C")
            cv.drawCircle(w * 0.38f, h * 0.40f, w * 0.04f, p)
            cv.drawCircle(w * 0.62f, h * 0.40f, w * 0.04f, p)
        }
    }

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(t: String, onClick: () -> Unit) = TextView(ctx).apply {
        text = t; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(ctx.px(12), ctx.px(10), ctx.px(12), ctx.px(10))
        background = Hud.rounded(Color.parseColor("#1E6FA8"), Hud.cyan, ctx.pxf(12f), 1.2f)
        setOnClickListener { onClick() }
    }

    private fun openSettings(action: String) {
        val i = Intent(action, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (e: Exception) {}
    }

    // status izin, diperbarui berkala selama layar pengizinan tampil
    private val statusTexts = ArrayList<TextView>()
    private val checkRunnable = object : Runnable {
        override fun run() {
            if (finished) return
            val overlay = Settings.canDrawOverlays(ctx)
            val write = Settings.System.canWrite(ctx)
            val access = Access.isRoot || Access.shizukuGranted()
            statusTexts[0].text = if (overlay) Lang.s(ctx,"perm_overlay_ok") else Lang.s(ctx,"perm_overlay_no")
            statusTexts[1].text = if (write) Lang.s(ctx,"perm_write_ok") else Lang.s(ctx,"perm_write_no")
            statusTexts[2].text = when {
                Access.isRoot -> Lang.s(ctx,"perm_root_ok")
                Access.shizukuGranted() -> Lang.s(ctx,"perm_shizuku_ok")
                else -> Lang.s(ctx,"perm_access_no")
            }
            // hanya izin tampil di atas aplikasi yang wajib (untuk panel); sisanya opsional
            // tombol masuk hanya aktif setelah tampil di atas aplikasi & modifikasi sistem diizinkan.
            // root / Shizuku tidak dipaksa; tidak ada yang membuka GameSpace otomatis.
            // tombol masuk selalu aktif: user tanpa izin tetap bisa pakai panel (musik, suara, dll).
            // fitur yang butuh izin akan memberi tahu saat dipakai.
            val ready = overlay && write
            enterBtn?.alpha = 1f
            enterBtn?.text = if (ready) Lang.s(ctx,"btn_enter") else Lang.s(ctx,"btn_enter_no_perm")
            if (!finished) postDelayed(this, 700)
        }
    }

    init {
        setBackgroundColor(Color.parseColor("#06101C"))
        isClickable = true
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(ctx.px(24), ctx.px(24), ctx.px(24), ctx.px(24))
        }
        col.addView(RobotView(ctx), LinearLayout.LayoutParams(ctx.px(140), ctx.px(140)))
        title.text = Lang.s(ctx,"perm_title")
        title.textSize = 14f
        title.setTextColor(Hud.neon)
        title.gravity = Gravity.CENTER
        col.addView(title, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(10) })

        permBox.orientation = LinearLayout.VERTICAL
        for (i in 0 until 3) {
            val t = tv("", 12f, Color.argb(230, 220, 240, 255))
            statusTexts.add(t)
            permBox.addView(t, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(6) })
        }
        permBox.addView(button(Lang.s(ctx,"btn_overlay")) { openSettings(Settings.ACTION_MANAGE_OVERLAY_PERMISSION) },
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(12) })
        permBox.addView(button(Lang.s(ctx,"btn_write")) { openSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS) },
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(8) })
        permBox.addView(button(Lang.s(ctx,"btn_root")) {
            if (Access.shizukuRunning() && !Access.shizukuGranted()) Access.requestShizuku(4242)
            Thread { Access.checkRoot() }.start()
        }, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(8) })
        // ---- Tombol pilih bahasa ----
        val langEntry = Lang.entry(ctx)
        val langBtn = button(Lang.s(ctx,"lang_btn_prefix") + " ${langEntry.flag} ${langEntry.name}") { showLangDialog() }
        permBox.addView(langBtn, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(8) })
        langBtnRef = langBtn

        enterBtn = button(Lang.s(ctx,"btn_enter")) { startDetect() }
        permBox.addView(enterBtn, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(14) })
        col.addView(permBox, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = ctx.px(14) })

        info.textSize = 12f
        info.setTextColor(Color.argb(230, 220, 240, 255))
        info.gravity = Gravity.CENTER
        info.setPadding(0, ctx.px(10), 0, 0)
        col.addView(info, LinearLayout.LayoutParams(-1, -2))

        countdown.textSize = 13f
        countdown.setTextColor(Hud.neon)
        countdown.gravity = Gravity.CENTER
        countdown.setPadding(0, ctx.px(14), 0, 0)
        col.addView(countdown, LinearLayout.LayoutParams(-1, -2))

        // seluruh isi bisa digulir supaya tombol di bawah tetap bisa ditekan di layar kecil
        val sv = android.widget.ScrollView(ctx).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            addView(col, FrameLayout.LayoutParams(-1, -2))
        }
        addView(sv, LayoutParams(-1, -1))
        post(checkRunnable)
    }

    private fun startDetect() {
        if (detectStarted) return
        detectStarted = true
        title.text = Lang.s(ctx,"detecting")
        Thread {
            Access.ensure()
            val d = try { DeviceInfo.collect(ctx) } catch (e: Exception) { emptyList() }
            val st = Store(ctx)
            for ((k, v) in d) st.put("dev_" + k.lowercase().replace(" ", "_").replace("/", "_"), v)
            st.put("dev_gpu", d.firstOrNull { it.first == "GPU" }?.second?.substringBefore(" ") ?: "UNKNOWN")
            st.put("dev_tier", d.firstOrNull { it.first == "Kelas" }?.second ?: "")
            st.put("dev_info", d.joinToString("\n") { "${it.first}: ${it.second}" })
            val summary = listOf("Perangkat", "Android", "GPU", "RAM", "Layar")
                .mapNotNull { key -> d.firstOrNull { it.first == key }?.let { "${it.first}: ${it.second}" } }
                .joinToString("\n")
            post {
                title.text = Lang.s(ctx,"detected")
                info.text = summary.ifBlank { Lang.s(ctx,"detect_fail") }
                startCountdown(3)
            }
        }.start()
    }

    private fun startCountdown(sec: Int) {
        if (sec <= 0) {
            if (finished) return
            finished = true
            Store(ctx).put("dev_done", "1")
            (parent as? android.view.ViewGroup)?.removeView(this)
            onDone()
            return
        }
        countdown.text = "GameSpace terbuka dalam $sec detik..."
        postDelayed({ startCountdown(sec - 1) }, 1000)
    }
}
