package com.xa.gamespace

import android.content.Context
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView

// Wallpaper video latar (tanpa suara) dengan loop mulus.
// Dua MediaPlayer disiapkan bergantian: saat yang sedang tampil selesai, yang kedua langsung
// dijalankan dari awal (sudah siap, tanpa seek). Yang selesai disiapkan ulang di belakang layar.
// Jadi titik ulang tidak berhenti seperti loop biasa (isLooping/seek).
class VideoBg(ctx: Context) : TextureView(ctx), TextureView.SurfaceTextureListener {
    private val players = arrayOfNulls<MediaPlayer>(2)
    private val ready = BooleanArray(2)
    private var cur = 0
    private var surface: Surface? = null
    private var paused = false
    private var vw = 0
    private var vh = 0

    init { surfaceTextureListener = this }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        surface = Surface(st)
        openAll()
    }

    private fun source(): Uri {
        val pick = Store(context).get("home_video")
        return if (pick.isNotBlank()) Uri.parse(pick)
        else Uri.parse("android.resource://${context.packageName}/${R.raw.anime_bg}")
    }

    private fun openAll() {
        releaseAll()
        if (surface == null) return
        for (i in 0..1) {
            try {
                val p = MediaPlayer()
                p.setDataSource(context, source())
                p.setVolume(0f, 0f)
                p.setOnVideoSizeChangedListener { _, w, h -> vw = w; vh = h; fit() }
                p.setOnPreparedListener { pl ->
                    ready[i] = true
                    if (i == cur && !paused) {
                        pl.setSurface(surface)
                        pl.start()
                    }
                }
                p.setOnCompletionListener { swap() }
                p.setOnErrorListener { _, _, _ -> true }
                players[i] = p
                p.prepareAsync()
            } catch (e: Exception) {
                players[i] = null
            }
        }
    }

    // pindah ke pemutar kedua yang sudah siap, lalu siapkan ulang yang selesai
    private fun swap() {
        val old = players[cur] ?: return
        val nextIdx = 1 - cur
        val next = players[nextIdx]
        try {
            if (next == null || !ready[nextIdx]) {
                // jarang terjadi: pemutar kedua belum siap, ulang yang sekarang
                old.seekTo(0)
                old.start()
                return
            }
            old.setSurface(null)
            next.setSurface(surface)
            next.start()
            cur = nextIdx
            old.seekTo(0)   // siapkan di awal (di belakang layar, tidak terlihat)
        } catch (e: Exception) {}
    }

    private fun fit() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (vw == 0 || vh == 0 || w == 0f || h == 0f) return
        // isi layar penuh (crop bila rasio beda)
        val av = vw.toFloat() / vh
        val aw = w / h
        val sx = if (av > aw) av / aw else 1f
        val sy = if (av > aw) 1f else aw / av
        val m = Matrix()
        m.setScale(sx, sy, w / 2, h / 2)
        setTransform(m)
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) = fit()

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        releaseAll()
        surface?.release()
        surface = null
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    // jeda: video yang tampil berhenti di frame yang sama
    fun pause() {
        paused = true
        try { players[cur]?.let { if (it.isPlaying) it.pause() } } catch (e: Exception) {}
    }

    // lanjut dari frame yang sama
    fun resume() {
        paused = false
        val p = players[cur]
        if (p == null) {
            if (surface != null) openAll()
            return
        }
        try { if (ready[cur] && !p.isPlaying) p.start() } catch (e: Exception) {}
    }

    // kompatibilitas: video latar selalu tanpa suara
    fun setSound(on: Boolean) {}

    private fun releaseAll() {
        for (i in 0..1) {
            try { players[i]?.release() } catch (e: Exception) {}
            players[i] = null
            ready[i] = false
        }
        cur = 0
    }
}
