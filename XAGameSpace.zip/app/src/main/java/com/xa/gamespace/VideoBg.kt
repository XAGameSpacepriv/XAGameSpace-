package com.xa.gamespace

import android.content.Context
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.net.Uri
import android.view.Surface
import android.view.TextureView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer

// Wallpaper video latar (tanpa suara). Memakai ExoPlayer (Media3) dengan REPEAT_MODE_ONE:
// pengulangan lebih mulus dibanding MediaPlayer.isLooping yang membuat jeda saat kembali ke awal.
// Pause/resume hanya menjeda pemutar yang sama, tidak membuka ulang video.
class VideoBg(ctx: Context) : TextureView(ctx), TextureView.SurfaceTextureListener {
    private var player: ExoPlayer? = null
    private var surface: Surface? = null
    private var paused = false
    private var vw = 0
    private var vh = 0

    init { surfaceTextureListener = this }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        surface = Surface(st)
        open()
    }

    private fun source(): Uri {
        val pick = Store(context).get("home_video")
        return if (pick.isNotBlank()) Uri.parse(pick)
        else Uri.parse("android.resource://${context.packageName}/${R.raw.anime_bg}")
    }

    private fun open() {
        release()
        val s = surface ?: return
        val p = ExoPlayer.Builder(context).build()
        p.setVideoSurface(s)
        p.volume = 0f
        p.repeatMode = Player.REPEAT_MODE_ONE
        p.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(size: VideoSize) {
                vw = size.width
                vh = size.height
                fit()
            }
        })
        p.setMediaItem(MediaItem.fromUri(source()))
        p.prepare()
        p.playWhenReady = !paused
        player = p
    }

    private fun fit() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (vw == 0 || vh == 0 || w == 0f || h == 0f) return
        // isi layar penuh (crop bila rasio beda), seperti sebelumnya
        val av = vw.toFloat() / vh
        val aw = w / h
        val sx = if (av > aw) av / aw else 1f
        val sy = if (av > aw) 1f else aw / av
        val m = Matrix()
        m.setScale(sx, sy, w / 2, h / 2)
        setTransform(m)
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) = fit()

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        release()
        surface?.release()
        surface = null
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    // jeda: pemutar tetap hidup, posisi video tidak hilang
    fun pause() {
        paused = true
        player?.playWhenReady = false
    }

    // lanjut dari posisi yang sama tanpa memuat ulang
    fun resume() {
        paused = false
        val p = player
        if (p == null) {
            if (surface != null) open()
        } else {
            p.playWhenReady = true
        }
    }

    // kompatibilitas: video latar selalu tanpa suara
    fun setSound(on: Boolean) {}

    private fun release() {
        try { player?.release() } catch (e: Exception) {}
        player = null
    }
}
