package com.xa.gamespace

import android.content.Context
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView

// Wallpaper video latar (tanpa suara), MediaPlayer tunggal dengan loop bawaan.
// Pause/resume hanya menjeda pemutar yang sama.
class VideoBg(ctx: Context) : TextureView(ctx), TextureView.SurfaceTextureListener {
    private var mp: MediaPlayer? = null
    private var surface: Surface? = null
    private var prepared = false
    private var paused = false
    private var vw = 0
    private var vh = 0

    init { surfaceTextureListener = this }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        surface = Surface(st)
        open()
    }

    private fun open() {
        release()
        try {
            val p = MediaPlayer()
            val pick = Store(context).get("home_video")
            p.setDataSource(context, if (pick.isNotBlank()) Uri.parse(pick)
                else Uri.parse("android.resource://${context.packageName}/${R.raw.anime_bg}"))
            p.setSurface(surface)
            p.isLooping = true
            p.setVolume(0f, 0f)
            p.setOnVideoSizeChangedListener { _, w, h -> vw = w; vh = h; fit() }
            p.setOnPreparedListener { pl ->
                prepared = true
                if (!paused) pl.start()
            }
            p.setOnErrorListener { _, _, _ -> true }
            mp = p
            p.prepareAsync()
        } catch (e: Exception) {
            mp = null
        }
    }

    private fun fit() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (vw == 0 || vh == 0 || w == 0f || h == 0f) return
        // isi layar penuh (crop bila rasio beda)
        val av = vw.toFloat() / vh
        val aw = w / h
        val sx = if (av > aw) av / aw else 1f
        val sy = if (av > aw) 1f else aw / av
        val m = Matrix()
        m.setScale(sx, sy, w / 2, h / 2)
        setTransform(m)
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) = fit()

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        release()
        surface?.release()
        surface = null
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    fun pause() {
        paused = true
        try { mp?.let { if (prepared && it.isPlaying) it.pause() } } catch (e: Exception) {}
    }

    fun resume() {
        paused = false
        val p = mp
        if (p == null) {
            if (surface != null) open()
        } else if (prepared) {
            try { if (!p.isPlaying) p.start() } catch (e: Exception) {}
        }
    }

    // kompatibilitas: video latar selalu tanpa suara
    fun setSound(on: Boolean) {}

    private fun release() {
        prepared = false
        try { mp?.release() } catch (e: Exception) {}
        mp = null
    }
}
