package com.xa.gamespace

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.TrafficStats
import android.os.BatteryManager
import android.view.Gravity
import android.view.InputDevice
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

// Mode 2: layout seperti foto referensi. Latar berupa video mp4.
class ModeTwo(private val a: MainActivity) : FrameLayout(a) {
    private val title = TextView(a)
    private val activity = TextView(a)
    private val sub = TextView(a)
    private val selLabel = TextView(a)
    private val achv = TextView(a)
    private val netValue = TextView(a)
    private val iconRow = LinearLayout(a)
    private val circles = ArrayList<TextView>()
    private var playTv: View? = null
    private var bgVideo: VideoBg? = null
    private var cardsRow: LinearLayout? = null
    private val iconViews = ArrayList<View>()
    private var stacked = false
    private var sel: GameApp? = null
    private var games: List<GameApp> = emptyList()
    private var ready = false
    private var rxLast = 0L
    private var txLast = 0L
    private var lastT = 0L

    private val MAX_ICONS = 4

    private val tick = object : Runnable {
        override fun run() {
            refreshStats()
            updateNet()
            postDelayed(this, 1000)
        }
    }

    private fun px(v: Int) = a.px(v)
    private fun dim(alpha: Int = 200) = Color.argb(alpha, 200, 215, 235)

    private fun sq(label: String, onClick: () -> Unit): TextView = TextView(a).apply {
        text = label; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = Hud.rounded(Color.argb(170, 20, 22, 30), Color.argb(40, 255, 255, 255), a.pxf(12f), 1f)
        setOnClickListener { Sfx.tap(); onClick() }
    }

    private fun card(): LinearLayout = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(px(10), px(8), px(10), px(8))
        background = Hud.rounded(Color.argb(170, 18, 20, 28), Color.argb(40, 255, 255, 255), a.pxf(14f), 1f)
    }

    private fun circle(): TextView = TextView(a).apply {
        textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = Hud.rounded(Color.argb(60, 8, 40, 60), Color.argb(200, 0, 230, 255), a.pxf(40f), 2f)
    }

    private fun updateActivity() {
        val g = sel
        if (g == null) { activity.text = "Belum ada game"; return }
        val n = a.store.get("play_cnt_${g.pkg}").toIntOrNull() ?: 0
        activity.text = "${g.label}\nDibuka $n kali dari GameSpace"
    }

    private fun select(g: GameApp?) {
        sel = g
        updateActivity()
        val newTitle = g?.label ?: "Belum ada game"
        val newSub = if (g == null) "Tambahkan game di mode 1" else "Ready to play"
        if (ready) {
            title.animate().alpha(0f).translationX(-px(20).toFloat()).setDuration(140).withEndAction {
                title.text = newTitle; title.translationX = px(20).toFloat()
                title.animate().alpha(1f).translationX(0f).setDuration(320)
                    .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
            }.start()
            sub.animate().alpha(0f).setDuration(120).withEndAction { sub.text = newSub; sub.animate().alpha(1f).setDuration(260).start() }.start()
            selLabel.animate().alpha(0f).setDuration(120).withEndAction { selLabel.text = g?.label ?: ""; selLabel.animate().alpha(1f).setDuration(260).start() }.start()
        } else {
            title.text = newTitle; selLabel.text = g?.label ?: ""; sub.text = newSub
        }
        rebuildIcons()
    }

    private fun rebuildIcons() {
        iconRow.removeAllViews()
        iconRow.gravity = Gravity.CENTER_VERTICAL
        iconViews.clear()
        val size = px(44)
        iconRow.addView(sq("▦") { toggleStack() }, LinearLayout.LayoutParams(size, size).also { it.rightMargin = px(8) })
        // batasi ikon di baris (maks 4) supaya tombol kontrol tidak menjajar jauh
        for (g in games.take(MAX_ICONS)) {
            val on = g.pkg == sel?.pkg
            val ic = ImageView(a).apply {
                setImageDrawable(g.icon)
                setPadding(px(3), px(3), px(3), px(3))
                scaleType = ImageView.ScaleType.FIT_CENTER
                background = Hud.rounded(Color.argb(170, 20, 22, 30),
                    if (on) Color.WHITE else Color.argb(40, 255, 255, 255), a.pxf(12f), if (on) 2f else 1f)
                // sudut ikon dipotong membulat (tidak tajam)
                clipToOutline = true
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(v: View, o: android.graphics.Outline) {
                        o.setRoundRect(0, 0, v.width, v.height, a.pxf(12f))
                    }
                }
                setOnClickListener { Sfx.tap(); select(g) }
            }
            if (on) { ic.scaleX = 1.12f; ic.scaleY = 1.12f }
            iconViews.add(ic)
            iconRow.addView(ic, LinearLayout.LayoutParams(size, size).also { it.rightMargin = px(8) })
        }
        iconRow.addView(netValue, LinearLayout.LayoutParams(-2, size).also { it.rightMargin = px(8) })
        iconRow.addView(sq("▲") { sel?.let { a.showPanel("TEXTURE · ${it.label}", TexturePanel(a, it.pkg).root) } }, LinearLayout.LayoutParams(size, size).also { it.rightMargin = px(8) })
        iconRow.addView(sq("🖼") { a.openBgPicker() }, LinearLayout.LayoutParams(size, size))
        applyStack(false)
    }

    // kumpulkan ikon game jadi satu tumpukan: margin negatif, game pertama paling depan
    private fun toggleStack() {
        stacked = !stacked
        applyStack(true)
    }

    private fun applyStack(animate: Boolean) {
        val n = iconViews.size
        val toStack = if (stacked) -(px(44) - px(14)) else px(8)
        for ((i, v) in iconViews.withIndex()) {
            v.z = (n - i).toFloat()
            val lp = v.layoutParams as LinearLayout.LayoutParams
            // ikon terakhir tidak ditumpuk, supaya kontrol di kanannya tidak masuk ke tumpukan
            val to = if (i == n - 1) px(8) else toStack
            val from = lp.rightMargin
            if (animate) {
                android.animation.ValueAnimator.ofInt(from, to).apply {
                    duration = 420
                    interpolator = android.view.animation.DecelerateInterpolator()
                    addUpdateListener { va ->
                        lp.rightMargin = va.animatedValue as Int
                        v.layoutParams = lp
                    }
                    start()
                }
            } else {
                lp.rightMargin = to
                v.layoutParams = lp
            }
        }
    }

    private fun updateNet() {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        val now = System.currentTimeMillis()
        if (lastT > 0 && rx >= 0 && tx >= 0) {
            val dt = (now - lastT).coerceAtLeast(1) / 1000.0
            val down = ((rx - rxLast) / dt / 1024).toInt()
            val up = ((tx - txLast) / dt / 1024).toInt()
            netValue.text = "↓ ${down} KB/s\n↑ ${up} KB/s"
        }
        rxLast = rx; txLast = tx; lastT = now
    }

    private fun refreshStats() {
        Thread {
            val pct = try {
                (a.getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
                    .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            } catch (e: Exception) { -1 }
            val s = try { SysStats.sample(a, false) } catch (e: Exception) { null }
            val gp = countGamepads()
            post {
                circles.getOrNull(0)?.text = if (pct >= 0) "$pct%" else "-"
                circles.getOrNull(1)?.text = "${s?.cpuPct ?: "-"}%"
                circles.getOrNull(2)?.text = s?.tempC?.let { "%.0f°".format(it) } ?: "-"
                ctrlText.text = if (gp > 0) "$gp controller terhubung" else "No controller connected"
            }
        }.start()
    }

    private val ctrlText = TextView(a)

    private fun countGamepads(): Int {
        var n = 0
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if ((d.sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD) n++
        }
        return n
    }

    // pengaturan mode HP: Normal / Balance / Performa (mengatur kecepatan render layar)
    private fun openPowerMode() {
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(px(4), px(4), px(4), px(4)) }
        val modes = listOf(
            Triple("Normal", "Bawaan", "") ,
            Triple("Balance", "90 Hz", "90"),
            Triple("Performa", "120 Hz", "120")
        )
        for ((name, desc, hz) in modes) {
            box.addView(TextView(a).apply {
                text = "$name  ·  $desc"; textSize = 14f; setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                setPadding(px(14), px(12), px(14), px(12))
                background = Hud.rounded(Color.argb(120, 30, 45, 70), Color.argb(70, 255, 255, 255), a.pxf(12f), 1f)
                setOnClickListener {
                    Sfx.tap()
                    a.store.put("power_mode", name)
                    Thread {
                        Access.run(if (hz.isBlank()) RateCmd.renderDefaultCmd() else RateCmd.renderCmd(hz))
                    }.start()
                    a.closePanel()
                }
            }, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = px(8) })
        }
        a.showPanel("MODE HP", box)
    }

    init {
        isClickable = true
        // latar video mp4 (memakai pilihan LATAR; bawaan = video anime)
        bgVideo = VideoBg(a)
        addView(bgVideo, 0, LayoutParams(-1, -1))
        setBackgroundColor(Color.parseColor("#06101C"))
        games = try { Games.detect(a) } catch (e: Exception) { emptyList() }

        val body = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(px(18), px(16), px(18), px(14)) }

        val top = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(a).apply { text = "Games"; textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD },
            LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(18) })
        top.addView(TextView(a).apply { text = "Media"; textSize = 15f; setTextColor(dim(150)) },
            LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(a).apply {
            text = "◀ MODE 1"; textSize = 11f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setPadding(px(12), px(7), px(12), px(7)); isSingleLine = true
            background = Hud.rounded(Color.argb(170, 20, 22, 30), Hud.cyan, a.pxf(12f), 1f)
            setOnClickListener { Sfx.tap(); a.setMode(1) }
        }, LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(12) })
        top.addView(TextView(a).apply { text = "⌕"; textSize = 18f; setTextColor(Color.WHITE) },
            LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(12) })
        top.addView(TextView(a).apply { text = "⚙"; textSize = 18f; setTextColor(Color.WHITE) },
            LinearLayout.LayoutParams(-2, -2).also { it.rightMargin = px(12) })
        top.addView(android.widget.TextClock(a).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"; textSize = 14f; setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(-2, -2))
        body.addView(top, LinearLayout.LayoutParams(-1, -2))

        body.addView(HorizontalScrollView(a).apply { isHorizontalScrollBarEnabled = false; addView(iconRow) },
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(16) })
        selLabel.textSize = 11f; selLabel.setTextColor(dim(170))
        selLabel.setPadding(px(52), px(4), 0, 0)
        body.addView(selLabel, LinearLayout.LayoutParams(-1, -2))

        netValue.textSize = 11f; netValue.setTextColor(Color.WHITE); netValue.typeface = Typeface.DEFAULT_BOLD
        netValue.gravity = Gravity.CENTER
        netValue.setPadding(px(10), px(4), px(10), px(4))
        netValue.background = Hud.rounded(Color.argb(170, 20, 22, 30), Color.argb(60, 0, 230, 255), a.pxf(12f), 1f)
        netValue.text = "↓ 0 KB/s\n↑ 0 KB/s"
        netValue.minWidth = px(104)
        netValue.z = 100f
        netValue.gravity = Gravity.CENTER

        body.addView(View(a), LinearLayout.LayoutParams(-1, 0, 1f))

        title.textSize = 34f; title.setTextColor(Color.WHITE); title.typeface = Typeface.DEFAULT_BOLD
        body.addView(title, LinearLayout.LayoutParams(-1, -2))
        sub.textSize = 13f; sub.setTextColor(dim(170))
        body.addView(sub, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(2) })

        // Play kecil di kiri, ••• di sebelahnya (pengaturan mode HP)
        val playRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val playTvLocal = TextView(a).apply {
            text = "▶  Play Game"; textSize = 13f; setTextColor(Color.parseColor("#1A1E26"))
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(px(20), px(9), px(20), px(9))
            background = Hud.rounded(Color.argb(235, 220, 230, 240), Color.WHITE, a.pxf(22f), 1f)
            setOnClickListener { Sfx.tap(); sel?.let { a.play(it.pkg) } }
        }
        playTv = playTvLocal
        playRow.addView(playTvLocal, LinearLayout.LayoutParams(-2, -2))
        playRow.addView(sq("•••") { openPowerMode() }, LinearLayout.LayoutParams(px(42), px(42)).also { it.leftMargin = px(10) })
        body.addView(playRow, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = px(14) })

        // kartu bawah (teks kecil), statistik berbentuk lingkaran
        // kartu 1: info kontak (klik = buka saluran WhatsApp)
        achv.textSize = 10f; achv.setTextColor(Color.WHITE)
        achv.text = "WA Saluran\nTikTok @XAGameSpace\nAdmin 085135834977"
        val c1 = card().apply {
            addView(TextView(a).apply { text = "Info"; textSize = 9f; setTextColor(dim(170)) })
            addView(achv, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(4) })
            setOnClickListener {
                Sfx.tap()
                try {
                    a.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse("https://whatsapp.com/channel/0029Vb9oX42LikgFESrDLY1J")))
                } catch (e: Exception) {}
            }
        }
        // kartu 2: aktivitas (nama game & jumlah dibuka dari GameSpace)
        activity.textSize = 10f; activity.setTextColor(Color.WHITE)
        val c2 = card().apply {
            addView(TextView(a).apply { text = "Aktivitas"; textSize = 9f; setTextColor(dim(170)) })
            addView(activity, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(4) })
        }
        val c3 = card().apply {
            gravity = Gravity.CENTER
            val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            circles.clear()
            for (lab in listOf("BAT", "CPU", "TEMP")) {
                val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
                val cv = circle().also { circles.add(it); it.text = "-" }
                col.addView(cv, LinearLayout.LayoutParams(px(44), px(44)))
                col.addView(TextView(a).apply { text = lab; textSize = 8f; setTextColor(dim(170)); gravity = Gravity.CENTER },
                    LinearLayout.LayoutParams(-2, -2))
                row.addView(col, LinearLayout.LayoutParams(-2, -2).also { it.setMargins(px(3), 0, px(3), 0) })
            }
            addView(row)
        }
        val c4 = card().apply {
            addView(TextView(a).apply { text = "Controller"; textSize = 9f; setTextColor(dim(170)) })
            ctrlText.textSize = 11f; ctrlText.setTextColor(Color.WHITE)
            addView(ctrlText, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(4) })
        }
        val cards = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        for (c in listOf(c1, c2, c3, c4)) cards.addView(c, LinearLayout.LayoutParams(0, px(88), 1f).also { it.setMargins(px(4), 0, px(4), 0) })
        cardsRow = cards
        body.addView(cards, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = px(14) })

        addView(body, LayoutParams(-1, -1))
        select(games.firstOrNull())
        ready = true
        refreshStats()
    }

    fun enter() {
        cardsRow?.let { row ->
            for (i in 0 until row.childCount) {
                val c = row.getChildAt(i)
                c.alpha = 0f; c.translationY = px(60).toFloat()
                c.animate().alpha(1f).translationY(0f).setStartDelay(160L + i * 90L).setDuration(460)
                    .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateActivity()
        postDelayed(tick, 1000)
    }

    // dipanggil dari MainActivity saat aplikasi ke latar belakang / kembali
    fun pauseBackground() {
        removeCallbacks(tick)
        bgVideo?.pause()
    }

    fun resumeBackground() {
        postDelayed(tick, 1000)
        bgVideo?.resume()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }
}
