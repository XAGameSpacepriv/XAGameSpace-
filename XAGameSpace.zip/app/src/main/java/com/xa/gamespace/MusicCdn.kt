package com.xa.gamespace

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

// Lagu bawaan tidak lagi ada di dalam APK (supaya APK di bawah 24 MB).
// Isi BASE dengan folder hosting tempat file <nama>.m4a diunggah (misal Google Drive direct link / server sendiri).
object MusicCdn {
    const val BASE = "https://GANTI-DENGAN-LINK-HOSTING-ANDA/music/"

    fun localFile(ctx: Context, name: String): File {
        val dir = File(ctx.filesDir, "music").apply { mkdirs() }
        return File(dir, "$name.m4a")
    }

    fun download(ctx: Context, name: String): Boolean = try {
        val c = URL(BASE + name + ".m4a").openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 60000
        val target = localFile(ctx, name)
        val tmp = File(target.parentFile, target.name + ".part")
        c.inputStream.use { inp -> tmp.outputStream().use { out -> inp.copyTo(out) } }
        tmp.renameTo(target)
    } catch (e: Exception) { false }
}
